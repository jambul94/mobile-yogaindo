import React from 'react'
import Modal from 'react-native-modal'
import PropTypes from 'prop-types'
import {Spinner} from 'native-base'

const CustomModalSpinner = (props) => {
  return (
    <Modal isVisible={props.isVisible} animationIn="bounceIn" animationOut="bounceOut" backdropTransitionOutTiming={0}>
      <Spinner color="#f5f5f5" />
    </Modal>
  )
}

CustomModalSpinner.propTypes = {
  isVisible: PropTypes.bool,
}

CustomModalSpinner.defaultProps = {
  isVisible: false,
}

export default CustomModalSpinner
