import React from 'react'
import PropTypes from 'prop-types'
import {TouchableOpacity} from 'react-native'
import {Icon} from 'native-base'

const styleIconBtn = {
  icon: {
    fontSize: 20,
  },
  active: {
    color: '#202020',
  },
  inActive: {
    color: '#666666',
  },
}

class CustomIconBtn extends React.Component {
  constructor (props) {
    super(props)

    this.pressIconButton = this.pressIconButton.bind(this)
  }

  pressIconButton () {
    const {props} = this

    props.onPress && props.onPress(props.idIconBtn)
  }

  render () {
    const {props} = this
    const activeColor = props.isActive ? styleIconBtn.active : styleIconBtn.inActive

    return (
      <TouchableOpacity style={props.style} onPress={this.pressIconButton}>
        <Icon style={[styleIconBtn.icon, activeColor]} type="FontAwesome5" name={props.icon} />
      </TouchableOpacity>
    )
  }
}

CustomIconBtn.propTypes = {
  style: PropTypes.oneOfType([
    PropTypes.object,
    PropTypes.array,
  ]),
  idIconBtn: PropTypes.number,
  icon: PropTypes.string,
  isActive: PropTypes.bool,
  onPress: PropTypes.func,
}

CustomIconBtn.defaultProps = {
  idIconBtn: 0,
  icon: null,
  isActive: false,
}

export default CustomIconBtn
