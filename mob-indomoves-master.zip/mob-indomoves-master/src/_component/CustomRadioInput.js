import React from 'react'
import PropTypes from 'prop-types'
import RadioGroup from 'react-native-radio-buttons-group';

class CustomRadioButton extends React.Component {
  /**
   * Constructor class
   *
   * @param {*} props - component properties
   */
  constructor (props) {
    super(props)
    this.handlePressItem =  this.handlePressItem.bind(this)
  }

	/**
   * Event handler - change text input
   *
   * @param {*} value - selected value item radio
   *
   * @return {void}
   */
  handlePressItem (data) {
    const {props} = this
    const fixData = data.slice().find(e => e.selected === true)
    const fixValue = fixData ? fixData.value : ''

    props.onPress && props.onPress(props.name, fixValue)
  }

  /**
   * Main render component
   *
   * @return {*} any
   */
  render () {
    const {props} = this
    return (
      <RadioGroup
        {...props}
        onPress={this.handlePressItem} />
    )
  }
}

CustomRadioButton.propTypes = {
  onPress: PropTypes.func,
  name: PropTypes.string.isRequired,
}

export default CustomRadioButton
