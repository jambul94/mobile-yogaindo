import React from 'react'
import Modal from 'react-native-modal'
import PropTypes from 'prop-types'
import Moment from 'react-moment'
import {FlatList, Image, TouchableOpacity} from 'react-native'
import {Col, Container, Icon, Row, Text} from 'native-base'
import {CustomInput} from '../_component'


class CustomModalComment extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      comment: null,
    }

    this.change_input = this.change_input.bind(this)
    this.on_modalHide = this.on_modalHide.bind(this)
    this.press_submitComment = this.press_submitComment.bind(this)
  }

  change_input (name, value) {
    this.setState({
      [name]: value,
    })
  }

  on_modalHide () {
    this.setState({
      comment: null,
    })
  }

  press_submitComment () {
    const {props, state} = this

    props.onPressSubmitComment && props.onPressSubmitComment(props.parentData.id, state.comment)
  }

  render () {
    const {props, state} = this
    const noImage = require('../assets/images/no-image.jpg')

    return (
      <Modal
        isVisible={props.isVisible}
        animationIn="slideInDown"
        animationOut="slideOutUp"
        onModalHide={this.on_modalHide}
        onBackButtonPress={props.onBackButtonPress}
        backdropTransitionOutTiming={0}>
          <Container>
            {props.parentData !== null && (
              <Col>
                <Row style={{padding: 15, flex: 0, borderBottomColor: '#666666', borderBottomWidth: 1}}>
                  <Image style={{width: 50, height: 50, borderRadius: 50/2, backgroundColor: 'rgba(0, 0, 0, 0.3)'}} defaultSource={noImage} source={{uri: props.parentData.commenter.photo_thumbnail}} />
                  <Col>
                    <Row style={{paddingLeft: 15, flex: 0}}>
                      <Text style={{color: '#202020', fontSize: 14}}>{props.parentData.commenter.name} . </Text>
                      <Moment style={{color: '#666666', fontSize: 11, paddingTop: 3}} fromNow={true} ago={true} element={Text}>{props.parentData.created_at}</Moment>
                    </Row>
                    <Text style={{color: '#666666', fontSize: 12, paddingLeft: 15, paddingVertical: 5}}>{props.parentData.comment}</Text>
                    <Text style={{color: '#075e54', fontSize: 12, paddingLeft: 15}}>{props.parentData.user_comments.length} comments</Text>
                  </Col>
                </Row>

                <FlatList
                  data={props.parentData.user_comments}
                  style={{paddingVertical: 15, paddingLeft: 30, paddingRight: 15}}
                  renderItem={({item}) => {
                    return (
                      <Row style={{marginBottom: 20}}>
                        <Image style={{width: 50, height: 50, borderRadius: 50/2, backgroundColor: 'rgba(0, 0, 0, 0.3)'}} defaultSource={noImage} source={{uri: item.commenter.photo_thumbnail}} />
                        <Col>
                          <Row style={{paddingLeft: 15, flex: 0}}>
                            <Text style={{color: '#202020', fontSize: 14}}>{item.commenter.name} . </Text>
                            <Moment style={{color: '#666666', fontSize: 11, paddingTop: 3}} fromNow={true} ago={true} element={Text}>{item.created_at}</Moment>
                          </Row>
                          <Text style={{color: '#666666', fontSize: 12, paddingLeft: 15, paddingVertical: 5}}>{item.comment}</Text>
                        </Col>
                      </Row>
                    )
                  }} />

                <Row style={{backgroundColor: '#e4e4e4', alignItems: 'center', flex: 0, paddingVertical: 5, paddingHorizontal: 15}}>
                  <CustomInput
                    onChangeText={this.change_input}
                    multiline={true}
                    name="comment"
                    placeholder="insert comment..."
                    placeholderTextColor="#707070"
                    style={{flex: 1, color: '#202020', marginLeft: 10, fontSize: 14, height: 50}}
                    value={state.comment} />

                  <TouchableOpacity onPress={this.press_submitComment} style={{backgroundColor: '#075e54', height: 40, width: 48, justifyContent: 'center', alignItems: 'center'}}>
                    <Icon style={{color: '#f4f4f4f4', fontSize: 16}} name="arrow-right" type="FontAwesome5" />
                  </TouchableOpacity>
                </Row>
              </Col>
            )}
          </Container>
      </Modal>
    )
  }
}

CustomModalComment.propTypes = {
  isVisible: PropTypes.bool,
  onBackButtonPress: PropTypes.func,
  onPressSubmitComment: PropTypes.func,
  parentData: PropTypes.object,
}

CustomModalComment.defaultProps = {
  isVisible: false,
  parentData: null,
}

export default CustomModalComment
