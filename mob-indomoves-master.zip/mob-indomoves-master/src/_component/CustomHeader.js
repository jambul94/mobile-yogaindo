import React from 'react'
import PropTypes from 'prop-types'
import {Body, Button, Header, Icon, Left, Right, Row, Title, Text} from 'native-base'

class CustomHeader extends React.Component {
  /**
   * Constructor class
   *
   * @param {*} props - component properties
   */
  constructor (props) {
    super(props)

    this.handlePressBackButton = this.handlePressBackButton.bind(this)
  }

  /**
   * Event handler - press back button
   *
   * @return {void}
   */
  handlePressBackButton () {
    const {props} = this

    props.navigation.goBack()
  }

  /**
   * Main render component
   *
   * @return {*} any node
   */
  render () {
    const {props} = this

    return (
      <Header
        translucent={false}
        androidStatusBarColor="#ffffff"
        iosBarStyle="dark-content"
        noShadow={true}
        style={{backgroundColor: '#ffffff'}}>

        <Left style={{flex: 0, width: 50}}>
          {!props.noLeft ?
            props.leftChildren === null ? (
              <Button
                onPress={this.handlePressBackButton}
                transparent={true}>

                <Icon style={{color: '#202020', fontSize: 16}} name="arrow-left" type="FontAwesome5" />
              </Button>
            ) : props.leftChildren
          : null}
        </Left>

        <Body style={{alignItems: props.bodyAlignItem}}>
          {props.title !== null ? (
            <Title style={{color: '#202020', fontSize: 16, letterSpacing: 1, textTransform: 'uppercase'}}>{props.title}</Title>
          ) : (
            <Row style={{alignItems: 'center'}}>
              <Text style={{color: '#202020', fontSize: 20, fontWeight: 'bold', letterSpacing: 1}}>Yoga</Text>
              <Text style={{color: '#202020', fontSize: 20, textTransform: 'uppercase', letterSpacing: 1}}>Indo</Text>
            </Row>
          )}
        </Body>

        <Right style={{flex: 0, width: 50}}>
          {!props.noRight ? props.rightChildren !== null ? props.rightChildren : null : null}
        </Right>
      </Header>
    )
  }
}

CustomHeader.propTypes = {
  bodyAlignItem: PropTypes.oneOf(['flex-start', 'center', 'flex-end']),
  leftChildren: PropTypes.any,
  noLeft: PropTypes.bool,
  noRight: PropTypes.bool,
  navigation: PropTypes.object,
  rightChildren: PropTypes.any,
  title: PropTypes.string,
}

CustomHeader.defaultProps = {
  bodyAlignItem: 'center',
  leftChildren: null,
  noLeft: false,
  noRight: false,
  navigation: null,
  rightChildren: null,
  title: null,
}

export default CustomHeader
