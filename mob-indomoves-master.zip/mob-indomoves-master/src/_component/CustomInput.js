import React from 'react'
import PropTypes from 'prop-types'
import {Input} from 'native-base'

class CustomInput extends React.Component {
  constructor (props) {
    super(props)

    this.handleChangeText = this.handleChangeText.bind(this)
  }

  handleChangeText (value) {
    const {props} = this

    props.onChangeText && props.onChangeText(props.name, value)
  }

  render () {
    const {props} = this

    return (
      <Input
        {...props}
        onChangeText={this.handleChangeText} />
    )
  }
}

CustomInput.propTypes = {
  onChangeText: PropTypes.func,
  name: PropTypes.string.isRequired,
}

export default CustomInput
