import React from 'react'
import {Col, Container, Content, Icon, Item, Row, Text} from 'native-base'
import {TouchableOpacity, View} from 'react-native'
import {CustomHeader, CustomInput} from '../_component'
import {connect} from 'react-redux'
import {language} from '../_common/language'
import {set_filterFaqTextSearch} from '../_actions/filter'
import {get_listFaq} from '../_actions/content'

class ContentFaqList extends React.Component {
  constructor (props) {
    super(props)

    this.change_input = this.change_input.bind(this)
    this.press_clearSearch = this.press_clearSearch.bind(this)
    this.press_detailFaq = this.press_detailFaq.bind(this)
    this.press_search = this.press_search.bind(this)
  }

  change_input (name, value) {
    const {props} = this

    if (name === 'textSearch') {
      props.dispatch(set_filterFaqTextSearch(value))
    }
  }

  press_clearSearch () {
    const {props} = this

    props.dispatch(set_filterFaqTextSearch(''))
    props.dispatch(get_listFaq())
  }

  press_detailFaq (idFaq) {
    const {props} = this

    props.navigation.navigate('ContentFaqDetail', {
      uniqId: idFaq,
    })
  }

  press_search () {
    const {props} = this

    props.dispatch(get_listFaq())
  }

  render () {
    const {props} = this

    return (
      <Container>
        <CustomHeader
          navigation={props.navigation}
          noRight={true} />

        <Col>
          <Row style={{backgroundColor: '#e4e4e4', height: 100, justifyContent: 'center', alignItems: 'center'}}>
            <Text style={{fontWeight: 'bold', fontSize: 22, letterSpacing: 5, textTransform: 'uppercase'}}>
              {language[props.language].title.help_label}
            </Text>
          </Row>

          <Row style={{padding: 15, height: 'auto'}}>
            <Col>
              <Item regular={true}>
                <CustomInput
                  onChangeText={this.change_input}
                  name="textSearch"
                  placeholder={language[props.language].title.help_search_placeholder}
                  placeholderTextColor="#707070"
                  style={{fontSize: 14, height: 40}}
                  value={props.textSearch} />

                {props.textSearch !== '' ? (
                  <TouchableOpacity onPress={this.press_clearSearch} style={{height: 40, width: 48, justifyContent: 'center', alignItems: 'center'}}>
                    <Icon style={{color: '#707070', fontSize: 16}} name="times" type="FontAwesome5" />
                  </TouchableOpacity>
                ) : null}
                <TouchableOpacity onPress={this.press_search} style={{backgroundColor: '#075e54', height: 40, width: 48, justifyContent: 'center', alignItems: 'center'}}>
                  <Icon style={{color: '#f4f4f4f4', fontSize: 16}} name="search" type="FontAwesome5" />
                </TouchableOpacity>
              </Item>
            </Col>
          </Row>

          {props.faq.length === 0 ? (
            <Col style={{alignItems: 'center', paddingTop: 50}}>
              <Text style={{color: '#202020', fontSize: 14}}>
                {language[props.language].title.empty_search.replace('[title]', language[props.language].menu.drawer_help.toLowerCase())}
              </Text>
            </Col>
          ) : (
            <Content>
              <Col style={{paddingHorizontal: 15}}>
                {props.faq.map(item => (
                  <TouchableOpacity key={`listfaq-${item.id}`} onPress={() => this.press_detailFaq(item.id)} style={{marginBottom: 15, borderColor: '#202020', borderWidth: 0.3, borderRadius: 5}}>
                    <Row style={{padding: 15, height: 100, alignItems: 'center'}}>
                      <Row>
                        <Text style={{fontSize: 16}}>{item.title}</Text>
                      </Row>
                      <Row style={{flex: 0}}>
                        <Icon style={{color: '#202020', fontSize: 16}} name="chevron-right" type="FontAwesome5" />
                      </Row>
                    </Row>
                  </TouchableOpacity>
                ))}

                <Row style={{justifyContent: 'center', marginTop: 20}}>
                  <Text style={{color: '#202020', fontSize: 20, fontWeight: 'bold', letterSpacing: 1}}>Yoga</Text>
                  <Text style={{color: '#202020', fontSize: 20, textTransform: 'uppercase', letterSpacing: 1}}>Indo</Text>
                </Row>
                <View style={{width: '100%', padding: 5, borderBottomColor: '#666666', borderBottomWidth: 1}} />
                <Row style={{justifyContent: 'center', marginVertical: 10}}>
                  <Text style={{fontSize: 10, color: '#666666'}}>v 4.3.7</Text>
                </Row>
              </Col>
            </Content>
          )}
        </Col>
      </Container>
    )
  }
}

ContentFaqList.defaultProps = {
  language: 'EN',
}

const mapStateToProps = state => ({
  language: state.userRdc.userMeInfo.language,
  faq: state.contentRdc.faq,
  textSearch: state.filterRdc.faq_textSearch,
})

export default connect(mapStateToProps)(ContentFaqList)
