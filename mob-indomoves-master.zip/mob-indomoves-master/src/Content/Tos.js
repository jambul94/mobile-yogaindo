import React from 'react'
import HTMLView from 'react-native-htmlview'
import {Col, Container, Content, Row, Spinner, Text} from 'native-base'
import {CustomHeader} from '../_component'
import {NavigationEvents} from 'react-navigation'
import {connect} from 'react-redux'
import {get_detailTos} from '../_actions/content'
import {language} from '../_common/language'

class ContentTos extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      contentLoading: true,
    }

    this._didFocus = this._didFocus.bind(this)
  }

  _didFocus () {
    this.get_contentTos()
  }

  toggle_contentLoading (nextMode, callbk) {
    this.setState({
      contentLoading: nextMode,
    }, callbk && callbk())
  }

  get_contentTos () {
    const {props} = this

    props.dispatch(get_detailTos(() => {
        this.toggle_contentLoading(false)
      })
    )
  }

  render () {
    const {props, state} = this

    return (
      <Container>
        <NavigationEvents
          onDidFocus={this._didFocus} />

        <CustomHeader
          navigation={props.navigation} />

        {state.contentLoading ? (
          <Col style={{justifyContent: 'center'}}>
            <Spinner color="#075e54" />
          </Col>
        ) : (
          <Content>
            <Row style={{backgroundColor: '#e4e4e4', height: 100, justifyContent: 'center', alignItems: 'center'}}>
              <Text style={{fontWeight: 'bold', fontSize: 22, letterSpacing: 5, textTransform: 'uppercase'}}>
                {language[props.language].title.setting_tos}
              </Text>
            </Row>
            <Col style={{padding: 15}}>
              <HTMLView
                value={props.detailTos.content.replace(/\r\n/g, '')} />
            </Col>
          </Content>
        )}
      </Container>
    )
  }
}

const mapStateToProps = state => ({
  language: state.userRdc.userMeInfo.language,
  detailTos: state.contentRdc.detailTos,
})

export default connect(mapStateToProps)(ContentTos)
