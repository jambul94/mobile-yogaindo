import React from 'react'
import {Col, Container, Content, Row, Text} from 'native-base'
import {CustomHeader} from '../_component'
import {NavigationEvents} from 'react-navigation'
import {View} from 'react-native'
import {connect} from 'react-redux'
import {get_detailFaq} from '../_actions/content'

class ContentFaqDetail extends React.Component {
  constructor (props) {
    super(props)

    this._didFocus = this._didFocus.bind(this)
  }

  _didFocus () {
    this.req_detailFaq()
  }

  req_detailFaq () {
    const {props} = this
    const idFaq = props.navigation.getParam('uniqId')
    console.log(idFaq)
    props.dispatch(get_detailFaq(idFaq))
  }

  render () {
    const {props} = this

    return (
      <Container>
        <NavigationEvents
          onDidFocus={this._didFocus} />

        <CustomHeader
          navigation={props.navigation}
          noRight={true} />

        {props.detailFaq !== null ? (
          <Col style={{padding: 15}}>
            <Row style={{flex: 0}}>
              <Col style={{flex: 0, height: 100, width: 75, justifyContent: 'center', alignItems: 'center'}}>
                <Text style={{fontSize: 50, fontWeight: '700', color: '#075e54'}}>Q</Text>
              </Col>
              <Col style={{height: 100, justifyContent: 'center'}}>
                <Text style={{color: '#202020', fontSize: 16}}>{props.detailFaq.title}</Text>
              </Col>
            </Row>

            <Content>
              <Row style={{padding: 15, borderColor: '#202020', borderWidth: 0.3, borderRadius: 5, marginBottom: 50}}>
                <Text style={{fontSize: 14, color: '#202020', letterSpacing: 0.1}}>{props.detailFaq.description}</Text>
              </Row>
              <Row style={{justifyContent: 'center', marginTop: 20}}>
                <Text style={{color: '#202020', fontSize: 20, fontWeight: 'bold', letterSpacing: 1}}>Yoga</Text>
                <Text style={{color: '#202020', fontSize: 20, textTransform: 'uppercase', letterSpacing: 1}}>Indo</Text>
              </Row>
              <View style={{width: '100%', padding: 5, borderBottomColor: '#666666', borderBottomWidth: 1}} />
              <Row style={{justifyContent: 'center', marginVertical: 10}}>
                <Text style={{fontSize: 10, color: '#666666'}}>v 4.3.7</Text>
              </Row>
            </Content>
          </Col>
        ) : null}
      </Container>
    )
  }
}

const mapStateToProps = state => ({
  detailFaq: state.contentRdc.detailFaq,
})

export default connect(mapStateToProps)(ContentFaqDetail)
