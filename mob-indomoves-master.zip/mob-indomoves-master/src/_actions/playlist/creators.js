const playlistActions = {
  PLAYLIST_GET_LIST_SUCCESS: 'PLAYLIST_GET_LIST_SUCCESS',
  PLAYLIST_GET_DETAIL_SUCCESS: 'PLAYLIST_GET_DETAIL_SUCCESS',
  PLAYLIST_RESET_DETAIL: 'PLAYLIST_RESET_DETAIL',
}

const playlistCreators = {
  getListPlaylistSuccess: (listPlaylist) => ({
    type: playlistActions.PLAYLIST_GET_LIST_SUCCESS,
    payload: {listPlaylist},
  }),

  getPlaylistDetailSuccess: (detailPlaylist) => ({
    type: playlistActions.PLAYLIST_GET_DETAIL_SUCCESS,
    payload: {detailPlaylist},
  }),

  resetDetailPlaylist: () => ({
    type: playlistActions.PLAYLIST_RESET_DETAIL,
  }),
}

export {
  playlistActions,
  playlistCreators,
}
