import {apiClient, dotenv} from '../../_common/helper'
import {playlistCreators} from './creators'

const getDetailPlaylist = (uniqId, callbkSuccess, callbkError) => {
  const playlist = new apiClient()

  return dispatch => {
    dispatch(playlistCreators.resetDetailPlaylist())
    playlist.get(`${dotenv.BASE_URL}playlists/${uniqId}/`).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== null && data !== undefined) {
          dispatch(playlistCreators.getPlaylistDetailSuccess(data))
          callbkSuccess && callbkSuccess()
        }
      }
    }).catch(err => {
      dispatch(playlistCreators.resetDetailPlaylist())
      callbkError && callbkError()
      console.log(`Get detail playlist error: ${err}`)
    })
  }
}

const getListPlaylist = (callbkSuccess, callbkError) => {
  const playlist = new apiClient()

  return (dispatch, getState) => {
    const stateFilter = getState().filterRdc
    const params = {}

    if (stateFilter.playlist_sortValue !== null) {
      params.sort = stateFilter.playlist_sortValue
    }

    playlist.get(`${dotenv.BASE_URL}playlists/`, {params}).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== null && data.length > 0) {
          dispatch(playlistCreators.getListPlaylistSuccess(data))
          callbkSuccess && callbkSuccess()
        }
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Get list playlist error: ${err}`)
    })
  }
}

export {
  getDetailPlaylist,
  getListPlaylist,
}
