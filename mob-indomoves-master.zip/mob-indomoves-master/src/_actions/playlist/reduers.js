import {playlistActions} from './creators'

const initStateRdc = {
  playlist: [],
  detailPlaylist: null,
}

const playlistRdc = (state = initStateRdc, actions) => {
  switch (actions.type) {
    case playlistActions.PLAYLIST_GET_LIST_SUCCESS:
      return {
        ...state,
        playlist: actions.payload.listPlaylist,
      }

    case playlistActions.PLAYLIST_GET_DETAIL_SUCCESS:
      return {
        ...state,
        detailPlaylist: actions.payload.detailPlaylist,
      }

    case playlistActions.PLAYLIST_RESET_DETAIL:
      return {
        ...state,
        detailPlaylist: null,
      }
    default:
      return state
  }
}

export {
  playlistRdc,
}
