const filterActions = {
  FILTER_CLASS_SET_DIFFICULTY: 'FILTER_CLASS_SET_DIFFICULTY',
  FILTER_CLASS_SET_INSTRUCTOR: 'FILTER_CLASS_SET_INSTRUCTOR',
  FILTER_CLASS_SET_INTENSITY: 'FILTER_CLASS_SET_INTENSITY',
  FILTER_CLASS_SET_SORT: 'FILTER_CLASS_SET_SORT',
  FILTER_CLASS_SET_STYLES: 'FILTER_CLASS_SET_STYLES',
  FILTER_FAQ_SET_TEXTSEARCH: 'FILTER_FAQ_SET_TEXTSEARCH',
  FILTER_INSTRUCTOR_SET_SORT: 'FILTER_INSTRUCTOR_SET_SORT',
  FILTER_INSTRUCTOR_SERIES_SET_SORT: 'FILTER_INSTRUCTOR_SERIES_SET_SORT',
  FILTER_PLAYLIST_SET_SORT: 'FILTER_PLAYLIST_SET_SORT',
  FILTER_SERIES_SET_INSTRUCTOR: 'FILTER_SERIES_SET_INSTRUCTOR',
  FILTER_SERIES_SET_SORT: 'FILTER_SERIES_SET_SORT',
  FILTER_SERIES_SET_STYLES: 'FILTER_SERIES_SET_STYLES',
  FILTER_SERIES_SET_TEXTSEARCH: 'FILTER_SERIES_SET_TEXTSEARCH',
  FILTER_USER_CLASS_SET_SORT: 'FILTER_USER_CLASS_SET_SORT',
  FILTER_USER_SERIES_SET_SORT: 'FILTER_USER_SERIES_SET_SORT',
  FILTER_USER_PLAYLIST_SET_SORT: 'FILTER_USER_PLAYLIST_SET_SORT',
}

const filterCreators = {
  set_filterClassDifficulty: (listDifficultyValue, listDifficultyLabel) => ({
    type: filterActions.FILTER_CLASS_SET_DIFFICULTY,
    payload: {listDifficultyValue, listDifficultyLabel},
  }),

  set_filterClassInstructor: (listInstructorValue, listInstructorLabel) => ({
    type: filterActions.FILTER_CLASS_SET_INSTRUCTOR,
    payload: {listInstructorValue, listInstructorLabel},
  }),

  set_filterClassIntensity: (listIntensityValue, listIntensityLabel) => ({
    type: filterActions.FILTER_CLASS_SET_INTENSITY,
    payload: {listIntensityValue, listIntensityLabel},
  }),

  set_filterClassSort: (sortValue, sortLabel) => ({
    type: filterActions.FILTER_CLASS_SET_SORT,
    payload: {sortValue, sortLabel},
  }),

  set_filterClassStyle: (listStyleValue, listStyleLabel) => ({
    type: filterActions.FILTER_CLASS_SET_STYLES,
    payload: {listStyleValue, listStyleLabel},
  }),

  set_filterFaqTextSearch: (textSearch) => ({
    type: filterActions.FILTER_FAQ_SET_TEXTSEARCH,
    payload: {textSearch},
  }),

  set_filterInstructorSort: (sortValue, sortLabel) => ({
    type: filterActions.FILTER_INSTRUCTOR_SET_SORT,
    payload: {sortValue, sortLabel},
  }),

  set_filterInstructorSeriesSort: (sortValue, sortLabel) => ({
    type: filterActions.FILTER_INSTRUCTOR_SERIES_SET_SORT,
    payload: {sortValue, sortLabel},
  }),

  set_filterPlaylistSort: (sortValue, sortLabel) => ({
    type: filterActions.FILTER_PLAYLIST_SET_SORT,
    payload: {sortValue, sortLabel},
  }),

  set_filterSeriesInstructor: (listInstructorValue, listInstructorLabel) => ({
    type: filterActions.FILTER_SERIES_SET_INSTRUCTOR,
    payload: {listInstructorValue, listInstructorLabel},
  }),

  set_filterSeriesSort: (sortValue, sortLabel) => ({
    type: filterActions.FILTER_SERIES_SET_SORT,
    payload: {sortValue, sortLabel},
  }),

  set_filterSeriesStyles: (listStyleValue, listStyleLabel) => ({
    type: filterActions.FILTER_SERIES_SET_STYLES,
    payload: {listStyleValue, listStyleLabel},
  }),

  set_filterSeriesTextSearch: (textSearch) => ({
    type: filterActions.FILTER_SERIES_SET_TEXTSEARCH,
    payload: {textSearch},
  }),

  set_filterUserClassSort: (sortValue, sortLabel) => ({
    type: filterActions.FILTER_USER_CLASS_SET_SORT,
    payload: {sortValue, sortLabel},
  }),

  set_filterUserPlaylistSort: (sortValue, sortLabel) => ({
    type: filterActions.FILTER_USER_PLAYLIST_SET_SORT,
    payload: {sortValue, sortLabel},
  }),

  set_filterUserSeriesSort: (sortValue, sortLabel) => ({
    type: filterActions.FILTER_USER_SERIES_SET_SORT,
    payload: {sortValue, sortLabel},
  }),
}

export {
  filterActions,
  filterCreators,
}
