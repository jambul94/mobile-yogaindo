import {filterCreators} from './creators'

const set_filterClassDifficulty = (listValue, listLabel) => {
  return dispatch => {
    dispatch(filterCreators.set_filterClassDifficulty(listValue, listLabel))
  }
}

const set_filterClassInstructor = (listValue, listLabel) => {
  return dispatch => {
    dispatch(filterCreators.set_filterClassInstructor(listValue, listLabel))
  }
}

const set_filterClassIntensity = (listValue, listLabel) => {
  return dispatch => {
    dispatch(filterCreators.set_filterClassIntensity(listValue, listLabel))
  }
}

const set_filterClassSort = (sortValue, sortLabel) => {
  return dispatch => {
    dispatch(filterCreators.set_filterClassSort(sortValue, sortLabel))
  }
}

const set_filterClassStyle = (listValue, listLabel) => {
  return dispatch => {
    dispatch(filterCreators.set_filterClassStyle(listValue, listLabel))
  }
}

const set_filterFaqTextSearch = (textSearch) => {
  return disptach => {
    disptach(filterCreators.set_filterFaqTextSearch(textSearch))
  }
}

const set_filterInstructorSort = (sortValue, sortLabel) => {
  return dispatch => {
    dispatch(filterCreators.set_filterInstructorSort(sortValue, sortLabel))
  }
}

const set_filterInstructorSeriesSort = (sortValue, sortLabel) => {
  return dispatch => {
    dispatch(filterCreators.set_filterInstructorSeriesSort(sortValue, sortLabel))
  }
}

const set_filterPlaylistrSort = (sortValue, sortLabel) => {
  return dispatch => {
    dispatch(filterCreators.set_filterPlaylistSort(sortValue, sortLabel))
  }
}

const set_filterSeriesInstructor = (listValue, listLabel) => {
  return dispatch => {
    dispatch(filterCreators.set_filterSeriesInstructor(listValue, listLabel))
  }
}

const set_filterSeriesSort = (sortValue, sortLabel) => {
  return dispatch => {
    dispatch(filterCreators.set_filterSeriesSort(sortValue, sortLabel))
  }
}

const set_filterSeriesStyles = (listValue, listLabel) => {
  return dispatch => {
    dispatch(filterCreators.set_filterSeriesStyles(listValue, listLabel))
  }
}

const set_filterSeriesTextSearch = (textSearch) => {
  return disptach => {
    disptach(filterCreators.set_filterSeriesTextSearch(textSearch))
  }
}

const set_filterUserClassSort = (sortValue, sortLabel) => {
  return dispatch => {
    dispatch(filterCreators.set_filterUserClassSort(sortValue, sortLabel))
  }
}

const set_filterUserPlaylistSort = (sortValue, sortLabel) => {
  return dispatch => {
    dispatch(filterCreators.set_filterUserPlaylistSort(sortValue, sortLabel))
  }
}

const set_filterUserSeriesSort = (sortValue, sortLabel) => {
  return dispatch => {
    dispatch(filterCreators.set_filterUserSeriesSort(sortValue, sortLabel))
  }
}

export {
  set_filterClassDifficulty,
  set_filterClassInstructor,
  set_filterClassIntensity,
  set_filterClassSort,
  set_filterClassStyle,
  set_filterFaqTextSearch,
  set_filterInstructorSort,
  set_filterInstructorSeriesSort,
  set_filterPlaylistrSort,
  set_filterSeriesInstructor,
  set_filterSeriesSort,
  set_filterSeriesStyles,
  set_filterSeriesTextSearch,
  set_filterUserClassSort,
  set_filterUserPlaylistSort,
  set_filterUserSeriesSort,
}
