import {filterActions} from './creators'

const initStateRdc = {
  class_difficultyValue: [],
  class_difficultyLabel: [],
  class_instructorValue: [],
  class_instructorLabel: [],
  class_intensityValue: [],
  class_intensityLabel: [],
  class_sortValue: null,
  class_sortLabel: '',
  class_styleValue: [],
  class_styleLabel: [],
  faq_textSearch: '',
  instructor_sortValue: null,
  instructor_sortLabel: '',
  instructor_series_sortValue: null,
  instructor_series_sortLabel: '',
  playlist_sortValue: 'desc',
  playlist_sortLabel: '',
  series_instructorValue: [],
  series_instructorLabel: [],
  series_sortValue: null,
  series_sortLabel: '',
  series_stylesValue: [],
  series_stylesLabel: [],
  series_textSearch: '',
  userClass_sortValue: null,
  userClass_sortLabel: '',
  userSeries_sortValue: null,
  userSeries_sortLabel: '',
  userPlaylist_sortValue: null,
  userPlaylist_sortLabel: '',
}

const filterRdc = (state = initStateRdc, actions) => {
  switch (actions.type) {
    case filterActions.FILTER_CLASS_SET_DIFFICULTY:
      return {
        ...state,
        class_difficultyValue: actions.payload.listDifficultyValue,
        class_difficultyLabel: actions.payload.listDifficultyLabel,
      }

    case filterActions.FILTER_CLASS_SET_INSTRUCTOR:
      return {
        ...state,
        class_instructorValue: actions.payload.listInstructorValue,
        class_instructorLabel: actions.payload.listInstructorLabel,
      }

    case filterActions.FILTER_CLASS_SET_INTENSITY:
      return {
        ...state,
        class_intensityValue: actions.payload.listIntensityValue,
        class_intensityLabel: actions.payload.listIntensityLabel,
      }

    case filterActions.FILTER_CLASS_SET_SORT:
      return {
        ...state,
        class_sortValue: actions.payload.sortValue,
        class_sortLabel: actions.payload.sortLabel,
      }

    case filterActions.FILTER_CLASS_SET_STYLES:
      return {
        ...state,
        class_styleValue: actions.payload.listStyleValue,
        class_styleLabel: actions.payload.listStyleLabel,
      }

    case filterActions.FILTER_FAQ_SET_TEXTSEARCH:
      return {
        ...state,
        faq_textSearch: actions.payload.textSearch,
      }

    case filterActions.FILTER_INSTRUCTOR_SET_SORT:
      return {
        ...state,
        instructor_sortValue: actions.payload.sortValue,
        instructor_sortLabel: actions.payload.sortLabel,
      }

    case filterActions.FILTER_INSTRUCTOR_SERIES_SET_SORT:
      return {
        ...state,
        instructor_series_sortValue: actions.payload.sortValue,
        instructor_series_sortLabel: actions.payload.sortLabel,
      }

    case filterActions.FILTER_PLAYLIST_SET_SORT:
      return {
        ...state,
        playlist_sortValue: actions.payload.sortValue,
        playlist_sortLabel: actions.payload.sortLabel,
      }

    case filterActions.FILTER_SERIES_SET_INSTRUCTOR:
      return {
        ...state,
        series_instructorValue: actions.payload.listInstructorValue,
        series_instructorLabel: actions.payload.listInstructorLabel,
      }

    case filterActions.FILTER_SERIES_SET_SORT:
      return {
        ...state,
        series_sortValue: actions.payload.sortValue,
        series_sortLabel: actions.payload.sortLabel,
      }

    case filterActions.FILTER_SERIES_SET_STYLES:
      return {
        ...state,
        series_stylesValue: actions.payload.listStyleValue,
        series_stylesLabel: actions.payload.listStyleLabel,
      }

    case filterActions.FILTER_SERIES_SET_TEXTSEARCH:
      return {
        ...state,
        series_textSearch: actions.payload.textSearch,
      }

    case filterActions.FILTER_USER_CLASS_SET_SORT:
      return {
        ...state,
        userClass_sortValue: actions.payload.sortValue,
        userClass_sortLabel: actions.payload.sortLabel,
      }

    case filterActions.FILTER_USER_PLAYLIST_SET_SORT:
      return {
        ...state,
        userPlaylist_sortValue: actions.payload.sortValue,
        userPlaylist_sortLabel: actions.payload.sortLabel,
      }

    case filterActions.FILTER_USER_SERIES_SET_SORT:
      return {
        ...state,
        userSeries_sortValue: actions.payload.sortValue,
        userSeries_sortLabel: actions.payload.sortLabel,
      }

    default:
      return state
  }
}

export {
  filterRdc,
}
