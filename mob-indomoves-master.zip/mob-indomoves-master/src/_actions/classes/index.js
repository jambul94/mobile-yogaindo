import {apiClient, dotenv} from '../../_common/helper'
import {classCreators} from './creators'
import {get_listInstructorReward} from '../../_actions/instructor'
import {get_listUserReward} from '../../_actions/user'

const getDetailClass = (uniqId, callbkSuccess, callbkError) => {
  const classess = new apiClient();

  return dispatch => {
    dispatch(classCreators.resetDetailClass())
    classess.get(`${dotenv.BASE_URL}workouts/${uniqId}/`).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== null && data !== undefined) {
          dispatch(classCreators.getDetailClassSuccess(data))
          callbkSuccess && callbkSuccess()
        }
      }
    }).catch(err => {
      dispatch(classCreators.resetDetailClass())
      callbkError && callbkError()
      console.log(`Get detail classess error: ${err}`)
    })
  }
}

const getListClass = (callbkSuccess, callbkError) => {
  const classess = new apiClient()

  return (dispatch, getState) => {
    const stateFilter = getState().filterRdc
    const params = {}

    if (stateFilter.class_sortValue !== null) {
      params.sort = stateFilter.class_sortValue
    }

    if (stateFilter.class_difficultyValue.length > 0) {
      params.difficulty = stateFilter.class_difficultyValue
    }

    if (stateFilter.class_instructorValue.length > 0) {
      params.instructor = stateFilter.class_instructorValue
    }

    if (stateFilter.class_intensityValue.length > 0) {
      params.intensity = stateFilter.class_intensityValue
    }

    if (stateFilter.class_styleValue.length > 0) {
      params.styles = stateFilter.class_styleValue
    }

    classess.get(`${dotenv.BASE_URL}workouts/`, {params}).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== undefined && data !== null) {
          dispatch(classCreators.getListClassSuccess(data))
        }

        callbkSuccess && callbkSuccess()
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Get list classess error: ${err}`)
    })
  }
}

const getListClassComment = (idClass, callbkSuccess, callbkError) => {
  const classess = new apiClient()

  classess.get(`${dotenv.BASE_URL}comm-workouts/?workouts_id=${idClass}`).then(resp => {
    const {data, status} = resp

    if (status === 200) {
      callbkSuccess && callbkSuccess(data)
    }
  }).catch(err => {
    callbkError && callbkError()
    console.log(`Get list classess comment error: ${err}`)
  })
}

const post_pointPlayVideo = (idClass, callbkSuccess, callbkError) => {
  const classess = new apiClient()
  const formData = {
    workouts: idClass,
  }

  return dispatch => {
    return classess.post(`${dotenv.BASE_URL}workouts/student/join/`, formData).then(async resp => {
      const {status} = resp

      if (status === 200) {
        await dispatch(get_listInstructorReward())
        await dispatch(get_listUserReward())
        callbkSuccess && callbkSuccess()
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Post point play classess video error: ${err}`)
    })
  }
}

const post_ClassComment = (formData, callbkSuccess, callbkError) => {
  const classess = new apiClient()

  classess.post(`${dotenv.BASE_URL}comm-workouts/`, formData).then(resp => {
    const {status} = resp

    if (status === 201) {
      callbkSuccess && callbkSuccess()
    }
  }).catch(err => {
    callbkError && callbkError()
    console.log(`Post classess comment error: ${err}`)
  })
}

export {
  getDetailClass,
  getListClass,
  getListClassComment,
  post_pointPlayVideo,
  post_ClassComment,
}
