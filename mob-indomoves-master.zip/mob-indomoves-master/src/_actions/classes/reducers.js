import {classActions} from './creators'

const initStateRdc = {
  classess: [],
  detailClass: null,
}

const classRdc = (state = initStateRdc, actions) => {
  switch (actions.type) {
    case classActions.CLASS_GET_LIST_SUCCESS:
      return {
        ...state,
        classess: actions.payload.listClass,
      }

    case classActions.CLASS_GET_DETAIL_SUCCESS:
      return {
        ...state,
        detailClass: actions.payload.detailClass,
      }

    case classActions.CLASS_RESET_DETAIL:
      return {
        ...state,
        detailClass: null,
      }

    default:
      return state
  }
}

export {
  classRdc,
}
