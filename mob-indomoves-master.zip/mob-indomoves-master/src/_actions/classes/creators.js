const classActions = {
  CLASS_GET_LIST_SUCCESS: 'CLASS_GET_LIST_SUCCESS',
  CLASS_GET_DETAIL_SUCCESS: 'CLASS_GET_DETAIL_SUCCESS',
  CLASS_RESET_DETAIL : 'CLASS_RESET_DETAIL',
}

const classCreators = {
  getListClassSuccess: (listClass) => ({
    type: classActions.CLASS_GET_LIST_SUCCESS,
    payload: {listClass},
  }),

  getDetailClassSuccess: (detailClass) => ({
    type: classActions.CLASS_GET_DETAIL_SUCCESS,
    payload: {detailClass},
  }),

  resetDetailClass: () => ({
    type: classActions.CLASS_RESET_DETAIL,
  }),
}

export {
  classActions,
  classCreators,
}
