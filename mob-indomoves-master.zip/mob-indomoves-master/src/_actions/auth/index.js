import {axios, dotenv} from '../../_common/helper'

const postUserLogin = (formData = {}, callbkSuccess, callbkError) => {
  axios({
    url: `${dotenv.BASE_URL}login/`,
    method: 'post',
    data: {
      ...formData,
    },
  }).then(resp => {
    callbkSuccess && callbkSuccess(resp)
  }).catch(err => {
    if (err.response) {
      callbkError && callbkError(err.response)
    } else {
      callbkError && callbkError()
    }

    console.log(`User login error: ${err}`)
  })
}

const postUserRegister = (formData = {}, callbkSuccess, callbkError) => {
  axios({
    url: `${dotenv.BASE_URL}register/`,
    method: 'post',
    data: {
      ...formData,
    },
  }).then(resp => {
    callbkSuccess && callbkSuccess(resp)
  }).catch(err => {
    if (err.response) {
      callbkError && callbkError(err.response)
    } else {
      callbkError && callbkError()
    }

    console.log(`User register error: ${err}`)
  })
}

const postUserVerification = (formData = {}, callbkSuccess, callbkError) => {
  axios({
    url: `${dotenv.BASE_URL}login/verification/`,
    method: 'post',
    data: {
      ...formData,
    },
  }).then(resp => {
    callbkSuccess && callbkSuccess(resp)
  }).catch(err => {
    if (err.response) {
      callbkError && callbkError(err.response)
    } else {
      callbkError && callbkError()
    }

    console.log(`User verification error: ${err}`)
  })
}

export {
  postUserLogin,
  postUserRegister,
  postUserVerification,
}
