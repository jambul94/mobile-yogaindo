const instructorActions = {
  INSTRUCTOR_GET_LIST_SUCCESS: 'INSTRUCTOR_GET_LIST_SUCCESS',
  INSTRUCTOR_GET_LIST_REWARD_SUCCESS: 'INSTRUCTOR_GET_LIST_REWARD_SUCCESS',
  INSTRUCTOR_GET_LIST_SERIES_SUCCESS: 'INSTRUCTOR_GET_LIST_SERIES_SUCCESS',
  INSTRUCTOR_GET_DETAIL_SUCCESS: 'INSTRUCTOR_GET_DETAIL_SUCCESS',
  INSTRUCTOR_RESET_DETAIL: 'INSTRUCTOR_RESET_DETAIL',
}

const instructorCreators = {
  getListInstructorSuccess: (listInstructor) => ({
    type: instructorActions.INSTRUCTOR_GET_LIST_SUCCESS,
    payload: {listInstructor},
  }),

  getDetailInstructorSuccess: (detailInstructor) => ({
    type: instructorActions.INSTRUCTOR_GET_DETAIL_SUCCESS,
    payload: {detailInstructor},
  }),

  resetDetailInstructor: () => ({
    type: instructorActions.INSTRUCTOR_RESET_DETAIL,
  }),

  set_ListInstructorReward: (listInstructorReward) => ({
    type: instructorActions.INSTRUCTOR_GET_LIST_REWARD_SUCCESS,
    payload : {listInstructorReward},
  }),

  set_ListInstructorSeries: (listInstructorSeries) => ({
    type: instructorActions.INSTRUCTOR_GET_LIST_SERIES_SUCCESS,
    payload : {listInstructorSeries},
  }),
}

export {
  instructorActions,
  instructorCreators,
}
