import {apiClient, dotenv} from '../../_common/helper'
import {instructorCreators} from './creators'

const getDetailInstructor = (uniqId, callbkSuccess, callbkError) => {
  const instructor = new apiClient()

  return dispatch => {
    dispatch(instructorCreators.resetDetailInstructor())
    instructor.get(`${dotenv.BASE_URL}instructor/${uniqId}/`).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== null && data !== undefined) {
          dispatch(instructorCreators.getDetailInstructorSuccess(data))
          callbkSuccess && callbkSuccess()
        }
      }
    }).catch(err => {
      dispatch(instructorCreators.resetDetailInstructor())
      callbkError && callbkError()
      console.log(`Get detail instructor error: ${err}`)
    })
  }
}

const getListInstructor = (callbkSuccess, callbkError) => {
  const instructor = new apiClient()

  return (dispatch, getState) => {
    const stateFilter = getState().filterRdc
    const params = {}

    if (stateFilter.instructor_sortValue !== null) {
      params.sort = stateFilter.instructor_sortValue
    }

    instructor.get(`${dotenv.BASE_URL}instructor/`, {params}).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== null && data.length > 0) {
          dispatch(instructorCreators.getListInstructorSuccess(data))
          callbkSuccess && callbkSuccess()
        }
      }
     }).catch(err => {
      callbkError && callbkError()
      console.log(`Get list instructor error: ${err}`)
    })
  }
}

const get_listInstructorReward = (callbkSuccess, callbkError) => {
  const instructor = new apiClient()

  return dispatch => {
    return instructor.get(`${dotenv.BASE_URL}instructor/reward/`).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== null && data !== undefined) {
          dispatch(instructorCreators.set_ListInstructorReward(data))
          callbkSuccess && callbkSuccess()
        }
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Get list instructor reward error: ${err}`)
    })
  }
}

const get_listInstructorSeries = (uniqId, callbkSuccess, callbkError) => {
  const instructor = new apiClient()

  return (dispatch, getState) => {
    const stateFilter = getState().filterRdc
    const params = {}

    if (stateFilter.instructor_series_sortValue !== null) {
      params.sort = stateFilter.instructor_series_sortValue
    }

    return instructor.get(`${dotenv.BASE_URL}instructor/${uniqId}/series/`, {params}).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== null && data !== undefined) {
          dispatch(instructorCreators.set_ListInstructorSeries(data))
          callbkSuccess && callbkSuccess()
        }
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Get list instructor series error: ${err}`)
    })
  }
}

export {
  getDetailInstructor,
  getListInstructor,
  get_listInstructorReward,
  get_listInstructorSeries,
}
