import {instructorActions} from './creators'

const initStateRdc = {
  instructor: [],
  instructorSeries: [],
  instructorReward: [],
  detailInstructor: null,
}

const instructorRdc = (state = initStateRdc, actions) => {
  switch (actions.type) {
    case instructorActions.INSTRUCTOR_GET_LIST_SUCCESS:
      return {
        ...state,
        instructor: actions.payload.listInstructor,
      }

    case instructorActions.INSTRUCTOR_GET_LIST_REWARD_SUCCESS:
      return {
        ...state,
        instructorReward: actions.payload.listInstructorReward,
      }

    case instructorActions.INSTRUCTOR_GET_LIST_SERIES_SUCCESS:
      return {
        ...state,
        instructorSeries: actions.payload.listInstructorSeries,
      }

    case instructorActions.INSTRUCTOR_GET_DETAIL_SUCCESS:
      return {
        ...state,
        detailInstructor: actions.payload.detailInstructor,
      }

    case instructorActions.INSTRUCTOR_RESET_DETAIL:
      return {
        ...state,
        detailInstructor: null,
      }

    default:
      return state
  }
}

export {
  instructorRdc,
}
