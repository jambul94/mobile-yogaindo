import {apiClient, dotenv, axios, moment} from '../../_common/helper'
import {userCreators} from './creators'

const addClassToUserMe = (idClass, callbkSuccess, callbkError) => {
  const user = new apiClient()
  const formData = {
    object_id: idClass,
  }

  return dispatch => {
    user.post(`${dotenv.BASE_URL}users/me/workouts/`, formData).then(resp => {
      const {status} = resp

      if (status === 201) {
        callbkSuccess && callbkSuccess()
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Add class to user practice error: ${err}`)
    })
  }
}

const addPlaylistToUserMe = (idPlaylist, callbkSuccess, callbkError) => {
  const user = new apiClient()
  const formData = {
    object_id: idPlaylist,
  }

  return dispatch => {
    user.post(`${dotenv.BASE_URL}users/me/playlists/`, formData).then(resp => {
      const {status} = resp

      if (status === 201) {
        callbkSuccess && callbkSuccess()
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Add series to user practice error: ${err}`)
    })
  }
}

const addSeriesToUserMe = (idSeries, callbkSuccess, callbkError) => {
  const user = new apiClient()
  const formData = {
    object_id: idSeries,
  }

  return dispatch => {
    user.post(`${dotenv.BASE_URL}users/me/series/`, formData).then(resp => {
      const {status} = resp

      if (status === 201) {
        callbkSuccess && callbkSuccess()
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Add series to user practice error: ${err}`)
    })
  }
}

const delete_classFromUserMe = (idClass, callbkSuccess, callbkError) => {
  const user = new apiClient()

  return dispatch => {
    user.delete(`${dotenv.BASE_URL}users/me/workouts/${idClass}/`).then(resp => {
      const {status} = resp

      if (status === 204) {
        dispatch(getUserMeClass())
        callbkSuccess && callbkSuccess()
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Remove class from user practice error: ${err}`)
    })
  }
}

const delete_seriesFromUserMe = (idSeries, callbkSuccess, callbkError) => {
  const user = new apiClient()

  return dispatch => {
    user.delete(`${dotenv.BASE_URL}users/me/series/${idSeries}/`).then(resp => {
      const {status} = resp

      if (status === 204) {
        dispatch(getUserMeSeries())
        callbkSuccess && callbkSuccess()
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Remove series from user practice error: ${err}`)
    })
  }
}

const delete_playlistFromUserMe = (idPLaylist, callbkSuccess, callbkError) => {
  const user = new apiClient()

  return dispatch => {
    user.delete(`${dotenv.BASE_URL}users/me/playlists/${idPLaylist}/`).then(resp => {
      const {status} = resp

      if (status === 204) {
        dispatch(getuserMePlaylist())
        callbkSuccess && callbkSuccess()
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Remove playlists from user practice error: ${err}`)
    })
  }
}

const get_listUserNotification = (callbkSuccess, callbkError) => {
  const user = new apiClient()
  const listNotification = user.get(`${dotenv.BASE_URL}users/me/notifications/`)
  const countUnredNotification = user.get(`${dotenv.BASE_URL}users/me/notifications/unread_count/`)

  return dispatch => {
    return Promise.all([listNotification, countUnredNotification]).then(axios.spread((resp_listNotification, resp_countUnredNotification) => {
      const resp_notif = {
        data: resp_listNotification.data,
        status: resp_listNotification.status,
      }

      const resp_count = {
        data: resp_countUnredNotification.data,
        status: resp_countUnredNotification.status,
      }

      if (resp_notif.status === 200 && resp_count.status === 200) {
        if (resp_notif.data !== undefined && resp_notif.data !== null && resp_count.data !== undefined && resp_count.data !== null) {
          dispatch(userCreators.setUserMeNotification(resp_notif.data, resp_count.data.unread_count))
        }

        callbkSuccess && callbkSuccess()
      }
    })).catch(err => {
      callbkError && callbkError()
      console.log(`Get list user notification error: ${err}`)
    })
  }
}

const get_listUserReward = (callbkSuccess, callbkError) => {
  const user = new apiClient()

  return dispatch => {
    return user.get(`${dotenv.BASE_URL}workouts/student/`).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== null && data !== undefined) {
          dispatch(userCreators.set_listUserReward(data))
          callbkSuccess && callbkSuccess()
        }
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Get list user student reward error: ${err}`)
    })
  }
}

const getUserMeInfo = (callbkSuccess, callbkError) => {
  const user = new apiClient()

  return dispatch => {
    user.get(`${dotenv.BASE_URL}users/me/`).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== null && data !== undefined) {
          dispatch(userCreators.setUserMeInfo(data))
          callbkSuccess && callbkSuccess()
        }
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Get user me indo error: ${err}`)
    })
  }
}

const getUserMeClass = (callbkSuccess, callbkError) => {
  const user = new apiClient()

  return (dispatch, getState) => {
    const stateFilter = getState().filterRdc
    const params = {}

    if (stateFilter.userClass_sortValue !== null) {
      params.sort = stateFilter.userClass_sortValue
    }

    user.get(`${dotenv.BASE_URL}users/me/workouts/`, {params}).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== null && data.length > 0) {
          dispatch(userCreators.setUserMeClass(data))
        } else {
          dispatch(userCreators.setUserMeClass([]))
        }

        callbkSuccess && callbkSuccess()
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Get user me class error ${err}`)
    })
  }
}

const getUserMeSeries = (callbkSuccess, callbkError) => {
  const user = new apiClient()

  return (dispatch, getState) => {
    const stateFilter = getState().filterRdc
    const params = {}

    if (stateFilter.userSeries_sortValue !== null) {
      params.sort = stateFilter.userSeries_sortValue
    }

    user.get(`${dotenv.BASE_URL}users/me/series/`, {params}).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== null && data.length > 0) {
          dispatch(userCreators.setUserMeSeries(data))
        } else {
          dispatch(userCreators.setUserMeSeries([]))
        }

        callbkSuccess && callbkSuccess()
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Get user me series error ${err}`)
    })
  }
}

const getuserMePlaylist = (callbkSuccess, callbkError) => {
  const user = new apiClient()

  return (dispatch, getState) => {
    const stateFilter = getState().filterRdc
    const params = {}

    if (stateFilter.userPlaylist_sortValue !== null) {
      params.sort = stateFilter.userPlaylist_sortValue
    }

    return user.get(`${dotenv.BASE_URL}users/me/playlists/`, {params}).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== null && data.length > 0) {
          dispatch(userCreators.setUserMePlaylist(data))
        } else {
          dispatch(userCreators.setUserMePlaylist([]))
        }

        callbkSuccess && callbkSuccess()
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Get user me playlist error ${err}`)
    })
  }
}

const update_notificationToRead = (formData, callbkSuccess, callbkError) => {
  const user = new apiClient()

  return dispatch => {
    return user.put(`${dotenv.BASE_URL}/users/me/notifications/mark_as_read/`, formData).then(resp => {
      const {status} = resp

      if (status === 200) {
        dispatch(get_listUserNotification())
        callbkSuccess && callbkSuccess()
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Update read notification error: ${err}`)
    })
  }
}

const update_userMeInfo = (formData, callbkSuccess, callbkError) => {
  const user = new apiClient()
  const fixFormData = new FormData()
  const apiConfigs = {
    headers: {'Content-Type': 'multipart/form-data'},
  }

  if (formData.name !== null && formData.name !== undefined) {
    fixFormData.append('name', formData.name)
  }

  if (formData.address !== null && formData.address !== undefined) {
    fixFormData.append('address', formData.address)
  }

  if (formData.about !== null && formData.about !== undefined) {
    fixFormData.append('about', formData.about)
  }

  if (formData.email !== null && formData.email !== undefined) {
    fixFormData.append('email', formData.email)
  }

  if (formData.gender !== null && formData.gender !== undefined) {
    fixFormData.append('gender', formData.gender)
  }

  if (formData.distance_unit !== null && formData.distance_unit !== undefined) {
    fixFormData.append('distance_unit', formData.distance_unit)
  }

  if (formData.language !== null && formData.language !== undefined) {
    fixFormData.append('language', formData.language)
  }

  if (formData.photo !== null && formData.photo !== undefined) {
    fixFormData.append(
      'photo',
      {uri: formData.photo, type: 'image/jpg', name: `${formData.name} - ${moment().format('YYYY-MM-HH')}.jpg`})
  }

  return dispatch => {
    return user.put(`${dotenv.BASE_URL}users/me/`, fixFormData, apiConfigs).then(resp => {
      const {status} = resp

      if (status === 200) {
        dispatch(getUserMeInfo())
        callbkSuccess && callbkSuccess()
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Update user me info error: ${err}`)
    })
  }
}

export {
  addClassToUserMe,
  addPlaylistToUserMe,
  addSeriesToUserMe,
  delete_classFromUserMe,
  delete_playlistFromUserMe,
  delete_seriesFromUserMe,
  get_listUserNotification,
  get_listUserReward,
  getUserMeInfo,
  getUserMeClass,
  getUserMeSeries,
  getuserMePlaylist,
  update_notificationToRead,
  update_userMeInfo,
}
