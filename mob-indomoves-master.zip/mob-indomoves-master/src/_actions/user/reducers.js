import {userActions} from './creators'

const initStateRdc = {
  userReward: [],
  userMeInfo: null,
  userMeClass: [],
  userMeNotification: [],
  userMeNotificationUnreadCount: 0,
  userMeSeries: [],
  userMePlaylist: [],
  // userMeSubscribeStatus: false,
}

const userRdc = (state = initStateRdc, actions) => {
  switch (actions.type) {
    case userActions.USER_GET_LIST_REWARD_SUCCESS:
      return {
        ...state,
        userReward: actions.payload.listUserReward,
      }

    case userActions.USER_ME_GET_INFO_SUCCESS:
      return {
        ...state,
        userMeInfo: actions.payload.userMeInfo,
      }

      case userActions.USER_ME_GET_CLASS_SUCCESS:
        return {
          ...state,
          userMeClass: actions.payload.userMeClass,
        }

      case userActions.USER_ME_GET_NOTIF_SUCCESS:
        return {
          ...state,
          userMeNotification: actions.payload.userMeNotif,
          userMeNotificationUnreadCount: actions.payload.countUnread,
        }

      case userActions.USER_ME_GET_SERIES_SUCCESS:
        return {
          ...state,
          userMeSeries: actions.payload.userMeSeries,
        }

      case userActions.USER_ME_GET_PLAYLIST_SUCCESS:
        return {
          ...state,
          userMePlaylist: actions.payload.userMePlaylist,
        }

    default:
      return state
  }
}

export {
  userRdc,
}
