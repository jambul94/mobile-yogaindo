const userActions = {
  USER_GET_LIST_REWARD_SUCCESS: 'USER_GET_LIST_REWARD_SUCCESS',
  USER_ME_GET_INFO_SUCCESS: 'USER_ME_GET_INFO_SUCCESS',
  USER_ME_GET_CLASS_SUCCESS: 'USER_ME_GET_CLASS_SUCCESS',
  USER_ME_GET_NOTIF_SUCCESS: 'USER_ME_GET_NOTIF_SUCCESS',
  USER_ME_GET_SERIES_SUCCESS: 'USER_ME_GET_SERIES_SUCCESS',
  USER_ME_GET_PLAYLIST_SUCCESS: 'USER_ME_GET_PLAYLIST_SUCCESS',
}

const userCreators = {
  setUserMeInfo: (userMeInfo) => ({
    type: userActions.USER_ME_GET_INFO_SUCCESS,
    payload: {userMeInfo},
  }),

  setUserMeClass: (userMeClass) => ({
    type: userActions.USER_ME_GET_CLASS_SUCCESS,
    payload: {userMeClass},
  }),

  setUserMeNotification: (userMeNotif, countUnread) => ({
    type: userActions.USER_ME_GET_NOTIF_SUCCESS,
    payload: {userMeNotif, countUnread},
  }),

  setUserMeSeries: (userMeSeries) => ({
    type: userActions.USER_ME_GET_SERIES_SUCCESS,
    payload: {userMeSeries},
  }),

  setUserMePlaylist: (userMePlaylist) => ({
    type: userActions.USER_ME_GET_PLAYLIST_SUCCESS,
    payload: {userMePlaylist},
  }),

  set_listUserReward: (listUserReward) => ({
    type: userActions.USER_GET_LIST_REWARD_SUCCESS,
    payload: {listUserReward},
  }),
}

export {
  userActions,
  userCreators,
}
