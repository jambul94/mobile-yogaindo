import {apiClient, dotenv} from '../../_common/helper'
import {categoriesCreators} from './creators'

const getListCategories = (callbkSuccess, callbkError) => {
  const categories = new apiClient()

  return dispatch => {
    categories.get(`${dotenv.BASE_URL}categories/`).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== null && data.length > 0) {
          dispatch(categoriesCreators.getListCategoriesSuccess(data))
          callbkSuccess && callbkSuccess()
        }
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Get list categories error: ${err}`)
    })
  }
}

const get_listCategoriesStyle = (callbkSuccess, callbkError) => {
  const categories = new apiClient()

  return dispatch => {
    return categories.get(`${dotenv.BASE_URL}categories/styles/`).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== undefined && data !== null) {
          dispatch(categoriesCreators.set_listCategoriesStyleSuccess(data))
        }

        callbkSuccess && callbkSuccess()
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Get list categories style error: ${err}`)
    })
  }
}

export {
  getListCategories,
  get_listCategoriesStyle,
}
