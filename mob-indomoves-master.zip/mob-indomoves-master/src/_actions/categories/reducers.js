import {categoriesActions} from './creators'

const inistStateRdc = {
  categories: [],
  categoriesStyle: [],
}

const categoriesRdc = (state = inistStateRdc, actions) => {
  switch (actions.type) {
    case categoriesActions.CAT_GET_LIST_SUCCESS:
      return {
        ...state,
        categories: actions.payload.listCategories,
      }

    case categoriesActions.CAT_GET_LIST_STYLE_SUCCESS:
      return {
        ...state,
        categoriesStyle: actions.payload.listCategoriesStyle,
      }

    default:
      return state
  }
}

export {
  categoriesRdc,
}
