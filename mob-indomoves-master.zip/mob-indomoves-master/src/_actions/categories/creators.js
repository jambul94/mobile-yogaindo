const categoriesActions = {
  CAT_GET_LIST_SUCCESS: 'CAT_GET_LIST_SUCCESS',
  CAT_GET_LIST_STYLE_SUCCESS: 'CAT_GET_LIST_STYLE_SUCCESS',
}

const categoriesCreators = {
  getListCategoriesSuccess: (listCategories) => ({
    type: categoriesActions.CAT_GET_LIST_SUCCESS,
    payload: {listCategories},
  }),

  set_listCategoriesStyleSuccess: (listCategoriesStyle) => ({
    type: categoriesActions.CAT_GET_LIST_STYLE_SUCCESS,
    payload: {listCategoriesStyle},
  }),
}

export {
  categoriesActions,
  categoriesCreators,
}
