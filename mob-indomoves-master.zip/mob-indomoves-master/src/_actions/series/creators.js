const seriesActions = {
  SERIES_GET_LIST_SUCCESS: 'SERIES_GET_LIST_SUCCESS',
  SERIES_GET_DETAIL_SUCCESS: 'SERIES_GET_DETAIL_SUCCESS',
  SERIES_RESET_DETAIL: 'SERIES_RESET_DETAIL',
}

const seriesCreators = {
  getListSeriesSuccess: (listSeries) => ({
    type: seriesActions.SERIES_GET_LIST_SUCCESS,
    payload: {listSeries},
  }),

  getDetailseriesSuccess: (detailSeries) => ({
    type: seriesActions.SERIES_GET_DETAIL_SUCCESS,
    payload: {detailSeries},
  }),

  resetDetailSeries: () => ({
    type: seriesActions.SERIES_RESET_DETAIL,
  }),
}

export {
  seriesActions,
  seriesCreators,
}
