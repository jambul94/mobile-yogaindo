import {apiClient, dotenv} from '../../_common/helper'
import {seriesCreators} from './creators'

const getDetailSeries = (uniqId, callbkSuccess, callbkError) => {
  const series = new apiClient()

  return dispatch => {
    dispatch(seriesCreators.resetDetailSeries())
    series.get(`${dotenv.BASE_URL}series/${uniqId}/`).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== null && data !== undefined) {
          dispatch(seriesCreators.getDetailseriesSuccess(data))
          callbkSuccess && callbkSuccess()
        }
      }
    }).catch(err => {
      dispatch(seriesCreators.resetDetailSeries())
      callbkError && callbkError()
      console.log(`Get detail series error: ${err}`)
    })
  }
}

const getListSeriesByCategories = (uniqId, callbkSuccess, callbkError) => {
  const series = new apiClient()

  return (dispatch, getState) => {
    const stateFilter = getState().filterRdc
    const params = {}

    if (stateFilter.series_sortValue !== null) {
      params.sort = stateFilter.series_sortValue
    }

    if (stateFilter.series_instructorValue.length > 0) {
      params.instructor = stateFilter.series_instructorValue
    }

    if (stateFilter.series_stylesValue.length > 0) {
      params.styles = stateFilter.series_stylesValue
    }

    series.get(`${dotenv.BASE_URL}categories/${uniqId}/series/`, {params}).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== null) {
          dispatch(seriesCreators.getListSeriesSuccess(data))
          callbkSuccess && callbkSuccess()
        }
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Get list series error: ${err}`)
    })
  }
}

const getListSeriesComment = (idClass, callbkSuccess, callbkError) => {
  const classess = new apiClient()

  classess.get(`${dotenv.BASE_URL}comm-series/?series_id=${idClass}`).then(resp => {
    const {data, status} = resp

    if (status === 200) {
      callbkSuccess && callbkSuccess(data)
    }
  }).catch(err => {
    callbkError && callbkError()
    console.log(`Get list series comment error: ${err}`)
  })
}

const post_SeriesComment = (formData, callbkSuccess, callbkError) => {
  const classess = new apiClient()

  classess.post(`${dotenv.BASE_URL}comm-series/`, formData).then(resp => {
    const {status} = resp

    if (status === 201) {
      callbkSuccess && callbkSuccess()
    }
  }).catch(err => {
    callbkError && callbkError()
    console.log(`Post series comment error: ${err}`)
  })
}

export {
  getDetailSeries,
  getListSeriesByCategories,
  getListSeriesComment,
  post_SeriesComment,
}
