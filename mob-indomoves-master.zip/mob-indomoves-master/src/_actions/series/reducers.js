import {seriesActions} from './creators'

const initStateRdc = {
  series: [],
  detailSeries: null,
}

const seriesRdc = (state = initStateRdc, actions) => {
  switch (actions.type) {
    case seriesActions.SERIES_GET_LIST_SUCCESS:
      return {
        ...state,
        series: actions.payload.listSeries,
      }

    case seriesActions.SERIES_GET_DETAIL_SUCCESS:
      return {
        ...state,
        detailSeries: actions.payload.detailSeries,
      }

    case seriesActions.SERIES_RESET_DETAIL:
      return {
        ...state,
        detailSeries: null,
      }

    default:
      return state
  }
}

export {
  seriesRdc,
}
