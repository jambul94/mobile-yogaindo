import {apiClient, dotenv} from '../../_common/helper'
import {contentCreators} from './creators'

const get_listBanner = (callbkSuccess, callbkError) => {
  const content = new apiClient()

  return dispatch => {
    return content.get(`${dotenv.BASE_URL}banners/`).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== null && data !== undefined) {
          dispatch(contentCreators.set_listBanner(data))
        }

        callbkSuccess && callbkSuccess()
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Get list banner error: ${err}`)
    })
  }
}

const get_listDifficulty = (callbkSuccess, callbkError) => {
  const content = new apiClient()

  return dispatch => {
    return content.get(`${dotenv.BASE_URL}difficulty/`).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== null && data !== undefined) {
          dispatch(contentCreators.set_listDifficulty(data))
        }

        callbkSuccess && callbkSuccess()
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Get list difficulty error: ${err}`)
    })
  }
}

const get_listFaq = (callbkSuccess, callbkError) => {
  const content = new apiClient()

  return (dispatch, getState) => {
    const stateFilter = getState().filterRdc
    const params = {}

    if (stateFilter.faq_textSearch !== '') {
      params.q = stateFilter.faq_textSearch
    }

    return content.get(`${dotenv.BASE_URL}help/`, {params}).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== null && data !== undefined) {
          dispatch(contentCreators.set_listFaq(data))
        }

        callbkSuccess && callbkSuccess()
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Get list faq error: ${err}`)
    })
  }
}

const get_listIntensity = (callbkSuccess, callbkError) => {
  const content = new apiClient()

  return dispatch => {
    return content.get(`${dotenv.BASE_URL}intensity/`).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== null && data !== undefined) {
          dispatch(contentCreators.set_listIntensity(data))
        }

        callbkSuccess && callbkSuccess()
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Get list intensity error: ${err}`)
    })
  }
}

const get_listSearchSeries = (callbkSuccess, callbkError) => {
  const content = new apiClient()

  return (dispatch, getState) => {
    const stateFilter = getState().filterRdc
    const params = {}

    if (stateFilter.series_textSearch !== '') {
      params.q = stateFilter.series_textSearch
    }

    return content.get(`${dotenv.BASE_URL}series/`, {params}).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== null && data !== undefined) {
          dispatch(contentCreators.set_listSeriesSearch(data))
        }

        callbkSuccess && callbkSuccess()
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Get list search series error: ${err}`)
    })
  }
}

const get_listSosmed = (callbkSuccess, callbkError) => {
  const content = new apiClient()

  return dispatch => {
    return content.get(`${dotenv.BASE_URL}preferences/`).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== null && data !== undefined) {
          dispatch(contentCreators.set_listSosmed(data))
        }

        callbkSuccess && callbkSuccess()
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Get list social media error: ${err}`)
    })
  }
}

const get_listSubscribePackage = (callbkSuccess, callbkError) => {
  const content = new apiClient()

  return dispatch => {
    return content.get(`${dotenv.BASE_URL}subscribe-packages/`).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== null && data !== undefined) {
          dispatch(contentCreators.set_listSubscribePackage(data))
        }

        callbkSuccess && callbkSuccess()
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Get list subscribe package error: ${err}`)
    })
  }
}

const get_detailFaq = (idFaq, callbkSuccess, callbkError) => {
  const content = new apiClient()

  return dispatch => {
    return content.get(`${dotenv.BASE_URL}help/${idFaq}/`).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== null && data !== undefined) {
          dispatch(contentCreators.set_detailFaq(data))
        }

        callbkSuccess && callbkSuccess()
      }
    }).catch(err => {
      dispatch(contentCreators.set_detailFaq(null))
      callbkError && callbkError()
      console.log(`Get detail faq error: ${err}`)
    })
  }
}

const get_detailPolice = (callbkSuccess, callbkError) => {
  const content = new apiClient()

  return dispatch => {
    return content.get(`${dotenv.BASE_URL}privacy-policy/`).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== undefined && data !== null) {
          dispatch(contentCreators.set_detailPolice(data))
        }

        callbkSuccess && callbkSuccess()
      }
    }).catch(err => {
      dispatch(contentCreators.set_detailPolice(null))
      callbkError && callbkError()
      console.log(`Get detail privacy police error: ${err}`)
    })
  }
}

const get_detailTos = (callbkSuccess, callbkError) => {
  const content = new apiClient()

  return dispatch => {
    return content.get(`${dotenv.BASE_URL}toc/`).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        if (data !== undefined && data !== null) {
          dispatch(contentCreators.set_detailTos(data))
        }

        callbkSuccess && callbkSuccess()
      }
    }).catch(err => {
      dispatch(contentCreators.set_detailTos(null))
      callbkError && callbkError()
      console.log(`Get detail term of service error: ${err}`)
    })
  }
}

const get_detailVoucher = (params, callbkSuccess, callbkError) => {
  const content = new apiClient()

  return dispatch => {
    return content.get(`${dotenv.BASE_URL}voucher-validate/`, {params}).then(resp => {
      const {data, status} = resp

      if (status === 200) {
        callbkSuccess && callbkSuccess(data)
      }
    }).catch(err => {
      callbkError && callbkError(err)
      console.log(`Get detail voucher package error: ${err}`)
    })
  }
}

const post_subscribeCharge = (formData, callbkSuccess, callbkError) => {
  const content = new apiClient()

  return dispatch => {
    return content.post(`${dotenv.BASE_URL}subscribe-charges/`, formData).then(resp => {
      const {data, status} = resp

      if (status === 201) {
        callbkSuccess && callbkSuccess(data)
      }
    }).catch(err => {
      callbkError && callbkError()
      console.log(`Post subscribe payment error: ${err}`)
    })
  }
}

export {
  get_detailFaq,
  get_detailPolice,
  get_detailTos,
  get_detailVoucher,
  get_listBanner,
  get_listDifficulty,
  get_listFaq,
  get_listIntensity,
  get_listSearchSeries,
  get_listSosmed,
  get_listSubscribePackage,
  post_subscribeCharge,
}
