import {contentActions} from './creators'

const initStateRdc = {
  banner: [],
  difficulty: [],
  faq: [],
  intensity: [],
  detailFaq: null,
  detailPolice: null,
  detailTos: null,
  searchSeries: [],
  sosmed: [],
  subscribePackage: [],
}

const contentRdc = (state = initStateRdc, actions) => {
  switch (actions.type) {
    case contentActions.CONTENT_GET_DETAIL_FAQ_SUCCESS:
      return {
        ...state,
        detailFaq: actions.payload.detailFaq,
      }

    case contentActions.CONTENT_GET_DETAIL_POLICE_SUCCESS:
      return {
        ...state,
        detailPolice: actions.payload.detailPolice,
      }


    case contentActions.CONTENT_GET_DETAIL_TOS_SUCCESS:
      return {
        ...state,
        detailTos: actions.payload.detailTos,
      }

    case contentActions.CONTENT_GET_LIST_BANNER_SUCCESS:
      return {
        ...state,
        banner: actions.payload.listBanner,
      }

    case contentActions.CONTENT_GET_LIST_FAQ_SUCCESS:
      return {
        ...state,
        faq: actions.payload.listFaq,
      }

    case contentActions.CONTENT_GET_LIST_INTENSITY_SUCCESS:
      return {
        ...state,
        intensity: actions.payload.listIntensity,
      }

    case contentActions.CONTENT_GET_LIST_DIFFICULTY_SUCCESS:
      return {
        ...state,
        difficulty: actions.payload.listDifficulty,
      }

    case contentActions.CONTENT_GET_LIST_SERIES_SEARCH_SUCCESS:
      return {
        ...state,
        searchSeries: actions.payload.listSeriesSearch,
      }

    case contentActions.CONTENT_GET_LIST_SOSMED_SUCCESS:
      return {
        ...state,
        sosmed: actions.payload.listSosmed,
      }

    case contentActions.CONTENT_GET_LIST_SUBSCRIBE_PACKAGE_SUCCESS:
      return {
        ...state,
        subscribePackage: actions.payload.listPackage,
      }

    default:
      return state
  }
}

export {
  contentRdc,
}
