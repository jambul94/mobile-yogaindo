const contentActions = {
  CONTENT_GET_DETAIL_FAQ_SUCCESS: 'CONTENT_GET_DETAIL_FAQ_SUCCESS',
  CONTENT_GET_DETAIL_POLICE_SUCCESS: 'CONTENT_GET_DETAIL_POLICE_SUCCESS',
  CONTENT_GET_DETAIL_TOS_SUCCESS: 'CONTENT_GET_DETAIL_TOS_SUCCESS',
  CONTENT_GET_LIST_BANNER_SUCCESS: 'CONTENT_GET_LIST_BANNER_SUCCESS',
  CONTENT_GET_LIST_DIFFICULTY_SUCCESS: 'CONTENT_GET_LIST_DIFFICULTY_SUCCESS',
  CONTENT_GET_LIST_FAQ_SUCCESS: 'CONTENT_GET_LIST_FAQ_SUCCESS',
  CONTENT_GET_LIST_INTENSITY_SUCCESS: 'CONTENT_GET_LIST_INTENSITY_SUCCESS',
  CONTENT_GET_LIST_SERIES_SEARCH_SUCCESS: 'CONTENT_GET_LIST_SERIES_SEARCH_SUCCESS',
  CONTENT_GET_LIST_SOSMED_SUCCESS: 'CONTENT_GET_LIST_SOSMED_SUCCESS',
  CONTENT_GET_LIST_SUBSCRIBE_PACKAGE_SUCCESS: 'CONTENT_GET_LIST_SUBSCRIBE_PACKAGE_SUCCESS',
}

const contentCreators = {
  set_detailFaq: (detailFaq) => ({
    type: contentActions.CONTENT_GET_DETAIL_FAQ_SUCCESS,
    payload: {detailFaq},
  }),

  set_detailPolice: (detailPolice) => ({
    type: contentActions.CONTENT_GET_DETAIL_POLICE_SUCCESS,
    payload: {detailPolice},
  }),

  set_detailTos: (detailTos) => ({
    type: contentActions.CONTENT_GET_DETAIL_TOS_SUCCESS,
    payload: {detailTos},
  }),

  set_listBanner: (listBanner) => ({
    type: contentActions.CONTENT_GET_LIST_BANNER_SUCCESS,
    payload: {listBanner},
  }),

  set_listDifficulty: (listDifficulty) => ({
    type: contentActions.CONTENT_GET_LIST_DIFFICULTY_SUCCESS,
    payload: {listDifficulty},
  }),

  set_listFaq: (listFaq) => ({
    type: contentActions.CONTENT_GET_LIST_FAQ_SUCCESS,
    payload: {listFaq},
  }),

  set_listIntensity: (listIntensity) => ({
    type: contentActions.CONTENT_GET_LIST_INTENSITY_SUCCESS,
    payload: {listIntensity},
  }),

  set_listSeriesSearch: (listSeriesSearch) => ({
    type: contentActions.CONTENT_GET_LIST_SERIES_SEARCH_SUCCESS,
    payload: {listSeriesSearch},
  }),

  set_listSosmed: (listSosmed) => ({
    type: contentActions.CONTENT_GET_LIST_SOSMED_SUCCESS,
    payload: {listSosmed},
  }),

  set_listSubscribePackage: (listPackage) => ({
    type: contentActions.CONTENT_GET_LIST_SUBSCRIBE_PACKAGE_SUCCESS,
    payload: {listPackage},
  }),
}

export {
  contentActions,
  contentCreators,
}
