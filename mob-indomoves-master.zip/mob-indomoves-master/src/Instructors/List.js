import React from 'react'
import {ActionSheet, Col, Container, Icon, Row, Text} from 'native-base'
import {FlatList, Image, TouchableOpacity} from 'react-native'
import {CustomHeader} from '../_component'
import {connect} from 'react-redux'
import {language} from '../_common/language'
import {set_filterInstructorSort} from '../_actions/filter'
import {getListInstructor} from '../_actions/instructor'

class InstructorsList extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      listSort: true,
      maxColumns: 2,
    }

    this.press_sort = this.press_sort.bind(this)
    this.pressInstructorDetail = this.pressInstructorDetail.bind(this)
  }

  onChangeListSort (nextSort, callbk) {
    this.setState({
      listSort: nextSort,
    }, callbk && callbk())
  }

  pressInstructorDetail (uniqId) {
    const {props} = this

    props.navigation.push('InstructorsDetail', {
      uniqId,
    })
  }

  press_sort () {
    const {props} = this
    const listSort = listSortType(props)
    const fixOptions = listSort.map(item => item.name)

    ActionSheet.show({
      options: fixOptions,
      title: language[props.language].title.sort_type,
    }, idx => {
      if (idx !== undefined) {
        props.dispatch(set_filterInstructorSort(listSort[idx].value, listSort[idx].name))
        props.dispatch(getListInstructor())
      }
    })
  }

  render () {
    const {props, state} = this
    const noImage = require('../assets/images/no-image.jpg')

    return (
      <Container>
        <CustomHeader
          navigation={props.navigation}
          noRight={true}
          title={language[props.language].title.reward_instructor} />

        <Col>
          <Row style={{flex: 0, marginBottom: 20, paddingLeft: 15, paddingRight: 15, justifyContent: 'center'}}>
            <Text style={{fontSize: 14, color: '#666666', textTransform: 'uppercase'}}>{language[props.language].title.sort_label} : </Text>
            <TouchableOpacity onPress={this.press_sort} style={{flexDirection: 'row'}}>
              <Text style={{fontSize: 14, color: '#202020', textTransform: 'uppercase', marginRight: 5}}>
                {props.sortLabel !== '' ? props.sortLabel : language[props.language].title.sort_relevan}
              </Text>
              <Icon style={{fontSize: 11, color: '#202020', paddingTop: 4}} type="FontAwesome5" name="chevron-down" />
            </TouchableOpacity>
          </Row>

          <FlatList
            style={{paddingLeft: 15, paddingRight: 15}}
            data={props.listInstructor}
            numColumns={state.maxColumns}
            renderItem={({item, index}) => {
              const oddEven = index % state.maxColumns
              const styleBoxItem = state.maxColumns === 2 ? oddEven === 0 ? {marginRight: 7} : {marginLeft: 7} : null

              if (state.maxColumns === 2 && item.empty) {
                return <Col style={{backgroundColor: 'transparent', height: 100}} />
              } else {
                return (
                  <TouchableOpacity onPress={() => this.pressInstructorDetail(item.id)} style={[{flex: 1, height: 190, marginBottom: 10, alignItems: 'center'}, styleBoxItem]}>
                    <Image style={{width: 150, height: 150, borderRadius: 150/2, backgroundColor: 'rgba(0, 0, 0, 0.3)'}} defaultSource={noImage} source={{uri: item.photo}} />
                    <Text numberOfLines={1} style={{fontSize: 14, color: '#202020', letterSpacing: 1, marginTop: 5}}>{item.name}</Text>
                  </TouchableOpacity>
                )
              }
            }} />
        </Col>
      </Container>
    )
  }
}

const listSortType = (props) => {
  return [{
    name: language[props.language].title.sort_asc,
    value: 'name',
  },{
    name: language[props.language].title.sort_popular,
    value: 'most',
  },{
    name: language[props.language].title.sort_relevan,
    value: null,
  },{
    name: language[props.language].title.sort_newest,
    value: 'desc',
  }]
}

InstructorsList.defaultProps = {
  language: 'EN',
}

const mapStateToProps = state => ({
  language: state.userRdc.userMeInfo.language,
  listInstructor: state.instructorRdc.instructor,
  sortLabel: state.filterRdc.instructor_sortLabel,
})

export default connect(mapStateToProps)(InstructorsList)
