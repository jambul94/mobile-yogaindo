import React from 'react'
import {Button, Col, Container, Content, Footer, Icon, Row, Text} from 'native-base'
import {CustomHeader} from '../_component'
import {TouchableOpacity} from 'react-native'
import {connect} from 'react-redux'
import {collection} from '../_common/helper'
import {set_filterClassDifficulty} from '../_actions/filter'

class ClassesFilterDifficulty extends React.Component {
  constructor (props) {
    super(props)

    this.press_applyFilter = this.press_applyFilter.bind(this)
    this.press_clearFilter = this.press_clearFilter.bind(this)
    this.press_selectedItem = this.press_selectedItem.bind(this)
  }

  press_applyFilter () {
    const {props} = this

    props.navigation.push('MainAppScreen', {
      mode: 'filter',
      activePage: 2,
    })
  }

  press_clearFilter () {
    const {props} = this

    props.dispatch(set_filterClassDifficulty([], []))
  }

  press_selectedItem (selectedItem) {
    const {props} = this
    const difficulty = collection(props.difficultyLabel.slice()).firstWhere('value', selectedItem.value)
    let difficultyLabel = props.difficultyLabel.slice()
    let difficultyValue = props.difficultyValue.slice()

    if (difficulty) {
      difficultyLabel = collection(difficultyLabel).where('value', '!==', selectedItem.value).toArray()
      difficultyValue = difficultyValue.filter(item => item !== selectedItem.value)
    } else {
      difficultyLabel.push(selectedItem)
      difficultyValue.push(selectedItem.value)
    }

    props.dispatch(set_filterClassDifficulty(difficultyValue, difficultyLabel))
  }

  render () {
    const {props} = this

    return (
      <Container>
        <CustomHeader
          bodyAlignItem="flex-start"
          rightChildren={
            <TouchableOpacity style={{padding: 5, borderWidth: 1}} onPress={this.press_clearFilter}>
              <Text style={{color: '#202020', fontSize: 10, textTransform: 'uppercase'}}>Clear</Text>
            </TouchableOpacity>
          }
          title="Difficulty"
          navigation={props.navigation} />

        <Content>
          <Col style={{padding: 15}}>
            {props.difficulty.map((item, idx) => (
              <TouchableOpacity key={`filter-difficulty-${idx}`} onPress={() => this.press_selectedItem(item)}>
                <Row style={{paddingVertical: 15}}>
                  <Text style={{flex: 1, fontSize: 14, color: '#202020', letterSpacing: 1}}>{item.value}</Text>
                  {props.difficultyValue.includes(item.value)
                    ? <Icon style={{fontSize: 14, alignSelf: 'flex-end', color: '#666666'}} name="check" type="FontAwesome5" />
                    : null}
                </Row>
              </TouchableOpacity>
            ))}
          </Col>
        </Content>

        <Footer style={{backgroundColor: 'transparent', height:65, padding: 10}}>
          <Row>
            <Button onPress={this.press_applyFilter} block={true} style={{backgroundColor: '#075e54', justifyContent: 'center', width: '100%'}}>
              <Text style={{fontSize: 14}}>Apply</Text>
            </Button>
          </Row>
        </Footer>
      </Container>
    )
  }
}

const mapStateToProps = state => ({
  difficulty: state.contentRdc.difficulty,
  difficultyLabel: state.filterRdc.class_difficultyLabel,
  difficultyValue: state.filterRdc.class_difficultyValue,
})

export default connect(mapStateToProps)(ClassesFilterDifficulty)
