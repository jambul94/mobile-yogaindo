import React from 'react'
import {Button, Col, Container, Content, Footer, Icon, Row, Text} from 'native-base'
import {CustomHeader} from '../_component'
import {TouchableOpacity} from 'react-native'
import {connect} from 'react-redux'
import {collection} from '../_common/helper'
import {set_filterClassIntensity} from '../_actions/filter'

class ClassesFilterInstensity extends React.Component {
  constructor (props) {
    super(props)

    this.press_applyFilter = this.press_applyFilter.bind(this)
    this.press_clearFilter = this.press_clearFilter.bind(this)
    this.press_selectedItem = this.press_selectedItem.bind(this)
  }

  press_applyFilter () {
    const {props} = this

    props.navigation.push('MainAppScreen', {
      mode: 'filter',
      activePage: 2,
    })
  }

  press_clearFilter () {
    const {props} = this

    props.dispatch(set_filterClassIntensity([], []))
  }

  press_selectedItem (selectedItem) {
    const {props} = this
    const intensity = collection(props.intensityLabel.slice()).firstWhere('value', selectedItem.value)
    let intensityLabel = props.intensityLabel.slice()
    let intensityValue = props.intensityValue.slice()

    if (intensity) {
      intensityLabel = collection(intensityLabel).where('value', '!==', selectedItem.value).toArray()
      intensityValue = intensityValue.filter(item => item !== selectedItem.value)
    } else {
      intensityLabel.push(selectedItem)
      intensityValue.push(selectedItem.value)
    }

    props.dispatch(set_filterClassIntensity(intensityValue, intensityLabel))
  }

  render () {
    const {props} = this

    return (
      <Container>
        <CustomHeader
          bodyAlignItem="flex-start"
          rightChildren={
            <TouchableOpacity style={{padding: 5, borderWidth: 1}} onPress={this.press_clearFilter}>
              <Text style={{color: '#202020', fontSize: 10, textTransform: 'uppercase'}}>Clear</Text>
            </TouchableOpacity>
          }
          title="Intensity"
          navigation={props.navigation} />

        <Content>
          <Col style={{padding: 15}}>
            {props.intensity.map((item, idx) => (
              <TouchableOpacity key={`filter-intensity-${idx}`} onPress={() => this.press_selectedItem(item)}>
                <Row style={{paddingVertical: 15}}>
                  <Text style={{flex: 1, fontSize: 14, color: '#202020', letterSpacing: 1}}>{`Level ${item.value}`}</Text>
                  {props.intensityValue.includes(item.value)
                    ? <Icon style={{fontSize: 14, alignSelf: 'flex-end', color: '#666666'}} name="check" type="FontAwesome5" />
                    : null}
                </Row>
              </TouchableOpacity>
            ))}
          </Col>
        </Content>

        <Footer style={{backgroundColor: 'transparent', height:65, padding: 10}}>
          <Row>
            <Button onPress={this.press_applyFilter} block={true} style={{backgroundColor: '#075e54', justifyContent: 'center', width: '100%'}}>
              <Text style={{fontSize: 14}}>Apply</Text>
            </Button>
          </Row>
        </Footer>
      </Container>
    )
  }
}

const mapStateToProps = state => ({
  intensity: state.contentRdc.intensity,
  intensityLabel: state.filterRdc.class_intensityLabel,
  intensityValue: state.filterRdc.class_intensityValue,
})

export default connect(mapStateToProps)(ClassesFilterInstensity)
