import React from 'react'
import Video from 'react-native-video'
import collect from 'collect.js'
import Moment from 'react-moment'
import {CustomHeader, CustomInput, CustomModalComment, CustomModalSpinner} from '../_component'
import {Button, Col, Container, Content, Icon, Row, Tab, Tabs, Text} from 'native-base'
import {FlatList, Image, ImageBackground, TouchableOpacity, View} from 'react-native'
import {NavigationEvents} from 'react-navigation'
import {connect} from 'react-redux'
import {getDetailClass, getListClassComment, post_pointPlayVideo, post_ClassComment} from '../_actions/classes'
import {addClassToUserMe, delete_classFromUserMe, getUserMeClass, update_notificationToRead} from '../_actions/user'
import {showToast} from '../_common/helper'
import {language} from '../_common/language'

class ClassesDetail extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      activeTab: 0,
      comment: null,
      isExistInPractice: false,
      isFullScreen: false,
      isDetailCommentShow: false,
      listComment: [],
      selectedComment: null,
      screenType: 'contain',
      showVideo: false,
    }

    this._didFocus = this._didFocus.bind(this)
    this.change_input = this.change_input.bind(this)
    this.change_activeTab = this.change_activeTab.bind(this)
    this.pressAddToMyPractice = this.pressAddToMyPractice.bind(this)
    this.reqDetailClass = this.reqDetailClass.bind(this)
    this.pressTitleInstructor = this.pressTitleInstructor.bind(this)
    this.pressShowVideo = this.pressShowVideo.bind(this)
    this.press_removeFromMyPractive = this.press_removeFromMyPractive.bind(this)
    this.press_subscribe = this.press_subscribe.bind(this)
    this.press_submitComment = this.press_submitComment.bind(this)
    this.press_submitSubComment = this.press_submitSubComment.bind(this)
    this.send_pointPlayVideo = this.send_pointPlayVideo.bind(this)
    this.toggle_modalDetailComment = this.toggle_modalDetailComment.bind(this)
  }

  _didFocus () {
    this.reqDetailClass()
    this.req_listComment()
  }

  change_input (name, value) {
    this.setState({
      [name]: value,
    })
  }

  change_activeTab (nextTab) {
    this.setState({
      activeTab: nextTab,
      comment: null,
    })
  }

  pressAddToMyPractice () {
    const {props} = this
    const idClass = props.detailClass.id

    this.toggleLoading(true)
    props.dispatch(addClassToUserMe(idClass, () => {
      this.toggleLoading(false)
      showToast('Berhasil ditambahkan ke My Practice', 'success')
      props.dispatch(getUserMeClass())
      this.setState({
        isExistInPractice: true,
      })
    }), () => {
      this.toggleLoading(false)
      showToast('Gagal ditambahkan ke My Practice', 'warning')
    })
  }

  reqDetailClass () {
    const {props} = this
    const uniqId = props.navigation.getParam('uniqId')
    const unreadStatus = props.navigation.getParam('unread', null)

    props.dispatch(getDetailClass(uniqId, () => {
      const existClass = collect(props.userListClass).firstWhere('id', uniqId)

      if (unreadStatus) {
        const readFormData = props.navigation.getParam('postRead', null)
        props.dispatch(update_notificationToRead(readFormData))
      }

      if (existClass !== null) {
        this.setState({
          isExistInPractice: true,
        })
      }
    }))
  }

  req_listComment () {
    const {props} = this
    const uniqId = props.navigation.getParam('uniqId')

    getListClassComment(uniqId, resp => {
      this.setState({
        listComment: resp,
      })
    })
  }

  toggleLoading (show, callbk) {
    this.setState({
      showLoading: show,
    }, callbk && callbk())
  }

  press_submitComment () {
    const {props, state} = this
    const uniqId = props.navigation.getParam('uniqId')
    const formData = {
      workouts_id: uniqId,
      comment: state.comment,
    }

    this.toggleLoading(true)
    post_ClassComment(formData, () => {
      this.toggleLoading(false)
      this.req_listComment()
      this.setState({
        comment: null,
      })
      showToast('Komentar telah berhasil di tambahkan', 'success')
    }, () => {
      this.toggleLoading(false)
      showToast('Komentar gagal di tambahkan', 'warning')
    })
  }

  press_submitSubComment (comment_id, comment) {
    const {props} = this
    const uniqId = props.navigation.getParam('uniqId')
    const formData = {
      workouts_id: uniqId,
      comment,
      comment_id,
    }

    this.toggleLoading(true)
    post_ClassComment(formData, () => {
      this.toggleLoading(false)
      this.req_listComment()
      this.setState({
        isDetailCommentShow: false,
      })
      showToast('Komentar telah berhasil di tambahkan', 'success')
    }, () => {
      this.toggleLoading(false)
      showToast('Komentar gagal di tambahkan', 'warning')
    })
  }

  pressTitleInstructor (idInstructor) {
    const {props} = this

    props.navigation.push('InstructorsDetail', {
      uniqId: idInstructor,
    })
  }

  pressShowVideo () {
    this.setState({
      showVideo: true,
    })
  }

  press_removeFromMyPractive () {
    const {props} = this
    const idClass = props.detailClass.id

    this.toggleLoading(true)
    props.dispatch(delete_classFromUserMe(idClass, () => {
      this.toggleLoading(false)
      showToast('Berhasil dihapus dari My Practice', 'success')
      this.setState({
        isExistInPractice: false,
      })
    }, () => {
      this.toggleLoading(false)
      showToast('Gagal dhapus dari My Practice', 'warning')
    }))
  }

  press_subscribe () {
    const {props} = this

    props.navigation.navigate('PaymentForm')
  }

  send_pointPlayVideo () {
    const {props} = this
    const idClass = props.detailClass.id

    props.dispatch(post_pointPlayVideo(idClass))
  }

  toggle_modalDetailComment (uniqId) {
    const {state} = this
    let selectedComment = collect(state.listComment).firstWhere('id', uniqId)

    if (state.isDetailCommentShow) {
      selectedComment = null
    } else {
      selectedComment = {
        id: selectedComment.id,
        comment: selectedComment.comment,
        created_at: selectedComment.created_at,
        commenter: selectedComment.commenter,
        user_comments: selectedComment.user_comments,
      }
    }

    this.setState({
      isDetailCommentShow: !state.isDetailCommentShow,
      selectedComment,
    })
  }

  render () {
    const {props, state} = this
    const noImage = require('../assets/images/no-image.jpg')

    return (
      <Container>
        <NavigationEvents
          onDidFocus={this._didFocus} />

        <CustomHeader
          navigation={props.navigation} />

        <CustomModalSpinner
          isVisible={state.showLoading} />

        <CustomModalComment
          isVisible={state.isDetailCommentShow}
          parentData={state.selectedComment}
          onBackButtonPress={this.toggle_modalDetailComment}
          onPressSubmitComment={this.press_submitSubComment} />

        {props.detailClass !== null && state.showVideo ? (
          <Col style={{flex: 0, height: 200, backgroundColor: '#202020', justifyContent: 'center'}}>
            <Video
              controls={true}
              fullscreen={state.isFullScreen}
              fullscreenAutorotate={true}
              fullscreenOrientation="landscape"
              onReadyForDisplay={this.send_pointPlayVideo}
              resizeMode={state.screenType}
              source={{uri: props.detailClass.file}}
              style={{position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: '#202020'}} />
          </Col>
        ) : null}

        {props.detailClass !== null ? (
          <Content>
            {state.showVideo ? null : (
              <ImageBackground style={{width: '100%', height: 200, backgroundColor: 'rgba(0, 0, 0, 0.3)'}} defaultSource={noImage} source={{uri: props.detailClass.thumbnail}}>
                {props.userSubscribeStatus ? (
                  <Col style={{justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0, 0, 0, 0.4)'}}>
                    <TouchableOpacity onPress={this.pressShowVideo}>
                      <Icon style={{fontSize: 60, color: '#ffffff'}} name="play-circle" type="FontAwesome5" />
                    </TouchableOpacity>
                  </Col>
                ) : (
                  <View style={{flex: 1, backgroundColor: 'rgba(0, 0, 0, 0.4)', justifyContent: 'center', alignItems: 'center'}}>
                    <Icon style={{fontSize: 40, color: '#ffffff', marginBottom: 15}} name="lock" type="FontAwesome5" />
                    <Text style={{fontSize: 12, color: '#ffffff', textTransform: 'uppercase', letterSpacing: 2}}>Unlock This Class</Text>
                  </View>
                )}
              </ImageBackground>
            )}

            <Col style={{marginTop: 15, marginBottom: 15}}>
              <Row style={{marginTop: 10, justifyContent: 'center', alignItems: 'center'}}>
                <Text style={{fontSize: 16, color: '#202020', textAlign: 'center', textTransform: 'uppercase', fontWeight: 'bold', letterSpacing: 2}}>{`${props.detailClass.name} (${props.detailClass.duration})`}</Text>
              </Row>
              <Row style={{marginTop: 10, justifyContent: 'center'}}>
                <Text style={{fontSize: 12, color: '#202020', letterSpacing: 1}}>
                  {`${language[props.language].title.detail_from} `}
                </Text>
                <Text style={{fontSize: 12, color: '#202020', letterSpacing: 1}}>{props.detailClass.series}</Text>
              </Row>
              <Row style={{marginTop: 5, justifyContent: 'center'}}>
                <Text style={{fontSize: 12, color: '#202020', letterSpacing: 1}}>
                  {`${language[props.language].title.detail_by} `}
                </Text>
                <Text onPress={() => this.pressTitleInstructor(props.detailClass.instructor.id)} style={{fontSize: 12, color: '#202020', letterSpacing: 1, textDecorationLine: 'underline'}}>
                  {props.detailClass.instructor.name}
                </Text>
              </Row>
            </Col>

            {props.userSubscribeStatus ?
              !state.isExistInPractice ? (
                <Col style={{paddingTop: 15, paddingLeft: 15, paddingRight: 15, paddingBottom: 15/2}}>
                  <Button onPress={this.pressAddToMyPractice} style={{backgroundColor: '#075e54', justifyContent: 'center'}}>
                    <Text style={{fontSize: 14, textTransform: 'uppercase', letterSpacing: 1}}>
                      {language[props.language].form.button_add_mypractive}
                    </Text>
                  </Button>
                </Col>
              ) : (
                <Col style={{paddingTop: 15, paddingLeft: 15, paddingRight: 15, paddingBottom: 15/2}}>
                  <Button onPress={this.press_removeFromMyPractive} style={{backgroundColor: '#075e54', justifyContent: 'center'}}>
                    <Text style={{fontSize: 14, textTransform: 'uppercase', letterSpacing: 1}}>
                      {language[props.language].form.button_remove_mypractive}
                    </Text>
                  </Button>
                </Col>
              )
            : (
              <Col style={{paddingTop: 15, paddingLeft: 15, paddingRight: 15, paddingBottom: 15/2}}>
                <Button onPress={this.press_subscribe} style={{backgroundColor: '#075e54', justifyContent: 'center'}}>
                  <Text style={{fontSize: 14, textTransform: 'uppercase', letterSpacing: 1}}>
                    {language[props.language].form.button_subscribe}
                  </Text>
                </Button>
              </Col>
            )}

            <View style={{flex: 1, borderBottomColor: '#666666', borderBottomWidth: 1, margin: 15}} />

            <Col style={{paddingLeft: 15, paddingRight: 15, marginBottom: 15}}>
              <Tabs
                onChangeTab={({i}) => this.change_activeTab(i)}
                tabContainerStyle={{elevation:0}}
                tabBarUnderlineStyle={{backgroundColor: '#202020'}}
                tabBarInactiveTextColor="#666666"
                tabBarActiveTextColor="#202020">

                  <Tab
                    tabStyle={{backgroundColor: '#ffffff'}}
                    activeTabStyle={{backgroundColor: '#ffffff'}}
                    heading={language[props.language].title.detail_overview}>
                      <Text style={{fontSize: 12, color: '#202020', lineHeight: 20, marginTop: 15}}>{props.detailClass.description}</Text>
                  </Tab>
                  <Tab
                    tabStyle={{backgroundColor: '#ffffff'}}
                    activeTabStyle={{backgroundColor: '#ffffff'}}
                    heading={language[props.language].title.detail_community}>
                      <FlatList
                        data={state.listComment}
                        style={{paddingVertical: 15}}
                        renderItem={({item}) => {
                          return (
                            <Row style={{marginBottom: 20}}>
                              <Image style={{width: 50, height: 50, borderRadius: 50/2, backgroundColor: 'rgba(0, 0, 0, 0.3)'}} defaultSource={noImage} source={{uri: item.commenter.photo_thumbnail}} />
                              <Col>
                                <Row style={{paddingLeft: 15, flex: 0}}>
                                  <Text style={{color: '#202020', fontSize: 14}}>{item.commenter.name} . </Text>
                                  <Moment style={{color: '#666666', fontSize: 11, paddingTop: 3}} fromNow={true} ago={true} element={Text}>{item.created_at}</Moment>
                                </Row>
                                <Text style={{color: '#666666', fontSize: 12, paddingLeft: 15, paddingVertical: 5}}>{item.comment}</Text>
                                <Row style={{paddingLeft: 15, flex: 0}}>
                                  <TouchableOpacity onPress={() => this.toggle_modalDetailComment(item.id)}>
                                    <Text style={{color: '#075e54', fontSize: 12}}>{item.user_comments.length} comments</Text>
                                  </TouchableOpacity>
                                </Row>
                              </Col>
                            </Row>
                          )
                        }} />
                  </Tab>
              </Tabs>
            </Col>
          </Content>
        ) : null}

        {state.activeTab === 1 && (
          <Row style={{backgroundColor: '#e4e4e4', alignItems: 'center', flex: 0, paddingVertical: 5, paddingHorizontal: 15}}>
            <CustomInput
              onChangeText={this.change_input}
              multiline={true}
              name="comment"
              placeholder="insert comment..."
              placeholderTextColor="#707070"
              style={{flex: 1, color: '#202020', marginLeft: 10, fontSize: 14, height: 50}}
              value={this.state.comment} />

            <TouchableOpacity onPress={this.press_submitComment} style={{backgroundColor: '#075e54', height: 40, width: 48, justifyContent: 'center', alignItems: 'center'}}>
              <Icon style={{color: '#f4f4f4f4', fontSize: 16}} name="arrow-right" type="FontAwesome5" />
            </TouchableOpacity>
          </Row>
        )}
      </Container>
    )
  }
}

ClassesDetail.defaultProps = {
  language: 'EN',
}

const mapStateToProps = state => ({
  language: state.userRdc.userMeInfo.language,
  userListClass: state.userRdc.userMeClass,
  userSubscribeStatus: state.userRdc.userMeInfo.is_subscribe,
  detailClass: state.classRdc.detailClass,
})

export default connect(mapStateToProps)(ClassesDetail)
