import React from 'react'
import {Button, Col, Container, Content, Icon, Row, Text} from 'native-base'
import {CustomHeader} from '../_component'
import {TouchableOpacity} from 'react-native'
import {connect} from 'react-redux'
import {collection} from '../_common/helper'
import {set_filterClassStyle} from '../_actions/filter'

class ClassesFilterStyles extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      activeSubStyle: 0,
      listSubStyle: [],
    }

    this.press_applyFilter = this.press_applyFilter.bind(this)
    this.press_clearFilter = this.press_clearFilter.bind(this)
    this.press_selectedItem = this.press_selectedItem.bind(this)
    this.press_selectedParent = this.press_selectedParent.bind(this)
  }

  press_applyFilter () {
    const {props} = this

    props.navigation.push('MainAppScreen', {
      mode: 'filter',
      activePage: 2,
    })
  }

  press_clearFilter () {
    const {props} = this

    props.dispatch(set_filterClassStyle([], []))
  }

  press_selectedItem (selectedItem) {
    const {props} = this
    const categoriesStyle = collection(props.styleLabel.slice()).firstWhere('id', selectedItem.id)
    let styleLabel = props.styleLabel.slice()
    let styleValue = props.styleValue.slice()

    if (categoriesStyle) {
      styleLabel = collection(styleLabel).where('id', '!==', selectedItem.id).toArray()
      styleValue = styleValue.filter(item => item !== selectedItem.id)
    } else {
      styleLabel.push(selectedItem)
      styleValue.push(selectedItem.id)
    }

    props.dispatch(set_filterClassStyle(styleValue, styleLabel))
  }

  press_selectedParent (index, selectedParent) {
    this.setState({
      activeSubStyle: index,
      listSubStyle: selectedParent.styles,
    })
  }

  render () {
    const {props, state} = this

    return (
      <Container>
        <CustomHeader
          bodyAlignItem="flex-start"
          rightChildren={
            <TouchableOpacity style={{padding: 5, borderWidth: 1}} onPress={this.press_clearFilter}>
              <Text style={{color: '#202020', fontSize: 10, textTransform: 'uppercase'}}>Clear</Text>
            </TouchableOpacity>
          }
          title="Styles"
          navigation={props.navigation} />

        <Row>
          <Col style={{backgroundColor: '#e4e4e4'}}>
            <Content>
              {props.categoriesStyle.map((item, idx) => (
                <TouchableOpacity style={{backgroundColor: idx === state.activeSubStyle ? '#ffffff' : '#e4e4e4'}} key={`filter-categories-${idx}`} onPress={() => this.press_selectedParent(idx, item)}>
                  <Row style={{padding: 15}}>
                    <Text numberOfLines={1} style={{flex: 1, fontSize: 14, color: '#202020', letterSpacing: 1}}>{item.name}</Text>
                  </Row>
                </TouchableOpacity>
              ))}
            </Content>
          </Col>
          <Col>
            <Content>
              {state.listSubStyle.length !== 0 ? state.listSubStyle.map((item, idx) => (
                <TouchableOpacity key={`filter-categoriesStyle-${idx}`} onPress={() => this.press_selectedItem(item)}>
                  <Row style={{padding: 15}}>
                    <Text numberOfLines={1} style={{flex: 1, fontSize: 14, color: '#202020', letterSpacing: 1}}>{item.name}</Text>
                    {props.styleValue.includes(item.id)
                      ? <Icon style={{fontSize: 14, alignSelf: 'flex-end', color: '#666666'}} name="check" type="FontAwesome5" />
                      : null}
                  </Row>
                </TouchableOpacity>
              )) : (
                <Text style={{fontSize: 14, color: '#202020', letterSpacing: 1, marginVertical: 15, textAlign: 'center'}}>No available item</Text>
              )}
            </Content>
            <Row style={{flex: 0, height: 65, padding: 10}}>
              <Button onPress={this.press_applyFilter} block={true} style={{backgroundColor: '#075e54', justifyContent: 'center', width: '100%'}}>
                <Text style={{fontSize: 14}}>Apply</Text>
              </Button>
            </Row>
          </Col>
        </Row>
      </Container>
    )
  }
}

const mapStateToProps = state => ({
  categoriesStyle: state.categoriesRdc.categoriesStyle,
  styleLabel: state.filterRdc.class_styleLabel,
  styleValue: state.filterRdc.class_styleValue,
})

export default connect(mapStateToProps)(ClassesFilterStyles)
