import React from 'react'
import {Button, Col, Container, Content, Footer, Icon, Row, Text} from 'native-base'
import {CustomHeader} from '../_component'
import {TouchableOpacity} from 'react-native'
import {connect} from 'react-redux'
import {set_filterClassDifficulty, set_filterClassInstructor, set_filterClassIntensity, set_filterClassStyle} from '../_actions/filter'

class ClassesFilter extends React.Component {
  constructor (props) {
    super(props)

    this.press_applyFilter = this.press_applyFilter.bind(this)
    this.press_clearFilter = this.press_clearFilter.bind(this)
    this.press_difficulty = this.press_difficulty.bind(this)
    this.press_intensity = this.press_intensity.bind(this)
    this.press_instructor = this.press_instructor.bind(this)
    this.press_style = this.press_style.bind(this)
  }

  press_clearFilter () {
    const {props} = this

    props.dispatch(set_filterClassDifficulty([], []))
    props.dispatch(set_filterClassInstructor([], []))
    props.dispatch(set_filterClassIntensity([], []))
    props.dispatch(set_filterClassStyle([], []))
  }

  press_applyFilter () {
    const {props} = this

    props.navigation.push('MainAppScreen', {
      mode: 'filter',
      activePage: 2,
    })
  }

  press_difficulty () {
    const {props} = this

    props.navigation.navigate('ClassesFilterDifficulty')
  }

  press_intensity () {
    const {props} = this

    props.navigation.navigate('ClassesFilterInstensity')
  }

  press_instructor () {
    const {props} = this

    props.navigation.navigate('ClassesFilterInstructor')
  }

  press_style () {
    const {props} = this

    props.navigation.navigate('ClassesFilterStyles')
  }

  render () {
    const {props} = this
    const labelInstructor = props.instructorLabel.map((item, idx) => idx !== 0 ? `, ${item.name}` : item.name)
    const labelDifficulty = props.difficultyLabel.map((item, idx) => idx !== 0 ? `, ${item.value}` : item.value)
    const labelIntensity = props.intensityLabel.map((item, idx) => idx !== 0 ? `, Level ${item.value}` : `Level ${item.value}`)
    const labelStyle = props.styleLabel.map((item, idx) => idx !== 0 ? `, ${item.name}` : item.name)

    return (
      <Container>
        <CustomHeader
          bodyAlignItem="flex-start"
          rightChildren={
            <TouchableOpacity style={{padding: 5, borderWidth: 1}} onPress={this.press_clearFilter}>
              <Text style={{color: '#202020', fontSize: 10, textTransform: 'uppercase'}}>Reset</Text>
            </TouchableOpacity>
          }
          title="Filter"
          navigation={props.navigation} />

        <Content>
          <Col style={{padding: 15}}>
            <Row style={{paddingVertical: 15}}>
              <TouchableOpacity onPress={this.press_instructor} style={{flex: 1, flexDirection: 'column'}}>
                <Row>
                  <Text style={{flex: 1, fontSize: 14, textTransform: 'uppercase', color: '#202020', letterSpacing: 1}}>Instructors</Text>
                  <Icon style={{fontSize: 14, alignSelf: 'flex-end', color: '#666666'}} name="chevron-right" type="FontAwesome5" />
                </Row>
                <Row>
                  <Text numberOfLines={1} style={{fontSize: 12, color: '#666666', letterSpacing: 1}}>{labelInstructor}</Text>
                </Row>
              </TouchableOpacity>
            </Row>
            <Row style={{paddingVertical: 15}}>
              <TouchableOpacity onPress={this.press_difficulty} style={{flex: 1, flexDirection: 'column'}}>
                <Row>
                  <Text style={{flex: 1, fontSize: 14, textTransform: 'uppercase', color: '#202020', letterSpacing: 1}}>Difficulty</Text>
                  <Icon style={{fontSize: 14, alignSelf: 'flex-end', color: '#666666'}} name="chevron-right" type="FontAwesome5" />
                </Row>
                <Row>
                  <Text numberOfLines={1} style={{fontSize: 12, color: '#666666', letterSpacing: 1}}>{labelDifficulty}</Text>
                </Row>
              </TouchableOpacity>
            </Row>
            <Row style={{paddingVertical: 15}}>
              <TouchableOpacity onPress={this.press_intensity} style={{flex: 1, flexDirection: 'column'}}>
                <Row>
                  <Text style={{flex: 1, fontSize: 14, textTransform: 'uppercase', color: '#202020', letterSpacing: 1}}>Intensity</Text>
                  <Icon style={{fontSize: 14, alignSelf: 'flex-end', color: '#666666'}} name="chevron-right" type="FontAwesome5" />
                </Row>
                <Row>
                  <Text numberOfLines={1} style={{fontSize: 12, color: '#666666', letterSpacing: 1}}>{labelIntensity}</Text>
                </Row>
              </TouchableOpacity>
            </Row>
            <Row style={{paddingVertical: 15}}>
              <TouchableOpacity onPress={this.press_style} style={{flex: 1, flexDirection: 'column'}}>
                <Row>
                  <Text style={{flex: 1, fontSize: 14, textTransform: 'uppercase', color: '#202020', letterSpacing: 1}}>Styles</Text>
                  <Icon style={{fontSize: 14, alignSelf: 'flex-end', color: '#666666'}} name="chevron-right" type="FontAwesome5" />
                </Row>
                <Row>
                  <Text numberOfLines={1} style={{fontSize: 12, color: '#666666', letterSpacing: 1}}>{labelStyle}</Text>
                </Row>
              </TouchableOpacity>
            </Row>
          </Col>
        </Content>

        <Footer style={{backgroundColor: 'transparent', height:65, padding: 10}}>
          <Row>
            <Button onPress={this.press_applyFilter} block={true} style={{backgroundColor: '#075e54', justifyContent: 'center', width: '100%'}}>
              <Text style={{fontSize: 14}}>Apply</Text>
            </Button>
          </Row>
        </Footer>
      </Container>
    )
  }
}

const mapStateToProps = state => ({
  difficultyLabel: state.filterRdc.class_difficultyLabel,
  instructorLabel: state.filterRdc.class_instructorLabel,
  intensityLabel: state.filterRdc.class_intensityLabel,
  styleLabel: state.filterRdc.class_styleLabel,
})

export default connect(mapStateToProps)(ClassesFilter)
