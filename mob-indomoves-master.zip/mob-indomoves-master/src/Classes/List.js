import React from 'react'
import PropTypes from 'prop-types'
import ViewMoreText from 'react-native-view-more-text'
import {ActionSheet, Button, Col, Icon, Row, Text} from 'native-base'
import {FlatList, Image, ImageBackground, TouchableOpacity, View} from 'react-native'
import {CustomIconButton} from '../_component'
import {connect} from 'react-redux'
import {set_filterClassSort} from '../_actions/filter'
import {getListClass} from '../_actions/classes'
import {language} from '../_common/language'

class ClassesList extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      maxColumns: 2,
    }

    this.pressListType = this.pressListType.bind(this)
    this.pressClassesDetail = this.pressClassesDetail.bind(this)
    this.press_filter = this.press_filter.bind(this)
    this.press_sort = this.press_sort.bind(this)
  }

  onChangeListType (nextType, callBk) {
    this.setState({
      maxColumns: nextType,
    }, () => callBk && callBk())
  }

  pressListType (nextType) {
    this.onChangeListType(nextType)
  }

  pressClassesDetail (uniqId) {
    const {props} = this

    props.navigation.navigate('ClassesDetail', {
      uniqId,
    })
  }

  press_filter () {
    const {props} = this

    props.navigation.navigate('ClassesFilter')
  }

  press_sort () {
    const {props} = this
    const listSort = listSortType(props)
    const fixOptions = listSort.map(item => item.name)

    ActionSheet.show({
      options: fixOptions,
      title: language[props.language].title.sort_type,
    }, idx => {
      if (idx !== undefined) {
        props.dispatch(set_filterClassSort(listSort[idx].value, listSort[idx].name))
        props.dispatch(getListClass())
      }
    })
  }

  render () {
    const {props, state} = this
    const noImage = require('../assets/images/no-image.jpg')

    return (
      <Col>
        <Row style={{height: 70, paddingLeft: 15, paddingRight: 15}}>
          <Col style={{justifyContent: 'center'}}>
            <Text style={{fontSize: 14, color: '#202020', textTransform: 'uppercase'}}>
              {language[props.language].title.class_count.replace('[count]', props.listClass.length)}
            </Text>
            <Row style={{flex:0}}>
              <Text style={{fontSize: 14, color: '#666666', textTransform: 'uppercase'}}>{language[props.language].title.sort_label} : </Text>
              <TouchableOpacity onPress={this.press_sort} style={{flexDirection: 'row'}}>
                <Text style={{fontSize: 14, color: '#202020', textTransform: 'uppercase', marginRight: 5}}>
                  {props.sortLabel !== '' ? props.sortLabel : language[props.language].title.sort_relevan}
                </Text>
                <Icon style={{fontSize: 11, color: '#202020', paddingTop: 4}} type="FontAwesome5" name="chevron-down" />
              </TouchableOpacity>
            </Row>
          </Col>

          <Row style={{justifyContent: 'flex-end', alignItems: 'center'}}>
            <CustomIconButton
              idIconBtn={2}
              icon="th-large"
              isActive={state.maxColumns === 2}
              onPress={this.pressListType}
              style={{marginRight: 10}} />

            <CustomIconButton
              idIconBtn={1}
              icon="bars"
              isActive={state.maxColumns === 1}
              onPress={this.pressListType} />
          </Row>
        </Row>

        <FlatList
          key={`listClasses-${state.maxColumns}`}
          style={{paddingLeft: 15, paddingRight: 15}}
          data={props.listClass}
          numColumns={state.maxColumns}
          renderItem={({item, index}) => {
            const oddEven = index % state.maxColumns
            const styleBoxItem = state.maxColumns === 2 ? oddEven === 0 ? {marginRight: 7} : {marginLeft: 7} : null
            const styleBoxHeight = state.maxColumns === 2 ? 150 : 250

            if (state.maxColumns === 2 && item.empty) {
              return (
                <Col style={{backgroundColor: 'transparent', height: styleBoxHeight}} />
              )
            } else if (state.maxColumns === 1 && item.empty) {
              return null
            } else {
              if (state.maxColumns === 2) {
                return (
                  <TouchableOpacity onPress={() => this.pressClassesDetail(item.id)} style={[{flex: 1, height: styleBoxHeight, marginBottom: 10}, styleBoxItem]}>
                    <Image style={{width: '100%', height: styleBoxHeight - 50, marginBottom: 5, backgroundColor: 'rgba(0, 0, 0, 0.3)'}} defaultSource={noImage} source={{uri: item.thumbnail}} />
                    <Text numberOfLines={1} style={{fontSize: 12, color: '#202020', textTransform: 'uppercase', fontWeight: 'bold', letterSpacing: 1}}>{item.name}</Text>
                    <Text numberOfLines={1} style={{fontSize: 10, color: '#666666', letterSpacing: 1}}>{item.instructor}</Text>
                  </TouchableOpacity>
                )
              } else if (state.maxColumns === 1) {
                return (
                  <Col style={{marginBottom: 30}}>
                    <TouchableOpacity onPress={() => this.pressClassesDetail(item.id)} style={[{flex: 1, height: styleBoxHeight}, styleBoxItem]}>
                      <ImageBackground style={{width: '100%', height: styleBoxHeight - 50, marginBottom: 10, backgroundColor: 'rgba(0, 0, 0, 0.3)'}} defaultSource={noImage} source={{uri: item.thumbnail}}>
                        <Text style={{textTransform: 'uppercase', color: '#202020', fontSize: 12, width: 'auto', backgroundColor: '#ffffff', alignSelf: 'flex-start', letterSpacing: 1, padding: 10, paddingLeft: 20, paddingRight: 20}}>{item.category_name}</Text>

                        <Row style={{alignItems: 'flex-end', padding: 15}}>
                          <Row style={{justifyContent: 'flex-start'}}>
                            <Icon name="signal" type="FontAwesome5" style={{color: '#ffffff', fontSize: 16, marginRight: 10}} />
                            <Text style={{fontSize: 12, color: '#ffffff', letterSpacing: 1, textShadowOffset: {width: -1, height: 1}, textShadowRadius: 2}}>{item.difficulty}</Text>
                          </Row>
                          <Row style={{justifyContent: 'flex-end'}}>
                            <Text style={{fontSize: 12, color: '#ffffff', letterSpacing: 1, textShadowOffset: {width: -1, height: 1}, textShadowRadius: 2}}>{item.duration}</Text>
                          </Row>
                        </Row>
                      </ImageBackground>

                      <Text style={{fontSize: 16, color: '#202020', textAlign: 'center', textTransform: 'uppercase', fontWeight: 'bold', letterSpacing: 2}}>{item.name}</Text>
                      <Text style={{fontSize: 12, color: '#666666', textAlign: 'center', letterSpacing: 1}}>{item.instructor}</Text>
                    </TouchableOpacity>

                    <View style={{width: '100%', borderBottomColor: '#666666', borderBottomWidth: 1, marginTop: 15, marginBottom: 15}} />

                    <ViewMoreText
                      numberOfLines={3}
                      renderViewMore={(onPress) => (
                      <Text onPress={onPress} style={{fontSize: 12, color: '#202020', fontWeight: 'bold', letterSpacing: 1, lineHeight: 20}}>
                        {language[props.language].title.detail_readmore}
                      </Text>)}
                      renderViewLess={() => null}>
                      <Text style={{fontSize: 12, color: '#202020', lineHeight: 20}}>{item.description}</Text>
                    </ViewMoreText>
                  </Col>
                )
              }
            }
          }} />

        <Row style={{position: 'absolute', bottom: 0, left: 0, right: 0, justifyContent: 'center', marginBottom: 15}}>
          <Button onPress={this.press_filter} style={{backgroundColor: '#075e54', paddingHorizontal: 10}}>
            <Icon name="filter" type="FontAwesome5" style={{color: '#ffffff', fontSize: 16, marginRight: -5}} />
            <Text style={{color: '#ffffff', fontSize: 14}}>Filter</Text>
          </Button>
        </Row>
      </Col>
    )
  }
}

ClassesList.propTypes = {
  navigation: PropTypes.object,
  listClass: PropTypes.array,
}

const listSortType = (props) => {
  return [{
    name: language[props.language].title.sort_asc,
    value: 'name',
  },{
    name: language[props.language].title.sort_popular,
    value: 'most',
  },{
    name: language[props.language].title.sort_relevan,
    value: null,
  },{
    name: language[props.language].title.sort_newest,
    value: 'desc',
  }]
}

ClassesList.defaultProps = {
  language: 'EN',
}

const mapStateToProps = state => ({
  language: state.userRdc.userMeInfo.language,
  sortLabel: state.filterRdc.class_sortLabel,
})

export default connect(mapStateToProps)(ClassesList)
