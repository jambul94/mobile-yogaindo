import React from 'react'
import {Button, Col, Container, Content, Footer, Item, Row, Text} from 'native-base'
import {WebView} from 'react-native-webview'
import {CustomHeader, CustomInput, CustomModalSpinner} from '../_component'
import {NavigationEvents} from 'react-navigation'
import {language} from '../_common/language'
import {showToast, Xendit} from '../_common/helper'
import {connect} from 'react-redux'
import {post_subscribeCharge} from '../_actions/content'
import {getUserMeInfo} from '../_actions/user'

class PaymentCreditCard extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      activeStep: null,
      amount: '',
      cardNumber: '',
      cardExpMonth: '',
      cardExpYear: '',
      cardCvn: '',
      code: '',
      codeAmount: '',
      codePackage: null,
      isAuthenticating: false,
      isMultipleUse: true,
      isSkip3DS: false,
      isTokenizing: false,
      isRenderWebview: false,
      webviewUrl: '',
      token_id: null,
      authentication_id: null,
      showLoading: false,
    }

    this._didFocus = this._didFocus.bind(this)
    this.change_input = this.change_input.bind(this)
    this.init_amount = this.init_amount.bind(this)
    this.response_authenticationHandler = this.response_authenticationHandler.bind(this)
    this.response_tokenHandler = this.response_tokenHandler.bind(this)
    this.response_verificationHandler = this.response_verificationHandler.bind(this)
    this.req_token = this.req_token.bind(this)
    this.set_isTokenizing = this.set_isTokenizing.bind(this)
  }

  _didFocus () {
    this.init_amount()
  }

  init_amount () {
    const {props} = this
    const code = props.navigation.getParam('code')
    const amount = props.navigation.getParam('amount')
    const codeAmount = props.navigation.getParam('codeAmount')
    const codePackage = props.navigation.getParam('codePackage')

    this.setState({
      amount, code, codeAmount, codePackage,
    })
  }

  on_changeInput (field, value, callbk) {
    this.setState({
      [field]: value,
    }, () => callbk && callbk())
  }

  change_input (name, value) {
    let fixValue = value

    this.on_changeInput(name, fixValue)
  }

  req_authentication (token_id) {
    const {props, state} = this
    const authenticationData = {
      amount: state.amount,
      token_id,
    }

    this.set_isAuthenticating()
    this.toggleLoading(true, () => {
      Xendit.setPublishableKey(props.public_key)
      Xendit.card.createAuthentication(authenticationData, this.response_authenticationHandler);
    })
  }

  req_subscribePayment (authentication_id, authentication_status) {
    const {state, props} = this
    const formData = {
      token_id: state.token_id,
      authentication_id,
      status: authentication_status,
      package: state.codePackage,
      price_package: state.amount,
    }

    if (state.code !== '') {
      formData.promo_code = state.code
    }

    formData.amount = state.code !== '' ? state.amount - state.codeAmount : state.amount

    this.toggleLoading(true)
    props.dispatch(post_subscribeCharge(formData, () => {
      props.dispatch(getUserMeInfo(() => {
        this.toggleLoading(false, () => {
          showToast('Submit charge for subscribe success', 'success')
          props.navigation.navigate('MainAppScreen')
        })
      }, () => {
        this.toggleLoading(false, () => {
          showToast('Update data subscribe failed, please contact system administrator', 'warning')
        })
      }))
    }, () => {
      this.toggleLoading(false, () => {
        showToast('Submit charge failed, please contact system administrator', 'warning')
      })
    }))
  }

  req_token () {
    const {props, state} = this
    const tokenData = this.serialize_tokenData()

    if (state.cardNumber === '' || state.cardNumber === null) {
      showToast('Card number can\'t be empty', 'warning')
    }

    if (state.cardCvn === '' || state.cardCvn === null) {
      showToast('Card CVN can\'t be empty', 'warning')
    }

    if (state.cardExpMonth === '' || state.cardExpMonth === null) {
      showToast('Card expire month can\'t be empty', 'warning')
    }

    if (state.cardExpYear === '' || state.cardExpYear === null) {
      showToast('Card expire year can\'t be empty', 'warning')
    }

    if (state.cardNumber !== '' && state.cardCvn !== '' && state.cardExpMonth !== '' && state.cardExpYear !== '') {
      this.set_isTokenizing()
      this.toggleLoading(true, () => {
        Xendit.setPublishableKey(props.public_key)
        Xendit.card.createToken(tokenData, this.response_tokenHandler)
      })
    }
  }

  response_authenticationHandler (err, token) {
    if (err) {
      setTimeout(() => {
        this.toggleLoading(false, () => {
          showToast(err.message, 'warning')
          this.set_isAuthenticating()
          return
        })
      }, 2000)
    }

    if (token !== undefined) {
      switch (token.status) {
        case 'APPROVED':
        case 'VERIFIED':
          this.set_authenticationId(token.id, () => {
            this.req_subscribePayment(token.id, token.status)
          })
          break
        case 'FAILED':
          this.toggleLoading(false, () => {
            showToast(token.message, 'warning')
          })
          break
        case 'IN_REVIEW':
          this.setState({
            webviewUrl: token.payer_authentication_url,
            isRenderWebview: true,
            activeStep: 2,
          }, () => {
            this.toggleLoading(false)
          })
          break
        default:
          this.toggleLoading(false, () => {
            showToast('Unknown Authentication token response', 'warning')
          })
          break
      }

      this.set_isAuthenticating()
    }
  }

  response_tokenHandler (err, token) {
    if (err) {
      setTimeout(() => {
        this.toggleLoading(false, () => {
          showToast(err.message, 'warning')
          this.set_isTokenizing()
          return
        })
      }, 2000)
    }

    if (token !== undefined) {
      switch (token.status) {
        case 'APPROVED':
        case 'VERIFIED':
          this.set_tokenId(token.id, () => {
            this.req_authentication(token.id)
          })

          break
        case 'FAILED':
          this.toggleLoading(false, () => {
            showToast(token.message, 'warning')
          })
          break
        case 'IN_REVIEW':
          this.setState({
            webviewUrl: token.payer_authentication_url,
            isRenderWebview: true,
          }, () => {
            this.toggleLoading(false)
          })
          break
        default:
          this.toggleLoading(false, () => {
            showToast('Unknown generate token response', 'warning')
          })
          break
      }

      this.set_isTokenizing()
    }
  }

  response_verificationHandler (rawData) {
    const {state} = this
    const data = JSON.parse(rawData.nativeEvent.data)

    if (state.activeStep === 1) {
      this.setState({
        isRenderWebview: false,
      }, () => {
        this.set_tokenId(data.id, () => {
          this.req_authentication(data.id)
        })
      })
    } else {
      this.setState({
        isRenderWebview: false,
        authentication_id: data.id,
      }, () => {
        this.req_subscribePayment(data.id, data.status)
      })
    }
  }

  serialize_tokenData () {
    const {state} = this

    return {
      amount: state.amount,
      card_number: state.cardNumber,
      card_exp_month: state.cardExpMonth,
      card_exp_year: state.cardExpYear,
      // card_cvn: state.cardCvn,
      is_multiple_use: state.isMultipleUse,
      should_authenticate: !state.isSkip3DS,
    }
  }

  set_isAuthenticating () {
    this.setState({
      isAuthenticating: !this.state.isAuthenticating,
    });
  }

  set_isTokenizing () {
    this.setState({
      isTokenizing: !this.state.isTokenizing,
    })
  }

  set_tokenId (token_id, callbk) {
    this.setState({
      token_id,
    }, () => callbk && callbk())
  }

  set_authenticationId (authentication_id, callbk) {
    this.setState({
      authentication_id,
    }, () => callbk && callbk())
  }

  toggleLoading (show, callbk) {
    this.setState({
      showLoading: show,
    }, callbk && callbk())
  }

  render () {
    const {props, state} = this
    const package_amount = state.amount !== '' ? state.amount : 0
    const voucher_amount = state.codeAmount !== '' ? state.codeAmount : 0

    if (state.isRenderWebview) {
      return (
        <WebView
          source={{uri: state.webviewUrl}}
          injectedJavaScript={'(function() {window.postMessage = function(data) {window.ReactNativeWebView.postMessage(data);};})();'}
          onMessage={this.response_verificationHandler} />
      )
    }

    return (
      <Container>
        <NavigationEvents
          onDidFocus={this._didFocus} />

        <CustomHeader
          navigation={props.navigation} />

        <CustomModalSpinner
          isVisible={state.showLoading} />

        <Content>
          <Col style={{padding: 15}}>
            <Col style={{paddingVertical: 10, borderWidth: 0.5,borderColor: '#d7d7d7'}}>
              <Row>
                <Col style={{justifyContent: 'center', paddingVertical: 5, paddingHorizontal: 15}}>
                  <Text style={{fontSize: 14, fontWeight: 'bold'}}>Package Amount</Text>
                </Col>
                <Col>
                  <Row style={{justifyContent: 'flex-end', alignItems: 'center', paddingVertical: 5, paddingHorizontal: 15}}>
                    <Text style={{fontSize: 14, fontWeight: 'bold'}}>Rp.</Text>
                    <Text style={{fontSize: 14, fontWeight: 'bold'}}>{package_amount}</Text>
                  </Row>
                </Col>
              </Row>

              <Row>
                <Col style={{justifyContent: 'center', paddingVertical: 5, paddingHorizontal: 15}}>
                  <Text style={{fontSize: 14, fontWeight: 'bold'}}>Voucher Amount</Text>
                </Col>
                <Col>
                  <Row style={{justifyContent: 'flex-end', alignItems: 'center', paddingVertical: 5, paddingHorizontal: 15}}>
                    <Text style={{fontSize: 14, fontWeight: 'bold'}}>Rp.</Text>
                    <Text style={{fontSize: 14, fontWeight: 'bold'}}>{voucher_amount}</Text>
                  </Row>
                </Col>
              </Row>
            </Col>

            <Row style={{marginBottom: 20, height: 50, backgroundColor: '#d7d7d7'}}>
              <Col style={{justifyContent: 'center', padding: 15}}>
                <Text style={{fontSize: 16, fontWeight: 'bold'}}>Total</Text>
              </Col>
              <Col>
                <Row style={{justifyContent: 'flex-end', alignItems: 'center', padding: 15}}>
                  <Text style={{fontSize: 16, fontWeight: 'bold'}}>Rp.</Text>
                  <Text style={{fontSize: 16, fontWeight: 'bold'}}>{package_amount - voucher_amount}</Text>
                </Row>
              </Col>
            </Row>

            <Row style={{justifyContent: 'center', marginBottom: 10}}>
              <Text style={{fontSize: 16, fontWeight: 'bold'}}>Card Information</Text>
            </Row>

            <Col style={{marginBottom: 20}}>
              <Item regular={true}>
                <CustomInput
                  keyboardType="number-pad"
                  returnKeyType="done"
                  name="cardNumber"
                  onChangeText={this.change_input}
                  placeholderTextColor="#707070"
                  placeholder={language[props.language].form.subscribe_card_number}
                  style={{fontSize: 14}}
                  textAlign="center"
                  value={state.cardNumber} />
              </Item>

              <Row style={{marginTop: 15}}>
                <Item style={{flex: 2, marginRight: 5}} regular={true}>
                  <CustomInput
                    keyboardType="number-pad"
                    returnKeyType="done"
                    name="cardCvn"
                    onChangeText={this.change_input}
                    placeholderTextColor="#707070"
                    placeholder="CCV"
                    style={{fontSize: 14}}
                    textAlign="center"
                    value={state.cardCvn} />
                </Item>

                <Item style={{flex: 1, marginRight: 5, marginLeft: 5}} regular={true}>
                  <CustomInput
                    keyboardType="number-pad"
                    returnKeyType="done"
                    maxLength={2}
                    name="cardExpMonth"
                    onChangeText={this.change_input}
                    placeholderTextColor="#707070"
                    placeholder={language[props.language].form.subscribe_exp_month}
                    style={{fontSize: 14}}
                    textAlign="center"
                    value={state.cardExpMonth} />
                </Item>

                <Item style={{flex: 1, marginLeft: 5}} regular={true}>
                  <CustomInput
                    keyboardType="number-pad"
                    returnKeyType="done"
                    maxLength={4}
                    name="cardExpYear"
                    onChangeText={this.change_input}
                    placeholderTextColor="#707070"
                    placeholder={language[props.language].form.subscribe_exp_year}
                    style={{fontSize: 14}}
                    textAlign="center"
                    value={state.cardExpYear} />
                </Item>
              </Row>
            </Col>
          </Col>
        </Content>

        <Footer style={{backgroundColor: 'transparent', height:65, padding: 10}}>
          <Row>
            <Button
              onPress={this.req_token} block={true}
              style={{backgroundColor: '#075e54', justifyContent: 'center', width: '100%'}}>

              <Text style={{fontSize: 14}}>{language[props.language].form.button_submit}</Text>
            </Button>
          </Row>
        </Footer>
      </Container>
    )
  }
}

PaymentCreditCard.defaultProps = {
  language: 'EN',
}

const mapStateToProps = state => ({
  language: state.userRdc.userMeInfo.language,
  public_key: state.userRdc.userMeInfo.public_key,
})

export default connect(mapStateToProps)(PaymentCreditCard)
