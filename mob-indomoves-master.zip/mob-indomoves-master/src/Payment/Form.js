import React from 'react'
import {Button, CheckBox, Col, Container, Content, Footer, Icon, Item, Row, Text} from 'native-base'
import {FlatList, TouchableOpacity} from 'react-native'
import {CustomHeader, CustomInput, CustomModalSpinner} from '../_component'
import {connect} from 'react-redux'
import {language} from '../_common/language'
import {showToast} from '../_common/helper'
import {get_detailVoucher} from '../_actions/content'

class PaymentForm extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      activeAmount: null,
      activePayment: '',
      amount: '',
      code: '',
      codeAmount: '',
      codeMessage: null,
      codePackage: null,
      isAgree: false,
      isCodeValid: 'reset',
    }

    this.change_input = this.change_input.bind(this)
    this.press_checkAgree = this.press_checkAgree.bind(this)
    this.press_nextPayment = this.press_nextPayment.bind(this)
    this.press_package = this.press_package.bind(this)
    this.press_payment = this.press_payment.bind(this)
    this.req_validateVoucher = this.req_validateVoucher.bind(this)
  }

  on_changeInput (field, value, callbk) {
    this.setState({
      [field]: value,
    }, () => callbk && callbk())
  }

  change_input (name, value) {
    let fixValue = value

    if (name === 'code') {
      this.setState({
        codeAmount: '',
        isCodeValid: 'reset',
        codeMessage: null,
      })
    }

    this.on_changeInput(name, fixValue)
  }

  press_checkAgree () {
    const {state} = this

    this.setState({
      isAgree: !state.isAgree,
    })
  }

  press_package (item) {
    this.setState({
      activeAmount: item.id,
      amount: item.price,
      code: '',
      codeAmount: '',
      codePackage: item.package,
      isCodeValid: 'reset',
    })
  }

  press_payment (payment) {
    this.setState({
      activePayment: payment,
    })
  }

  press_nextPayment () {
    const {props, state} = this

    if (state.activePayment === '') {
      showToast('Please select payment method', 'warning')
    } else {
      if (state.activePayment === 'va') {
        showToast('The payment method is currently not available', 'warning')
      } else {
        props.navigation.navigate(state.activePayment === 'cc' && 'PaymentCreditCard', {
          amount: state.amount,
          code: state.code,
          codeAmount: state.codeAmount,
          codePackage: state.codePackage,
        })
      }
    }
  }

  req_validateVoucher () {
    const {state, props} = this
    const formData = {
      code: state.code,
      package: state.codePackage,
    }

    this.toggleLoading(true)
    props.dispatch(get_detailVoucher(formData, (resp_success) => {
      this.toggleLoading(false, () => {
        this.setState({
          isCodeValid: 'valid',
          codeAmount: resp_success,
          codeMessage: 'Voucher code is valid and can be used',
        })
        showToast('Voucher code is valid and can be used', 'success')
      })
    }, (resp_err) => {
      this.toggleLoading(false, () => {
        const {response} = resp_err

        if (response && response.status === 400) {
          this.setState({
            isCodeValid: 'invalid',
            codeMessage: response.data,
          })
        }

        showToast('The voucher code you entered is invalid', 'warning')
      })
    }))
  }

  toggleLoading (show, callbk) {
    this.setState({
      showLoading: show,
    }, callbk && callbk())
  }

  render () {
    const {props, state} = this
    const package_amount = state.amount !== '' ? state.amount : 0
    const voucher_amount = state.codeAmount !== '' ? state.codeAmount : 0

    return (
      <Container>
        <CustomHeader
          navigation={props.navigation} />

        <CustomModalSpinner
          isVisible={state.showLoading} />

        <Content>
          <Col style={{padding: 15}}>
            <FlatList
              data={props.subscribePackage}
              horizontal={true}
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={{marginBottom: 20}}
              renderItem={(data) => {
                const {item} = data

                return (
                  <TouchableOpacity onPress={() => this.press_package(item)}
                    style={{backgroundColor: state.activeAmount === item.id ? '#075e54' : '#ffffff', borderWidth: 0.5, borderRadius: 5, marginHorizontal: 5, height: 125, width: 125}}>

                    <Row style={{justifyContent: 'center', alignItems: 'flex-end'}}>
                      <Text style={{fontSize: 10, marginBottom: 5, color: state.activeAmount === item.id ? '#ffffff' : '#202020'}}>Rp.</Text>
                      <Text style={{fontSize: 20, fontWeight: 'bold', color: state.activeAmount === item.id ? '#ffffff' : '#202020'}}>{item.price}</Text>
                      <Text style={{fontSize: 10, marginBottom: 5, color: state.activeAmount === item.id ? '#ffffff' : '#202020'}}>/</Text>
                    </Row>
                    <Row style={{justifyContent: 'center', alignItems: 'flex-start'}}>
                      <Text style={{fontSize: 14, marginTop: 10, color: state.activeAmount === item.id ? '#ffffff' : '#202020'}}>{item.name}</Text>
                    </Row>
                  </TouchableOpacity>
                )
              }} />

            <Row style={{justifyContent: 'center', marginBottom: 10}}>
              <Text style={{fontSize: 16, fontWeight: 'bold'}}>Voucher</Text>
            </Row>

            <Col style={{marginBottom: 20}}>
              <Item regular={true} style={{borderColor: state.isCodeValid === 'valid' ? '#075e54' : state.isCodeValid === 'invalid' ? 'red' : '#d7d7d7'}}>
                <CustomInput
                  returnKeyType="done"
                  name="code"
                  disabled={state.activeAmount !== null ? false : true}
                  onChangeText={this.change_input}
                  placeholderTextColor="#707070"
                  placeholder={state.activeAmount !== null ? language[props.language].form.subscribe_voucher_code : 'Please select package'}
                  style={{fontSize: 14}}
                  textAlign="center"
                  value={state.code} />

                {state.activeAmount !== null && state.code !== '' && (
                  <TouchableOpacity onPress={this.req_validateVoucher} style={{backgroundColor: '#075e54', height: 50, width: 48, justifyContent: 'center', alignItems: 'center'}}>
                    <Icon style={{color: '#f4f4f4f4', fontSize: 16}} name="arrow-right" type="FontAwesome5" />
                  </TouchableOpacity>
                )}
              </Item>

              {state.isCodeValid !== 'reset' && (
                <Text style={{fontSize: 12, marginTop: 5}}>{`* ${state.codeMessage}`}</Text>
              )}
            </Col>

            <Col style={{paddingVertical: 10, borderWidth: 0.5,borderColor: '#d7d7d7'}}>
              <Row>
                <Col style={{justifyContent: 'center', paddingVertical: 5, paddingHorizontal: 15}}>
                  <Text style={{fontSize: 14, fontWeight: 'bold'}}>Package Amount</Text>
                </Col>
                <Col>
                  <Row style={{justifyContent: 'flex-end', alignItems: 'center', paddingVertical: 5, paddingHorizontal: 15}}>
                    <Text style={{fontSize: 14, fontWeight: 'bold'}}>Rp.</Text>
                    <Text style={{fontSize: 14, fontWeight: 'bold'}}>{package_amount}</Text>
                  </Row>
                </Col>
              </Row>

              <Row>
                <Col style={{justifyContent: 'center', paddingVertical: 5, paddingHorizontal: 15}}>
                  <Text style={{fontSize: 14, fontWeight: 'bold'}}>Voucher Amount</Text>
                </Col>
                <Col>
                  <Row style={{justifyContent: 'flex-end', alignItems: 'center', paddingVertical: 5, paddingHorizontal: 15}}>
                    <Text style={{fontSize: 14, fontWeight: 'bold'}}>Rp.</Text>
                    <Text style={{fontSize: 14, fontWeight: 'bold'}}>{voucher_amount}</Text>
                  </Row>
                </Col>
              </Row>
            </Col>

            <Row style={{marginBottom: 20, height: 50, backgroundColor: '#d7d7d7'}}>
              <Col style={{justifyContent: 'center', padding: 15}}>
                <Text style={{fontSize: 16, fontWeight: 'bold'}}>Total</Text>
              </Col>
              <Col>
                <Row style={{justifyContent: 'flex-end', alignItems: 'center', padding: 15}}>
                  <Text style={{fontSize: 16, fontWeight: 'bold'}}>Rp.</Text>
                  <Text style={{fontSize: 16, fontWeight: 'bold'}}>{package_amount - voucher_amount}</Text>
                </Row>
              </Col>
            </Row>

            <Row style={{justifyContent: 'center', marginBottom: 10}}>
              <Text style={{fontSize: 16, fontWeight: 'bold'}}>Payment Method</Text>
            </Row>

            <Col style={{marginBottom: 20}}>
              <TouchableOpacity onPress={() => this.press_payment('cc')}
                style={{backgroundColor: state.activePayment === 'cc' ? '#075e54' : '#ffffff', borderWidth: 0.5, borderRadius: 5, marginHorizontal: 5, marginBottom: 5}}>

                <Row style={{justifyContent: 'center', alignItems: 'flex-start'}}>
                  <Text style={{fontSize: 14, padding: 10, color: state.activePayment === 'cc' ? '#ffffff' : '#202020'}}>Credit Card</Text>
                </Row>
              </TouchableOpacity>

              <TouchableOpacity onPress={() => this.press_payment('va')}
                style={{backgroundColor: state.activePayment === 'va' ? '#075e54' : '#ffffff', borderWidth: 0.5, borderRadius: 5, marginHorizontal: 5, marginBottom: 5}}>

                <Row style={{justifyContent: 'center', alignItems: 'flex-start'}}>
                  <Text style={{fontSize: 14, padding: 10, color: state.activePayment === 'va' ? '#ffffff' : '#202020'}}>Virtual Account</Text>
                </Row>
              </TouchableOpacity>
            </Col>

            <Row>
              <TouchableOpacity onPress={this.press_checkAgree}>
                <Row>
                  <CheckBox color="#075e54" checked={state.isAgree} onPress={this.press_checkAgree} />
                  <Text style={{marginLeft: 20, fontSize: 12, letterSpacing: 1}}>{language[props.language].form.subscribe_agreement}</Text>
                </Row>
              </TouchableOpacity>
            </Row>
          </Col>
        </Content>

        <Footer style={{backgroundColor: 'transparent', height:65, padding: 10}}>
          <Row>
            <Button
              onPress={this.press_nextPayment} block={true} disabled={!state.isAgree ? true : state.amount === '' ? true : state.isCodeValid === 'invalid' ? true : false}
              style={{backgroundColor: !state.isAgree ? '#d7d7d7' : state.amount === '' ? '#d7d7d7' : state.isCodeValid === 'invalid' ? '#d7d7d7' : '#075e54', justifyContent: 'center', width: '100%'}}>

              <Text style={{fontSize: 14}}>Next</Text>
            </Button>
          </Row>
        </Footer>
      </Container>
    )
  }
}

PaymentForm.defaultProps = {
  language: 'EN',
}

const mapStateToProps = state => ({
  language: state.userRdc.userMeInfo.language,
  subscribePackage: state.contentRdc.subscribePackage,
})

export default connect(mapStateToProps)(PaymentForm)
