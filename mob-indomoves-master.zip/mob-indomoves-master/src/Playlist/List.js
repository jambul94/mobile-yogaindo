import React from 'react'
import {ActionSheet, Col, Container, Icon, Row, Text} from 'native-base'
import {FlatList, Image, TouchableOpacity} from 'react-native'
import {CustomHeader} from '../_component'
import {connect} from 'react-redux'
import {language} from '../_common/language'
import {set_filterPlaylistrSort} from '../_actions/filter'
import {getListPlaylist} from '../_actions/playlist'

class PlaylistList extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      maxColumns: 2,
    }

    this.press_detailPLaylist = this.press_detailPLaylist.bind(this)
    this.press_sort = this.press_sort.bind(this)
  }

  press_detailPLaylist (uniqId) {
    const {props} = this

    props.navigation.navigate('PlaylistDetail', {
      uniqId,
    })
  }

  press_sort () {
    const {props} = this
    const listSort = listSortType(props)
    const fixOptions = listSort.map(item => item.name)

    ActionSheet.show({
      options: fixOptions,
      title: language[props.language].title.sort_type,
    }, idx => {
      if (idx !== undefined) {
        props.dispatch(set_filterPlaylistrSort(listSort[idx].value, listSort[idx].name))
        props.dispatch(getListPlaylist())
      }
    })
  }

  render () {
    const {props, state} = this
    const noImage = require('../assets/images/no-image.jpg')

    return (
      <Container>
        <CustomHeader
          navigation={props.navigation} />

        <Col style={{paddingHorizontal: 15}}>
          <Row style={{height: 70}}>
            <Col style={{justifyContent: 'center'}}>
              <Text style={{fontSize: 14, color: '#202020', textTransform: 'uppercase'}}>
                {language[props.language].title.playlist_count.replace('[count]', props.listPLaylist.length)}
              </Text>
              <Row style={{flex:0}}>
                <Text style={{fontSize: 14, color: '#666666', textTransform: 'uppercase'}}>{language[props.language].title.sort_label} : </Text>
                <TouchableOpacity onPress={this.press_sort} style={{flexDirection: 'row'}}>
                  <Text style={{fontSize: 14, color: '#202020', textTransform: 'uppercase', marginRight: 5}}>
                    {props.sortLabel !== '' ? props.sortLabel : language[props.language].title.sort_newest}
                  </Text>
                  <Icon style={{fontSize: 11, color: '#202020', paddingTop: 4}} type="FontAwesome5" name="chevron-down" />
                </TouchableOpacity>
              </Row>
            </Col>
          </Row>

          <FlatList
            data={props.listPLaylist}
            numColumns={state.maxColumns}
            renderItem={({item, index}) => {
              const oddEven = index % state.maxColumns
              const styleBoxItem = state.maxColumns === 2 ? oddEven === 0 ? {marginRight: 7} : {marginLeft: 7} : null

              return (
                <TouchableOpacity onPress={() => this.press_detailPLaylist(item.id)} style={[{flex: 1, height: 150, marginBottom: 10}, styleBoxItem]}>
                  <Image style={{width: '100%', height: 150 - 35, marginBottom: 5, backgroundColor: 'rgba(0, 0, 0, 0.3)'}} defaultSource={noImage} source={{uri: item.image}} />
                  <Text numberOfLines={1} style={{fontSize: 12, color: '#202020', textTransform: 'uppercase', fontWeight: 'bold', letterSpacing: 1}}>{item.title}</Text>
                </TouchableOpacity>
              )
            }} />
        </Col>
      </Container>
    )
  }
}

const listSortType = (props) => {
  return [{
    name: language[props.language].title.sort_asc,
    value: 'name',
  },{
    name: language[props.language].title.sort_popular,
    value: 'most',
  },{
    name: language[props.language].title.sort_newest,
    value: 'desc',
  }]
}

PlaylistList.defaultProps = {
  language: 'EN',
}

const mapStateToProps = state => ({
  language: state.userRdc.userMeInfo.language,
  listPLaylist: state.playlistRdc.playlist,
  sortLabel: state.filterRdc.playlist_sortLabel,
})

export default connect(mapStateToProps)(PlaylistList)
