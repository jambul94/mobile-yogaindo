import React from 'react'
import ViewMoreText from 'react-native-view-more-text'
import collect from 'collect.js'
import {Button, Col, Container, Content, Row, Text} from 'native-base'
import {CustomHeader, CustomModalSpinner} from '../_component'
import {Image, TouchableOpacity} from 'react-native'
import {NavigationEvents} from 'react-navigation'
import {connect} from 'react-redux'
import {getDetailPlaylist} from '../_actions/playlist'
import {addPlaylistToUserMe, delete_playlistFromUserMe, getuserMePlaylist} from '../_actions/user'
import {showToast} from '../_common/helper'
import {language} from '../_common/language'

class PlaylistDetail extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      isExistInPractice: false,
      showLoading: false,
    }

    this._didFocus = this._didFocus.bind(this)
    this.pressAddToMyPractice = this.pressAddToMyPractice.bind(this)
    this.reqDetailPlaylist = this.reqDetailPlaylist.bind(this)
    this.press_removeFromMyPractive = this.press_removeFromMyPractive.bind(this)
  }

  _didFocus () {
    this.reqDetailPlaylist()
  }

  pressAddToMyPractice () {
    const {props} = this
    const idPlaylist = props.detailPlaylist.id

    this.toggleLoading(true)
    props.dispatch(addPlaylistToUserMe(idPlaylist, () => {
      this.toggleLoading(false)
      showToast('Berhasil ditambahkan ke My Practice', 'success')
      props.dispatch(getuserMePlaylist())
      this.setState({
        isExistInPractice: true,
      })
    }), () => {
      this.toggleLoading(false)
      showToast('Gagal ditambahkan ke My Practice', 'warning')
    })
  }

  pressPlaylistItem (uniqId) {
    const {props} = this

    props.navigation.navigate('ClassesDetail', {
      uniqId,
    })
  }

  reqDetailPlaylist () {
    const {props} = this
    const uniqId = props.navigation.getParam('uniqId')

    props.dispatch(getDetailPlaylist(uniqId, () => {
      const existPlaylist = collect(props.userListPlaylist).firstWhere('id', uniqId)

      if (existPlaylist !== null) {
        this.setState({
          isExistInPractice: true,
        })
      }
    }))
  }

  press_removeFromMyPractive () {
    const {props} = this
    const idPlaylist = props.detailPlaylist.id

    this.toggleLoading(true)
    props.dispatch(delete_playlistFromUserMe(idPlaylist, () => {
      this.toggleLoading(false)
      showToast('Berhasil dihapus dari My Practice', 'success')
      this.setState({
        isExistInPractice: false,
      })
    }, () => {
      this.toggleLoading(false)
      showToast('Gagal dhapus dari My Practice', 'warning')
    }))
  }

  toggleLoading (show, callbk) {
    this.setState({
      showLoading: show,
    }, callbk && callbk())
  }

  render () {
    const {props, state} = this
    const noImage = require('../assets/images/no-image.jpg')

    return (
      <Container>
        <NavigationEvents
          onDidFocus={this._didFocus} />

        <CustomHeader
          navigation={props.navigation} />

        <CustomModalSpinner
          isVisible={state.showLoading} />

        {props.detailPlaylist !== null ? (
          <Content>
            <Col style={{alignItems: 'center', paddingTop: 15, paddingLeft: 15, paddingRight: 15}}>
              <Image style={{width: 250, height: 250, backgroundColor: 'rgba(0, 0, 0, 0.3)'}} defaultSource={noImage} source={{uri: props.detailPlaylist.image}} />
            </Col>

            <Col style={{alignItems: 'center', paddingLeft: 15, paddingRight: 15}}>
              <Text style={{fontSize: 14, color: '#666666', textTransform: 'uppercase', letterSpacing: 1, paddingTop: 10, paddingBottom: 10/2}}>Playlist</Text>
              <Text style={{fontSize: 20, fontWeight: 'bold', color: '#202020', textTransform: 'uppercase', letterSpacing: 2, paddingTop: 10/2, paddingBottom: 10/2, textAlign: 'center'}}>{props.detailPlaylist.title}</Text>
              <ViewMoreText
                textStyle={{paddingLeft: 15, paddingRight: 15, paddingTop: 10/2, paddingBottom: 10/2, textAlign: 'center'}}
                numberOfLines={3}
                renderViewMore={(onPress) => (
                <Text onPress={onPress} style={{textAlign: 'center', fontSize: 12, color: '#666666', fontWeight: 'bold', letterSpacing: 1, lineHeight: 20}}>
                  {language[props.language].title.detail_readmore}
                </Text>)}
                renderViewLess={() => null}>
                  <Text style={{fontSize: 12, color: '#666666', lineHeight: 20}}>{props.detailPlaylist.description}</Text>
              </ViewMoreText>
              {/* <Text style={{fontSize: 14, color: '#666666', letterSpacing: 1, paddingTop: 10/2, paddingBottom: 10/2}}>Created By Indo Moves</Text> */}
              {/* <Text style={{fontSize: 14, color: '#666666', letterSpacing: 1, paddingTop: 10/2, paddingBottom: 10/2}}>270 Followers</Text> */}
              <Text style={{fontSize: 14, color: '#666666', letterSpacing: 1, paddingTop: 10/2, paddingBottom: 10/2}}>
                {`${props.detailPlaylist.workouts.length} ${language[props.language].menu.main_classes} - ${props.detailPlaylist.total_duration}`}
              </Text>
            </Col>

            {!state.isExistInPractice ? (
              <Col style={{paddingTop: 15, paddingLeft: 15, paddingRight: 15, paddingBottom: 15/2}}>
                <Button onPress={this.pressAddToMyPractice} style={{backgroundColor: '#075e54', justifyContent: 'center'}}>
                  <Text style={{fontSize: 14, textTransform: 'uppercase', letterSpacing: 1}}>
                    {language[props.language].form.button_add_mypractive}
                  </Text>
                </Button>
              </Col>
            ) : (
              <Col style={{paddingTop: 15, paddingLeft: 15, paddingRight: 15, paddingBottom: 15/2}}>
                <Button onPress={this.press_removeFromMyPractive} style={{backgroundColor: '#075e54', justifyContent: 'center'}}>
                  <Text style={{fontSize: 14, textTransform: 'uppercase', letterSpacing: 1}}>
                    {language[props.language].form.button_remove_mypractive}
                  </Text>
                </Button>
              </Col>
            )}

            <Col style={{paddingHorizontal: 15, paddingTop: 15}}>
              {props.detailPlaylist.workouts.map(item => (
                <TouchableOpacity onPress={() => this.pressPlaylistItem(item.id)} key={`playlist-item-${item.key}`} style={{borderBottomColor: '#666666', borderBottomWidth: 1}}>
                  <Row style={{paddingTop: 10, paddingBottom: 5/2, justifyContent: 'space-between'}}>
                    <Text style={{fontSize: 11, color: '#202020', letterSpacing: 1, textTransform: 'uppercase'}}>{item.series_name}</Text>
                    <Text style={{fontSize: 11, color: '#202020', letterSpacing: 1, textTransform: 'uppercase'}}>{item.duration}</Text>
                  </Row>
                  <Text style={{paddingTop: 5/2, paddingBottom: 5/2, fontSize: 16, color: '#202020', fontWeight: 'bold', letterSpacing: 1, textTransform: 'uppercase'}}>{item.name}</Text>
                  <Text style={{paddingTop: 5/2, paddingBottom: 10, fontSize: 11, color: '#202020', letterSpacing: 1}}>{item.instructor}</Text>
                </TouchableOpacity>
              ))}
            </Col>
          </Content>
        ) : null}
      </Container>
    )
  }
}

PlaylistDetail.defaultProps = {
  language: 'EN',
}

const mapStateToProps = state => ({
  language: state.userRdc.userMeInfo.language,
  detailPlaylist: state.playlistRdc.detailPlaylist,
  userListPlaylist: state.userRdc.userMePlaylist,
})

export default connect(mapStateToProps)(PlaylistDetail)
