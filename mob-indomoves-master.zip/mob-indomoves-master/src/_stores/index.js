import reduxThunk from 'redux-thunk'
import {applyMiddleware, combineReducers, createStore, compose} from 'redux'
import {categoriesRdc} from '../_actions/categories/reducers'
import {classRdc} from '../_actions/classes/reducers'
import {contentRdc} from '../_actions/content/reducers'
import {filterRdc} from '../_actions/filter/reducers'
import {instructorRdc} from '../_actions/instructor/reducers'
import {playlistRdc} from '../_actions/playlist/reduers'
import {seriesRdc} from '../_actions/series/reducers'
import {userRdc} from '../_actions/user/reducers'
import {reactotron} from '../../ReactotronConfig'

let composedEnhancer
const middleware = [reduxThunk]

const appRdc = combineReducers({
  categoriesRdc,
  classRdc,
  contentRdc,
  filterRdc,
  instructorRdc,
  playlistRdc,
  seriesRdc,
  userRdc,
})

if (__DEV__) {
  composedEnhancer = compose(
    applyMiddleware(
      ...middleware,
    ),
    reactotron.createEnhancer()
  )
} else {
  composedEnhancer = applyMiddleware(...middleware)
}

const baseStores = createStore(appRdc, composedEnhancer)

export default baseStores
