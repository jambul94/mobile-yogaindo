import React from 'react'
import PropTypes from 'prop-types'
import Carousel from 'react-native-snap-carousel'
import {Col, Content, Icon, Row, Text} from 'native-base'
import {Dimensions, FlatList, Image, ImageBackground, TouchableOpacity} from 'react-native'
import {language} from '../_common/language'

class HomeList extends React.Component {
  constructor (props) {
    super(props)

    this.pressOurInstructor = this.pressOurInstructor.bind(this)
    this.pressInstructorDetail = this.pressInstructorDetail.bind(this)
    this.pressClassesDetail = this.pressClassesDetail.bind(this)
    this.pressPlaylistDetail = this.pressPlaylistDetail.bind(this)
    this.pressPlaylistNew = this.pressPlaylistNew.bind(this)
    this.render_itemBanner = this.render_itemBanner.bind(this)
  }

  pressOurInstructor () {
    const {props} = this

    props.navigation.push('InstructorsList')
  }

  pressClassesDetail (uniqId) {
    const {props} = this

    props.navigation.push('ClassesDetail', {
      uniqId,
    })
  }

  pressInstructorDetail (uniqId) {
    const {props} = this

    props.navigation.push('InstructorsDetail', {
      uniqId,
    })
  }

  pressPlaylistNew () {
    const {props} = this

    props.navigation.push('PlaylistList')
  }

  pressPlaylistDetail (uniqId) {
    const {props} = this

    props.navigation.navigate('PlaylistDetail', {
      uniqId,
    })
  }

  render_itemBanner ({item, index}) {
    const noImage = require('../assets/images/no-image.jpg')

    return (
      <ImageBackground key={`banner-${index}`} style={{flex: 1, height: 200, marginBottom: 10, backgroundColor: 'rgba(0, 0, 0, 0.3)'}} defaultSource={noImage} source={{uri: item.image}}>
        <Col style={{alignItems: 'center', justifyContent: 'center', paddingHorizontal: 30, backgroundColor: 'rgba(0, 0, 0, 0.3)'}}>
          <Text style={{fontSize: 20, fontWeight: 'bold', color: '#ffffff', letterSpacing: 2, textAlign: 'center'}}>{item.name}</Text>
          <Text style={{fontSize: 14, fontWeight: 'bold', color: '#ffffff', letterSpacing: 1.5, textAlign: 'center', marginTop: 10}}>{item.description}</Text>
        </Col>
      </ImageBackground>
    )
  }

  render () {
    const {props} = this
    const windowWidth = Dimensions.get('window').width
    const noImage = require('../assets/images/no-image.jpg')

    return (
      <Content>
        <Carousel
          autoplay={true}
          autoplayDelay={3000}
          autoplayInterval={8000}
          data={props.listBanner}
          enableMomentum={false}
          lockScrollWhileSnapping={true}
          itemWidth={windowWidth}
          loop={true}
          renderItem={this.render_itemBanner}
          sliderWidth={windowWidth} />

        <Row style={{flex: 0, height: 20, alignItems: 'center', paddingLeft: 15, paddingRight: 15 ,marginBottom: 10}}>
          <Text style={{color: '#202020', fontSize: 14, textTransform: 'uppercase', fontWeight: 'bold'}}>
            {language[props.language].title.feature_minutesOrLess}
          </Text>
        </Row>

        <FlatList
          data={props.listClass}
          horizontal={true}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{paddingLeft: 15, paddingRight: 5, marginBottom: 10}}
          renderItem={(data) => {
            const {item} = data

            return (
              <TouchableOpacity onPress={() => this.pressClassesDetail(item.id)} style={[{width: 150, height: 140, marginRight: 10}]}>
                <Image style={{width: '100%', height: 100, backgroundColor: 'rgba(0, 0, 0, 0.3)'}} defaultSource={noImage} source={{uri: item.thumbnail}} />
                <Text numberOfLines={1} style={{fontSize: 12, color: '#202020', textTransform: 'uppercase', fontWeight: 'bold', letterSpacing: 1, marginTop: 5}}>{item.name}</Text>
                <Text numberOfLines={1} style={{fontSize: 10, color: '#666666', letterSpacing: 1}}>{item.instructor}</Text>
              </TouchableOpacity>
            )
          }} />

        <Row style={{flex: 0, height: 20, alignItems: 'center', paddingLeft: 15, paddingRight: 15 ,marginBottom: 10}}>
          <Text style={{color: '#202020', fontSize: 14, textTransform: 'uppercase', fontWeight: 'bold'}}>
            {language[props.language].title.feature_trending}
          </Text>
        </Row>

        <FlatList
          data={props.listClass}
          horizontal={true}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{paddingLeft: 15, paddingRight: 5, marginBottom: 10}}
          renderItem={(data) => {
            const {item} = data

            return (
              <TouchableOpacity onPress={() => this.pressClassesDetail(item.id)} style={[{width: 150, height: 140, marginRight: 10}]}>
                <Image style={{width: '100%', height: 100, backgroundColor: 'rgba(0, 0, 0, 0.3)'}} defaultSource={noImage} source={{uri: item.thumbnail}} />
                <Text numberOfLines={1} style={{fontSize: 12, color: '#202020', textTransform: 'uppercase', fontWeight: 'bold', letterSpacing: 1, marginTop: 5}}>{item.name}</Text>
                <Text numberOfLines={1} style={{fontSize: 10, color: '#666666', letterSpacing: 1}}>{item.instructor}</Text>
              </TouchableOpacity>
            )
          }} />

        <Row style={{height: 20, paddingLeft: 15, paddingRight: 15 ,marginBottom: 10}}>
          <TouchableOpacity onPress={this.pressOurInstructor} style={{flex: 0, flexDirection: 'row', alignItems: 'center'}}>
            <Text style={{color: '#202020', fontSize: 14, textTransform: 'uppercase', fontWeight: 'bold'}}>
              {language[props.language].title.feature_instructor}
            </Text>
            <Icon style={{fontSize: 12, marginLeft: 10, color: '#666666'}} name="chevron-right" type="FontAwesome5" />
          </TouchableOpacity>
        </Row>

        <FlatList
          data={props.listInstructor}
          horizontal={true}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{paddingLeft: 15, paddingRight: 5, marginBottom: 10}}
          renderItem={(data) => {
            const {item} = data

            return (
              <TouchableOpacity onPress={() => this.pressInstructorDetail(item.id)} style={[{width: 100, height: 130, marginRight: 10, alignItems: 'center'}]}>
                <Image style={{width: '100%', height: 100, borderRadius: 100/2, backgroundColor: 'rgba(0, 0, 0, 0.3)'}} defaultSource={noImage} source={{uri: item.photo}} />
                <Text numberOfLines={1} style={{fontSize: 10, color: '#202020', letterSpacing: 1, marginTop: 5}}>{item.name}</Text>
              </TouchableOpacity>
            )
          }} />

        <Row style={{flex: 0, height: 20, alignItems: 'center', paddingLeft: 15, paddingRight: 15 ,marginBottom: 10}}>
          <TouchableOpacity onPress={this.pressPlaylistNew} style={{flex: 0, flexDirection: 'row', alignItems: 'center'}}>
            <Text style={{color: '#202020', fontSize: 14, textTransform: 'uppercase', fontWeight: 'bold'}}>
              {language[props.language].title.feature_playlist}
            </Text>
            <Icon style={{fontSize: 12, marginLeft: 10, color: '#666666'}} name="chevron-right" type="FontAwesome5" />
          </TouchableOpacity>
        </Row>

        <FlatList
          data={props.listPlaylist}
          horizontal={true}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{paddingLeft: 15, paddingRight: 5, marginBottom: 10}}
          renderItem={(data) => {
            const {item} = data

            return (
              <TouchableOpacity onPress={() => this.pressPlaylistDetail(item.id)} style={[{width: 120, height: 150, marginRight: 10}]}>
                <Image style={{width: '100%', height: 120, backgroundColor: 'rgba(0, 0, 0, 0.3)'}} defaultSource={noImage} source={{uri: item.image}} />
                <Text numberOfLines={1} style={{fontSize: 12, color: '#202020', textTransform: 'uppercase', fontWeight: 'bold', letterSpacing: 1, marginTop: 5}}>{item.title}</Text>
              </TouchableOpacity>
            )
          }} />
      </Content>
    )
  }
}

HomeList.propTypes = {
  navigation: PropTypes.object,
  language: PropTypes.string,
  listBanner: PropTypes.array,
  listClass: PropTypes.array,
  listInstructor: PropTypes.array,
  listPlaylist: PropTypes.array,
}

HomeList.defaultProps = {
  language: 'EN',
}

export default HomeList
