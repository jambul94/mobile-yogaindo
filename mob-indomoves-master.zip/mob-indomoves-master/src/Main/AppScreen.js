import React from 'react'
import MainMenu from './component/MainMenu'
import MainDrawer from './component/MainDrawer'
import HomeList from '../Home/List'
import ClassesList from '../Classes/List'
import SeriesList from '../Series/List'
import UserPractice from '../User/Practice'
import Modal from 'react-native-modal'
import {Container, Col, Button, Footer, Icon} from 'native-base'
import {CustomHeader, CustomModalSpinner} from '../_component'
import {connect} from 'react-redux'
import {getListSeriesByCategories} from '../_actions/series'
import {getListClass} from '../_actions/classes'
import {asyncStorage} from '../_common/helper'
import {language} from '../_common/language'
import {NavigationEvents} from 'react-navigation'

class MainAppScreen extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      activePage: 0,
      category: null,
      category_temp: null,
      showModalMenu: false,
      showLoading: false,
    }

    this._didFocus = this._didFocus.bind(this)
    this.pressBackSeries = this.pressBackSeries.bind(this)
    this.pressHideModal = this.pressHideModal.bind(this)
    this.pressSeriesCategory = this.pressSeriesCategory.bind(this)
    this.pressShowModal = this.pressShowModal.bind(this)
    this.pressIconSearch = this.pressIconSearch.bind(this)
    this.pressMainMenu = this.pressMainMenu.bind(this)
  }

  _didFocus () {
    this.set_initialParams()
    this.set_inititalPage()
  }

  onChangeCategorySeries (nextCategory, nameCategory, callbk) {
    this.setState({
      category: nextCategory,
      category_temp: nameCategory,
    }, callbk && callbk())
  }

  onChangePage (nextPage, callBk) {
    this.setState({
      activePage: nextPage,
      category: null,
      category_temp: null,
    }, () => callBk && callBk())
  }

  onToggleModalMenu (nextState, callBk) {
    this.setState({
      showModalMenu: nextState,
    }, () => callBk && callBk())
  }

  pressBackSeries () {
    this.pressMainMenu(3)
  }

  pressHideModal (nextPage) {
    const {props} = this

    this.onToggleModalMenu(false, () => {
      if (nextPage !== undefined && nextPage !== null) {
        if (nextPage !== 'UserLogout') {
          props.navigation.navigate(nextPage)
        } else {
          asyncStorage.removeItem('@key_log').then(() => {
            props.navigation.navigate('MainAppAuth')
          })
        }
      }
    })
  }

  pressSeriesCategory (selectedItem) {
    const {props} = this

    this.onChangeCategorySeries(selectedItem.id, selectedItem.name, () => {
      props.dispatch(getListSeriesByCategories(selectedItem.id))
    })
  }

  pressShowModal () {
    this.onToggleModalMenu(true)
  }

  pressIconSearch () {
    const {props} = this

    props.navigation.navigate('MainAppSearch')
  }

  pressMainMenu (nextPage) {
    const {props} = this

    props.navigation.setParams({mode: null, activePage: nextPage})
    this.onChangePage(nextPage)
  }

  req_listClass () {
    const {props} = this

    this.toggle_loading(true)
    props.dispatch(getListClass(() => {
        this.toggle_loading(false)
      }, () => {
        this.toggle_loading(false)
      })
    )
  }

  req_listSeries () {
    const {props} = this
    const category = props.navigation.getParam('category', null)
    const category_temp = props.navigation.getParam('category_temp', null)

    this.toggle_loading(true)
    this.onChangeCategorySeries(category, category_temp, () => {
      props.dispatch(getListSeriesByCategories(category,
        () => {
          this.toggle_loading(false)
        }, () => {
          this.toggle_loading(false)
        })
      )
    })
  }

  set_inititalPage () {
    const {props} = this
    const mode = props.navigation.getParam('mode', null)
    const activePage = props.navigation.getParam('activePage', null)

    if (mode !== null && activePage !== null) {
      if (activePage === 2 && mode === 'filter') {
        this.pressMainMenu(activePage)
        this.req_listClass()
      }

      if (activePage === 3 && mode === 'filter') {
        this.pressMainMenu(activePage)
        this.req_listSeries()
      }
    } else if (mode === null && activePage !== null) {
      this.pressMainMenu(activePage)
    } else {
      this.pressMainMenu(1)
    }
  }

  set_initialParams () {
    const {props} = this

    props.navigation.setParams({mode: null})
  }

  toggle_loading (show, callbk) {
    this.setState({
      showLoading: show,
    }, callbk && callbk())
  }

  render () {
    const {props, state} = this

    return (
      <Container>
        <NavigationEvents
          onDidFocus={this._didFocus} />

        <CustomModalSpinner
          isVisible={state.showLoading} />

        <CustomHeader
          leftChildren={
            state.category !== null ? (
              <Button
                onPress={this.pressBackSeries}
                transparent={true}>

                <Icon style={{color: '#202020', fontSize: 16}} name="arrow-left" type="FontAwesome5" />
              </Button>
            ) : (
              <Button
                onPress={this.pressShowModal}
                transparent={true}>

                <Icon style={{color: '#202020', fontSize: 16}} name="bars" type="FontAwesome5" />
              </Button>
            )
          }
          rightChildren={
            <Button
              onPress={this.pressIconSearch}
              transparent={true}>

              <Icon style={{color: '#202020', fontSize: 16}} name="search" type="FontAwesome5" />
            </Button>
          }
          navigation={props.navigation} />

        <Col>
          {state.activePage === 1 && (
            <HomeList
              language={props.userInfo.language}
              listBanner={props.listBanner}
              listClass={props.listClass}
              listInstructor={props.listInstructor}
              listPlaylist={props.listPlaylist}
              navigation={props.navigation} />
          )}

          {state.activePage === 2 && (
            <ClassesList
              listClass={props.listClass}
              navigation={props.navigation} />
          )}

          {state.activePage === 3 && (
            <SeriesList
              category={state.category}
              category_temp={state.category_temp}
              listCategories={props.listCategories}
              listSeries={props.listSeries}
              navigation={props.navigation}
              onPressSeriesCategory={this.pressSeriesCategory} />
          )}

          {state.activePage === 4 && (
            <UserPractice
              navigation={props.navigation} />
          )}
        </Col>

        <Footer style={{backgroundColor: 'transparent'}}>
          <MainMenu
            icon="home"
            idMenu={1}
            isActive={state.activePage === 1}
            onPressMenu={this.pressMainMenu}
            text={language[props.userInfo.language].menu.main_home} />

          <MainMenu
            icon="youtube"
            idMenu={2}
            isActive={state.activePage === 2}
            onPressMenu={this.pressMainMenu}
            text={language[props.userInfo.language].menu.main_classes} />

          <MainMenu
            icon="th-large"
            idMenu={3}
            isActive={state.activePage === 3}
            onPressMenu={this.pressMainMenu}
            text={language[props.userInfo.language].menu.main_series} />

          <MainMenu
            icon="plus-circle"
            idMenu={4}
            isActive={state.activePage === 4}
            onPressMenu={this.pressMainMenu}
            text={language[props.userInfo.language].menu.main_practice} />
        </Footer>

        <Modal
          animationIn="slideInLeft"
          animationOut="slideOutRight"
          backdropColor="#075e54"
          backdropOpacity={1}
          backdropTransitionOutTiming={0}
          isVisible={state.showModalMenu}
          onBackButtonPress={this.pressHideModal}>

            <MainDrawer
              navigation={props.navigation}
              onPressCancel={this.pressHideModal}
              onPressMenu={this.pressHideModal} />
          </Modal>
      </Container>
    )
  }
}

const mapStateToProps = state => ({
  listBanner: state.contentRdc.banner,
  listCategories: state.categoriesRdc.categories,
  listClass: state.classRdc.classess,
  listSeries: state.seriesRdc.series,
  listInstructor: state.instructorRdc.instructor,
  listPlaylist: state.playlistRdc.playlist,
  userInfo: state.userRdc.userMeInfo,
})

export default connect(mapStateToProps)(MainAppScreen)
