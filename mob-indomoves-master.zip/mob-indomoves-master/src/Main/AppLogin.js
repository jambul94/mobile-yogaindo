import React from 'react'
import PhoneInput from 'react-native-phone-input'
import {Button, Col, Container, Item, Row, Text} from 'native-base'
import {CustomInput, CustomHeader, CustomModalSpinner} from '../_component'
import {NavigationEvents} from 'react-navigation'
import {showToast, serializeForm} from '../_common/helper'
import {postUserLogin} from '../_actions/auth'

class MainAppLogin extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      ...initStateFormLogin,
      showLoading: false,
    }

    this._didFocus = this._didFocus.bind(this)
    this.changeInput = this.changeInput.bind(this)
    this.initDefaultCountryCode = this.initDefaultCountryCode.bind(this)
    this.pressVerification = this.pressVerification.bind(this)
  }

  _didFocus () {
    this.initDefaultCountryCode()
  }

  onChangeInput (field, value, callbk) {
    this.setState({
      [field]: value,
    }, () => callbk && callbk())
  }

  changeInput (name, value) {
    const {state} = this
    let fixValue = value

    if (name === 'phone') {
      this.initDefaultCountryCode()
      fixValue  = fixValue.replace(/[^0-9]/g, '')

      if (state.phone === null  || state.phone === '') {
        if (value === '0') {
          fixValue = ''
        }
      }
    }

    this.onChangeInput(name, fixValue)
  }

  initDefaultCountryCode () {
    this.setState({
      country_call_code: this.inputPhone.getCountryCode(),
    })
  }

  pressVerification () {
    const {props, state} = this
    const formData = serializeForm(initStateFormLogin, state)

    if (formData.phone === '' || formData.phone === null) {
      showToast('Your phone number must be filled in', 'warning')
    } else {
      this.toggleLoading(true)
      postUserLogin(formData, (resp) => {
        const {status} = resp

        this.toggleLoading(false)
        if (status === 200) {
          props.navigation.navigate('MainAppVerification', {
            phone: formData.phone,
            country_call_code: formData.country_call_code,
          })
        }
      }, (err) => {
        const {status} = err

        this.toggleLoading(false)
        if (status === 404) {
          showToast('Your phone number was not found', 'warning')
        } else {
          showToast('Something error with internal system', 'error')
        }
      })
    }
  }

  toggleLoading (show, callbk) {
    this.setState({
      showLoading: show,
    }, callbk && callbk())
  }

  render () {
    const {props, state} = this

    return (
      <Container>
        <NavigationEvents
          onDidFocus={this._didFocus} />

        <CustomHeader
          navigation={props.navigation}
          noRight={true} />

        <CustomModalSpinner
          isVisible={state.showLoading} />

        <Col>
          <Row style={{backgroundColor: '#e4e4e4', height: 100, justifyContent: 'center', alignItems: 'center'}}>
            <Text style={{fontWeight: 'bold', fontSize: 22, letterSpacing: 5, textTransform: 'uppercase'}}>Welcome Back</Text>
          </Row>

          <Col style={{padding: 15}}>
            <Row style={{height: 50}}>
              <Item style={{flex: 1, height: 50, paddingLeft: 15}} regular={true}>
                <PhoneInput
                  ref={ref => {this.inputPhone = ref}}
                  initialCountry="id"
                  onSelectCountry={this.initDefaultCountryCode}
                  textProps={
                    {
                      keyboardType: 'number-pad',
                      name: 'phone',
                      onChangeText: this.changeInput,
                      placeholderTextColor: '#707070',
                      placeholder: `+${state.country_call_code}`,
                      returnKeyType: 'done',
                      style: {fontSize: 14},
                      value: state.phone,
                    }
                  }
                  textComponent={CustomInput} />
              </Item>
            </Row>
          </Col>

          <Row style={{flexDirection: 'column-reverse', padding: 10}}>
            <Button onPress={this.pressVerification} style={{backgroundColor: '#075e54', justifyContent: 'center'}}>
              <Text style={{fontSize: 14}}>Send Verification</Text>
            </Button>
          </Row>
        </Col>
      </Container>
    )
  }
}

const initStateFormLogin = {
  phone: '',
  country_call_code: '',
}

export default MainAppLogin
