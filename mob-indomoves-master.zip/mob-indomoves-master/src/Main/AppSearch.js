import React from 'react'
import {Col, Container, Icon, Row, Text} from 'native-base'
import {CustomHeader, CustomInput} from '../_component'
import {FlatList, Image, TouchableOpacity} from 'react-native'
import {connect} from 'react-redux'
import {language} from '../_common/language'
import {NavigationEvents} from 'react-navigation'
import {set_filterSeriesTextSearch} from '../_actions/filter'
import {get_listSearchSeries} from '../_actions/content'

class MainAppSearch extends React.Component {
  constructor (props) {
    super(props)

    this._willFocus = this._willFocus.bind(this)
    this.change_input = this.change_input.bind(this)
    this.press_clearSearch = this.press_clearSearch.bind(this)
    this.press_detailSeries = this.press_detailSeries.bind(this)
    this.press_search = this.press_search.bind(this)
  }

  _willFocus () {
    this.press_clearSearch()
  }

  change_input (name, value) {
    const {props} = this

    if (name === 'textSearch') {
      props.dispatch(set_filterSeriesTextSearch(value))
    }
  }

  press_clearSearch () {
    const {props} = this

    props.dispatch(set_filterSeriesTextSearch(''))
    props.dispatch(get_listSearchSeries())
  }

  press_detailSeries (uniqId) {
    const {props} = this

    props.navigation.navigate('SeriesDetail', {
      uniqId,
    })
  }

  press_search () {
    const {props} = this

    props.dispatch(get_listSearchSeries())
  }

  render () {
    const {props} = this
    const noImage = require('../assets/images/no-image.jpg')

    return (
      <Container>
        <NavigationEvents
          onWillFocus={this._willFocus} />

        <CustomHeader
          navigation={props.navigation}
          noRight={true}
          title={language[props.language].title.search_label} />

          <Col>
            <Row style={{backgroundColor: '#e4e4e4', height: 50, alignItems: 'center', paddingLeft: 15, paddingRight: 15}}>
              <Icon style={{fontSize: 16, color: '#202020'}} name="search" type="FontAwesome5" />
              <CustomInput
                onChangeText={this.change_input}
                name="textSearch"
                placeholder={language[props.language].title.search_placeholder}
                placeholderTextColor="#707070"
                style={{flex: 1, color: '#202020', marginLeft: 10, fontSize: 14}}
                value={props.textSearch} />

              {props.textSearch !== '' ? (
                <TouchableOpacity onPress={this.press_clearSearch} style={{height: 40, width: 48, justifyContent: 'center', alignItems: 'center'}}>
                  <Icon style={{color: '#707070', fontSize: 16}} name="times" type="FontAwesome5" />
                </TouchableOpacity>
              ) : null}
              <TouchableOpacity onPress={this.press_search} style={{backgroundColor: '#075e54', height: 40, width: 48, justifyContent: 'center', alignItems: 'center'}}>
                <Icon style={{color: '#f4f4f4f4', fontSize: 16}} name="arrow-right" type="FontAwesome5" />
              </TouchableOpacity>
            </Row>

            {props.listSeries.length > 0 ? (
              <FlatList
                data={props.listSeries}
                style={{padding: 15}}
                renderItem={({item}) => {
                  return (
                    <TouchableOpacity onPress={() => this.press_detailSeries(item.id)}>
                      <Row style={{marginBottom: 10}}>
                        <Image style={{width: 100, height: 60, backgroundColor: 'rgba(0, 0, 0, 0.3)'}} defaultSource={noImage} source={{uri: item.thumbnail}} />
                        <Col style={{justifyContent: 'center'}}>
                          <Text style={{color: '#202020', fontSize: 14, paddingLeft: 10}}>{item.name}</Text>
                          <Text style={{color: '#666666', fontSize: 12, paddingLeft: 10}}>{item.instructor}</Text>
                        </Col>
                      </Row>
                    </TouchableOpacity>
                  )
                }} />
            ) : (
              <Row style={{padding: 15, paddingTop: 50, justifyContent: 'center'}}>
                <Text style={{color: '#202020', fontSize: 14}}>
                  {language[props.language].title.empty_search.replace('[title]', language[props.language].menu.main_series.toLowerCase())}
                </Text>
              </Row>
            )}
          </Col>
      </Container>
    )
  }
}

MainAppSearch.defaultProps = {
  language: 'EN',
}

const mapStateToProps = state => ({
  language: state.userRdc.userMeInfo.language,
  listSeries: state.contentRdc.searchSeries,
  textSearch: state.filterRdc.series_textSearch,
})

export default connect(mapStateToProps)(MainAppSearch)
