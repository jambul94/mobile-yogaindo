import React from 'react'
import PropTypes from 'prop-types'
import {Badge, Col, Icon, Row, Text} from 'native-base'
import {Image, TouchableOpacity, View} from 'react-native'
import {connect} from 'react-redux'
import {language} from '../../_common/language'

class MainDrawer extends React.Component {
  constructor (props) {
    super(props)

    this.pressCancel = this.pressCancel.bind(this)
    this.pressDownload = this.pressDownload.bind(this)
    this.press_gethelp = this.press_gethelp.bind(this)
    this.press_logout = this.press_logout.bind(this)
    this.pressMyProfile = this.pressMyProfile.bind(this)
    this.pressNotification = this.pressNotification.bind(this)
    this.pressReward = this.pressReward.bind(this)
    this.pressSetting = this.pressSetting.bind(this)
  }

  pressCancel () {
    const {props} = this

    props.onPressCancel && props.onPressCancel()
  }

  pressDownload () {
    const {props} = this

    props.onPressMenu && props.onPressMenu('UserDownload')
  }

  press_gethelp () {
    const {props} = this

    props.onPressMenu && props.onPressMenu('ContentFaqList')
  }

  press_logout () {
    const {props} = this

    props.onPressMenu && props.onPressMenu('UserLogout')
  }

  pressMyProfile () {
    const {props} = this

    props.onPressMenu && props.onPressMenu('UserProfile')
  }

  pressNotification () {
    const {props} = this

    props.onPressMenu && props.onPressMenu('UserNotification')
  }

  pressReward () {
    const {props} = this

    props.onPressMenu && props.onPressMenu('RewardList')
  }

  pressSetting () {
    const {props} = this

    props.onPressMenu && props.onPressMenu('UserSetting')
  }

  render () {
    const {props} = this
    const logoGreen = require('../../assets/images/logo-green.png')

    return (
      <Col>
        <Row style={{flex: 0}}>
          <Row style={{flex: 0, width: 30}}>
            <Icon onPress={this.pressCancel} style={{fontSize: 20, color: '#ffffff', marginTop: 10}} name="times" type="FontAwesome5" />
          </Row>
          <Row style={{justifyContent: 'center'}}>
            <Image source={logoGreen} style={{width: 65, height: 65, marginTop: 30}} />
          </Row>
          <Row style={{flex: 0, width: 30}} />
        </Row>

        <Col style={{paddingTop: 15, alignItems: 'center'}}>
          <TouchableOpacity style={{padding: 5}} onPress={this.pressMyProfile}>
            <Text style={{color: '#ffffff', fontSize: 14, textTransform: 'uppercase', letterSpacing: 2}}>
              {language[props.language].menu.drawer_profile}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity style={{padding: 5}} onPress={this.pressNotification}>
            <Text style={{color: '#ffffff', fontSize: 14, textTransform: 'uppercase', letterSpacing: 2}}>
              {language[props.language].menu.drawer_notif}
            </Text>
            <Badge style={{position: 'absolute', right: props.countUnreadNotification > 9 ? -35 : -25, top: -5, backgroundColor: '#202020'}}>
              <Text style={{fontSize: 14}}>{props.countUnreadNotification > 100 ? '90+' : props.countUnreadNotification}</Text>
            </Badge>
          </TouchableOpacity>
          {/* <TouchableOpacity style={{padding: 5}} onPress={this.pressDownload}>
            <Text style={{color: '#ffffff', fontSize: 14, textTransform: 'uppercase', letterSpacing: 2}}>Download</Text>
          </TouchableOpacity> */}
          <TouchableOpacity style={{padding: 5}} onPress={this.pressReward}>
            <Text style={{color: '#ffffff', fontSize: 14, textTransform: 'uppercase', letterSpacing: 2}}>
              {language[props.language].menu.drawer_reward}
            </Text>
          </TouchableOpacity>

          <View style={{width:200 , padding: 5, marginBottom: 10, borderBottomColor: '#ffffff',opacity: .5, borderBottomWidth: 1}} />

          <TouchableOpacity style={{padding: 5}} onPress={this.pressSetting}>
            <Text style={{color: '#ffffff', opacity: .5, fontSize: 14, textTransform: 'uppercase', letterSpacing: 2}}>
              {language[props.language].menu.drawer_setting}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={this.press_gethelp} style={{padding: 5}}>
            <Text style={{color: '#ffffff', opacity: .5, fontSize: 14, textTransform: 'uppercase', letterSpacing: 2}}>
              {language[props.language].menu.drawer_help}
            </Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={this.press_logout} style={{padding: 5}}>
            <Text style={{color: '#ffffff', opacity: .5, fontSize: 14, textTransform: 'uppercase', letterSpacing: 2}}>
              {language[props.language].menu.logout}
            </Text>
          </TouchableOpacity>
        </Col>
      </Col>
    )
  }
}

MainDrawer.propTypes = {
  onPressCancel: PropTypes.func,
  onPressMenu: PropTypes.func,
}

MainDrawer.defaultProps = {
  language: 'EN',
}

const mapStateToProps = state => ({
  countUnreadNotification: state.userRdc.userMeNotificationUnreadCount,
  language: state.userRdc.userMeInfo.language,
})

export default connect(mapStateToProps)(MainDrawer)
