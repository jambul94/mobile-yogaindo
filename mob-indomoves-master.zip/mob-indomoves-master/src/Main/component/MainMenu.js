import React from 'react'
import PropTypes from 'prop-types'
import {Icon, Text} from 'native-base'
import {TouchableOpacity} from 'react-native'

const styleMenu = {
  wrapBox: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  icon: {
    fontSize: 22,
  },
  text: {
    fontSize: 10,
  },
  active: {
    color: '#202020',
  },
  inActive: {
    color: '#666666',
  },
}

class MainMenu extends React.Component {
  constructor (props) {
    super(props)

    this.pressMenu = this.pressMenu.bind(this)
  }

  pressMenu () {
    const {props} = this

    props.onPressMenu && props.onPressMenu(props.idMenu)
  }

  render () {
    const {props} = this
    const activeColor = props.isActive ? styleMenu.active : styleMenu.inActive

    return (
      <TouchableOpacity
        onPress={this.pressMenu}
        style={[styleMenu.wrapBox]}>

        <Icon style={[styleMenu.icon, activeColor]} type="FontAwesome5" name={props.icon} />
        <Text style={[styleMenu.text, activeColor]}>{props.text}</Text>
      </TouchableOpacity>
    )
  }
}

MainMenu.propTypes = {
  idMenu: PropTypes.number,
  icon: PropTypes.string,
  isActive: PropTypes.bool,
  onPressMenu: PropTypes.func,
  text: PropTypes.string,
}

MainMenu.defaultProps = {
  idMenu: 0,
  icon: null,
  isActive: false,
  text: null,
}

export default MainMenu
