import React from 'react'
import {Image, ImageBackground, StatusBar} from 'react-native'
import {Button, Container, Col, Footer, Row, Text} from 'native-base'

class MainAppSplash extends React.Component {
  constructor (props) {
    super(props)

    this.handlePressLogin = this.handlePressLogin.bind(this)
    this.pressRegister = this.pressRegister.bind(this)
  }

  handlePressLogin () {
    const {props} = this

    props.navigation.navigate('MainAppLogin')
  }

  pressRegister () {
    const {props} = this

    props.navigation.navigate('MainAppRegister')
  }

  render () {
    const bgSplash = require('../assets/images/bg-splash.jpg')
    const logoGreen = require('../assets/images/logo-green.png')

    return (
      <Container>
        <StatusBar backgroundColor="transparent" translucent={false} barStyle="dark-content" />

        <ImageBackground source={bgSplash} style={{flex: 1, width: null, height: null}}>
          <Col>
            <Row style={{justifyContent: 'center', paddingTop: 50}}>
              <Image source={logoGreen} style={{width: 150, height: 150}} />
            </Row>
          </Col>

          <Footer style={{backgroundColor: 'transparent', height: 65, padding: 10}}>
            <Row style={{paddingRight: 5}}>
              <Button onPress={this.pressRegister} style={{backgroundColor: '#075e54', justifyContent: 'center', width: '100%'}}>
                <Text style={{fontSize: 14}}>Register</Text>
              </Button>
            </Row>
            <Row style={{paddingLeft: 5}}>
              <Button onPress={this.handlePressLogin} style={{backgroundColor: '#075e54', justifyContent: 'center', width: '100%'}}>
                <Text style={{fontSize: 14}}>Log In</Text>
              </Button>
            </Row>
          </Footer>
        </ImageBackground>
      </Container>
    )
  }
}

export default MainAppSplash
