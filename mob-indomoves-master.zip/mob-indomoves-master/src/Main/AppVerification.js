import React from 'react'
import {Col, Container, Item, Row, Text} from 'native-base'
import {CustomInput, CustomHeader, CustomModalSpinner} from '../_component'
import {NavigationEvents} from 'react-navigation'
import {asyncStorage, serializeForm, showToast} from '../_common/helper'
import {postUserVerification} from '../_actions/auth'
import {connect} from 'react-redux'
import {getListCategories, get_listCategoriesStyle} from '../_actions/categories'
import {getListClass} from '../_actions/classes'
import {getListInstructor, get_listInstructorReward} from '../_actions/instructor'
import {getListPlaylist} from '../_actions/playlist'
import {get_listUserNotification, get_listUserReward, getUserMeInfo, getUserMeClass, getUserMeSeries, getuserMePlaylist} from '../_actions/user'
import {get_listBanner, get_listDifficulty, get_listFaq, get_listIntensity, get_listSosmed, get_listSubscribePackage} from '../_actions/content'

class MainAppVerification extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      ...initStateFormVerification,
      showLoading: false,
      timer: 60,
    }

    this._didFocus = this._didFocus.bind(this)
    this._willBlur = this._willBlur.bind(this)
    this.changeInput = this.changeInput.bind(this)
    this.countDown = this.countDown.bind(this)
    this.initDefaultPhoneNumber = this.initDefaultPhoneNumber.bind(this)
  }

  _didFocus () {
    this.initDefaultPhoneNumber()
    this.count = setInterval(() => {
      this.countDown()
    }, 1000)
  }

  _willBlur () {
    clearInterval(this.count)
  }

  initDefaultPhoneNumber () {
    const {props} = this
    const phoneNumber = props.navigation.getParam('phone')
    const countryCallCode = props.navigation.getParam('country_call_code')

    this.setState({
      phone: phoneNumber,
      country_call_code: countryCallCode,
    })
  }

  onChangeInput (field, value, callbk) {
    this.setState({
      [field]: value,
    }, () => callbk && callbk())
  }

  changeInput (name, value) {
    let fixValue  = value.replace(/[^0-9]/g, '')

    this.onChangeInput(name, fixValue, () => {
      this.reqVerification()
    })
  }

  countDown () {
    const {state} = this

    if (state.timer === 0) {
      clearInterval(this.count)
    } else {
      this.setState({
        timer: state.timer - 1,
      })
    }
  }

  reqVerification () {
    const {props, state} = this
    const formData = serializeForm(initStateFormVerification, state)

    if (formData.token !== null && formData.token.length === 7) {
      clearInterval(this.count)
      this.toggleLoading(true)
      postUserVerification(formData, (resp) => {
        const {data, status} = resp

        if (status === 200 && data.success) {
          asyncStorage.setItem('@key_log', data.access_token).then(async () => {
            try {
              await props.dispatch(getUserMeInfo())
              await props.dispatch(getUserMeClass())
              await props.dispatch(getUserMeSeries())
              await props.dispatch(getuserMePlaylist())
              await props.dispatch(get_listBanner())
              await props.dispatch(get_listDifficulty())
              await props.dispatch(get_listFaq())
              await props.dispatch(get_listIntensity())
              await props.dispatch(getListCategories())
              await props.dispatch(get_listCategoriesStyle())
              await props.dispatch(getListClass())
              await props.dispatch(getListInstructor())
              await props.dispatch(get_listInstructorReward())
              await props.dispatch(get_listUserNotification())
              await props.dispatch(get_listUserReward())
              await props.dispatch(getListPlaylist())
              await props.dispatch(get_listSosmed())
              await props.dispatch(get_listSubscribePackage())

              setTimeout(() => {
                this.toggleLoading(false, () => {
                  props.navigation.navigate('MainScreen')
                })
              }, 1000);
            } catch (err) {
              console.warn(`Get initial data in login failed: ${err}`)
            }
          })
        } else if (status === 200 && !data.success) {
          this.toggleLoading(false, () => {
            showToast(data.message, 'warning')
          })
        }
      }, () => {
        this.toggleLoading(false, () => {
          showToast('Something error with internal system', 'error')
        })
      })
    }
  }

  toggleLoading (show, callbk) {
    this.setState({
      showLoading: show,
    }, () => {
      setTimeout(() => {
        callbk && callbk()
      }, 500)
    })
  }

  render () {
    const {props, state} = this

    return (
      <Container>
        <NavigationEvents
          onDidFocus={this._didFocus}
          onWillBlur={this._willBlur} />

        <CustomHeader
          navigation={props.navigation}
          noRight={true} />

        <CustomModalSpinner isVisible={state.showLoading} />

        <Col>
          <Row style={{backgroundColor: '#e4e4e4', height: 100, justifyContent: 'center', alignItems: 'center'}}>
            <Text style={{fontWeight: 'bold', fontSize: 22, letterSpacing: 5, textTransform: 'uppercase'}}>Verification</Text>
          </Row>

          <Col style={{padding: 15}}>
            <Row style={{height: 50}}>
              <Item style={{flex: 1, height: 50}} regular={true}>
                <CustomInput
                  keyboardType="number-pad"
                  returnKeyType="done"
                  maxLength={7}
                  name="token"
                  onChangeText={this.changeInput}
                  placeholderTextColor="#707070"
                  placeholder="_ _ _ _ _ _ _"
                  style={{fontSize: 14, letterSpacing: 2}}
                  textAlign="center"
                  value={state.token} />
              </Item>
            </Row>
            <Row style={{justifyContent: 'flex-end', paddingTop: 20}}>
              <Text style={{fontSize: 14, color: '#707070'}}>{`Resending Code (${state.timer}s)`}</Text>
            </Row>
          </Col>
        </Col>
      </Container>
    )
  }
}

const initStateFormVerification = {
  phone: '',
  country_call_code: '',
  token: '',
}

export default connect()(MainAppVerification)
