import React from 'react'
import {Image, StatusBar} from 'react-native'
import {Col, Container} from 'native-base'
import {NavigationEvents} from 'react-navigation'
import {asyncStorage} from '../_common/helper'
import {connect} from 'react-redux'
import {getListCategories, get_listCategoriesStyle} from '../_actions/categories'
import {getListClass} from '../_actions/classes'
import {getListInstructor, get_listInstructorReward} from '../_actions/instructor'
import {getListPlaylist} from '../_actions/playlist'
import {get_listUserNotification, get_listUserReward, getUserMeInfo, getUserMeClass, getUserMeSeries, getuserMePlaylist} from '../_actions/user'
import {get_listBanner, get_listDifficulty, get_listFaq, get_listIntensity, get_listSosmed, get_listSubscribePackage} from '../_actions/content'

class MainAppSplashScreen extends React.Component {
  constructor (props) {
    super(props)

    this._didFocus = this._didFocus.bind(this)
  }

  async _didFocus () {
    const {props} = this
    const keyLog = await asyncStorage.getItem('@key_log').then(val => val)

    if (keyLog) {
      try {
        await props.dispatch(getUserMeInfo())
        await props.dispatch(getUserMeClass())
        await props.dispatch(getUserMeSeries())
        await props.dispatch(getuserMePlaylist())
        await props.dispatch(get_listBanner())
        await props.dispatch(get_listDifficulty())
        await props.dispatch(get_listFaq())
        await props.dispatch(get_listIntensity())
        await props.dispatch(getListCategories())
        await props.dispatch(get_listCategoriesStyle())
        await props.dispatch(getListClass())
        await props.dispatch(getListInstructor())
        await props.dispatch(get_listInstructorReward())
        await props.dispatch(get_listUserNotification())
        await props.dispatch(get_listUserReward())
        await props.dispatch(getListPlaylist())
        await props.dispatch(get_listSosmed())
        await props.dispatch(get_listSubscribePackage())

        setTimeout(() => {
          props.navigation.navigate('MainScreen')
        }, 1000)
      } catch (err) {
        console.warn(`Get initial data splashscreen failed: ${err}`)
      }
    } else {
      props.navigation.navigate('AuthScreen')
    }
  }

  render () {
    const logoGreen = require('../assets/images/logo-green.png')

    return (
      <Container>
        <NavigationEvents onDidFocus={this._didFocus} />
        <StatusBar backgroundColor="transparent" translucent={false} barStyle="dark-content" />

        <Col style={{backgroundColor: '#202020', justifyContent: 'center', alignItems: 'center'}}>
          <Image source={logoGreen} style={{width: 150, height: 150}} />
        </Col>
      </Container>
    )
  }
}

export default connect()(MainAppSplashScreen)
