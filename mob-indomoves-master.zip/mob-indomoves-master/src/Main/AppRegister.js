import React from 'react'
import PhoneInput from 'react-native-phone-input'
import {Button, Col, Container, Content, Footer, Item, Row, Text} from 'native-base'
import {CustomInput, CustomHeader, CustomModalSpinner, CustomRadioInput} from '../_component'
import {NavigationEvents} from 'react-navigation'
import {showToast, serializeForm} from '../_common/helper'
import {postUserRegister} from '../_actions/auth'

class MainAppRegister extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      ...initStateFormRegister,
      showLoading: false,
    }

    this._didFocus = this._didFocus.bind(this)
    this.changeInput = this.changeInput.bind(this)
    this.initDefaultCountryCode = this.initDefaultCountryCode.bind(this)
    this.pressSubmitRegister = this.pressSubmitRegister.bind(this)
  }

  _didFocus () {
    this.initDefaultCountryCode()
  }

  onChangeInput (field, value, callbk) {
    this.setState({
      [field]: value,
    }, () => callbk && callbk())
  }

  changeInput (name, value) {
    const {state} = this
    let fixValue = value

    if (name === 'phone') {
      this.initDefaultCountryCode()
      fixValue  = fixValue.replace(/[^0-9]/g, '')

      if (state.phone === null  || state.phone === '') {
        if (value === '0') {
          fixValue = ''
        }
      }
    }

    this.onChangeInput(name, fixValue)
  }

  initDefaultCountryCode () {
    this.setState({
      country_call_code: this.inputPhone.getCountryCode(),
    })
  }

  pressSubmitRegister () {
    const {props, state} = this
    const formData = serializeForm(initStateFormRegister, state)

    if (formData.name === '' || formData.name === null) {
      showToast('Your name must be filled in', 'warning')
    } else if (formData.gender === '' || formData.gender === null) {
      showToast('Your gender must be filled in', 'warning')
    } else if (formData.phone === '' || formData.phone === null) {
      showToast('Your phone number must be filled in', 'warning')
    } else if (formData.email === '' || formData.email === null) {
      showToast('Your email must be filled in', 'warning')
    } else if (formData.password === '' || formData.password === null) {
      showToast('Your password must be filled in', 'warning')
    } else {
      this.toggleLoading(true)
      postUserRegister(formData, (resp) => {
        const {status} = resp

        this.toggleLoading(false)
        if (status === 201) {
          props.navigation.navigate('MainAppVerification', {
            phone: formData.phone,
            country_call_code: formData.country_call_code,
          })
        }
      }, (err) => {
        const {data, status} = err

        this.toggleLoading(false)
        if (status === 400) {
          let msg = ''
          let key = ''

          for (key in data) {
            msg = data[key][0].replace('field', key)
          }

          showToast(msg, 'warning')
        } else {
          showToast('Something error with internal system', 'error')
        }
      })
    }
  }

  toggleLoading (show, callbk) {
    this.setState({
      showLoading: show,
    }, callbk && callbk())
  }

  render () {
    const {props, state} = this

    return (
      <Container>
        <NavigationEvents
          onDidFocus={this._didFocus} />

        <CustomHeader
          navigation={props.navigation}
          noRight={true} />

        <CustomModalSpinner
          isVisible={state.showLoading} />

        <Content>
          <Col style={{padding: 15}}>
            <Item style={{flex: 1, height: 50, marginBottom: 15}} regular={true}>
              <CustomInput
                name="name"
                onChangeText={this.changeInput}
                placeholderTextColor="#707070"
                placeholder="Name"
                style={{fontSize: 14}}
                textAlign="center"
                value={state.name} />
            </Item>

            <Item style={{flex: 1, height: 50, marginBottom: 15, justifyContent: 'center'}} regular={true}>
              <CustomRadioInput
                flexDirection="row"
                name="gender"
                onPress={this.changeInput}
                radioButtons={[
                  {label: 'Male', value: 'M'},
                  {label: 'Female', value: 'F'},
                ]}
                style={{marginTop: 5}} />
            </Item>

            <Item style={{flex: 1, height: 50, marginBottom: 15, paddingLeft: 15}} regular={true}>
              <PhoneInput
                ref={ref => {this.inputPhone = ref}}
                initialCountry="id"
                onSelectCountry={this.initDefaultCountryCode}
                textProps={
                  {
                    keyboardType: 'number-pad',
                    name: 'phone',
                    onChangeText: this.changeInput,
                    placeholderTextColor: '#707070',
                    placeholder: `+${state.country_call_code}`,
                    returnKeyType: 'done',
                    style: {fontSize: 14},
                    value: state.phone,
                  }
                }
                textComponent={CustomInput} />
            </Item>

            <Item style={{flex: 1, height: 50, marginBottom: 15}} regular={true}>
              <CustomInput
                name="email"
                onChangeText={this.changeInput}
                placeholderTextColor="#707070"
                placeholder="Email"
                style={{fontSize: 14}}
                textAlign="center"
                value={state.email} />
            </Item>

            <Item style={{flex: 1, height: 50, marginBottom: 15}} regular={true}>
              <CustomInput
                name="password"
                onChangeText={this.changeInput}
                placeholderTextColor="#707070"
                placeholder="Password"
                secureTextEntry={true}
                style={{fontSize: 14}}
                textAlign="center"
                value={state.password} />
            </Item>
          </Col>
        </Content>

        <Footer style={{backgroundColor: 'transparent', height:65, padding: 10}}>
          <Row>
            <Button onPress={this.pressSubmitRegister} block={true} style={{backgroundColor: '#075e54', justifyContent: 'center', width: '100%'}}>
              <Text style={{fontSize: 14}}>Register</Text>
            </Button>
          </Row>
        </Footer>
      </Container>
    )
  }
}

const initStateFormRegister = {
  email: '',
  name: '',
  password: '',
  gender: 'M',
  phone: '',
  country_call_code: '',
}

export default MainAppRegister
