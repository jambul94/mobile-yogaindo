import React from 'react'
import baseStores from '../_stores'
import {Root} from 'native-base'
import {createAppContainer, createSwitchNavigator} from 'react-navigation'
import {AuthNavigator, AppNavigator, SplashNavigator} from '../_common/navigator'
import {setTopLevelNavigator} from '../_common/navigationService'
import {Provider} from 'react-redux'

class MainAppContainer extends React.Component {
  render () {
    const MainAppNavigator = createAppContainer(
      createSwitchNavigator({
        AuthScreen: AuthNavigator,
        MainScreen: AppNavigator,
        SplashScreen: SplashNavigator,
      },{
        initialRouteName: 'SplashScreen',
      })
    )

    return (
      <Provider store={baseStores}>
        <Root>
          <MainAppNavigator ref={navigatorRef => setTopLevelNavigator(navigatorRef)} />
        </Root>
      </Provider>
    )
  }
}

export default MainAppContainer
