import React from 'react'
import PropTypes from 'prop-types'
import {Col, Row, Text} from 'native-base'
import {FlatList, Image} from 'react-native'

class RewardStudent extends React.Component {
  render () {
    const {props} = this
    const noImage = require('../assets/images/no-image.jpg')

    return props.listReward.length === 0 ? (
      <Col style={{alignItems: 'center', paddingTop: 50}}>
        <Text style={{color: '#666666'}}>No data available</Text>
      </Col>
    ) : (
      <FlatList
        data={props.listReward}
        style={{padding: 15}}
        renderItem={({item}) => {
          return (
            <Row style={{marginBottom: 10, alignItems: 'center'}}>
              <Image style={{width: 50, height: 50, borderRadius: 50/2, backgroundColor: 'rgba(0, 0, 0, 0.3)'}} defaultSource={noImage} source={{uri: item.photo_thumbnail}} />
              <Text style={{color: '#202020', fontSize: 14, paddingLeft: 10}}>{item.name}</Text>
            </Row>
          )
        }} />
    )
  }
}

RewardStudent.propTypes = {
  listReward: PropTypes.array,
}

RewardStudent.defaultProps = {
  listReward: [],
}

export default RewardStudent
