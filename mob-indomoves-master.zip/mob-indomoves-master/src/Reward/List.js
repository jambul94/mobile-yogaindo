import React from 'react'
import RewardStudent from './Student'
import RewardInstructor from './Instructor'
import {Container, Tab, Tabs} from 'native-base'
import {CustomHeader} from '../_component'
import {connect} from 'react-redux'
import {language} from '../_common/language'

class RewardList extends React.Component {
  render () {
    const {props} = this

    return (
      <Container>
        <CustomHeader
          navigation={props.navigation}
          noRight={true}
          title={language[props.language].menu.drawer_reward} />

        <Tabs
          tabContainerStyle={{elevation: 0}}
          tabBarUnderlineStyle={{backgroundColor: '#202020'}}
          tabBarInactiveTextColor="#666666"
          tabBarActiveTextColor="#202020">

            <Tab tabStyle={{backgroundColor: '#ffffff'}} activeTabStyle={{backgroundColor: '#ffffff'}} heading={language[props.language].title.reward_student}>
              <RewardStudent
                listReward={props.userReward} />
            </Tab>
            <Tab tabStyle={{backgroundColor: '#ffffff'}} activeTabStyle={{backgroundColor: '#ffffff'}} heading={language[props.language].title.reward_instructor}>
              <RewardInstructor
                listReward={props.instructorReward} />
            </Tab>
        </Tabs>
      </Container>
    )
  }
}

const mapStateToProp = state => ({
  instructorReward: state.instructorRdc.instructorReward,
  language: state.userRdc.userMeInfo.language,
  userReward: state.userRdc.userReward,
})

export default connect(mapStateToProp)(RewardList)
