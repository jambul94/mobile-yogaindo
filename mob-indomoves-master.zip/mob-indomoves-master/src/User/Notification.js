import React from 'react'
import {Col, Container, Content, Text} from 'native-base'
import {CustomHeader} from '../_component'
import {TouchableOpacity} from 'react-native'
import {connect} from 'react-redux'
import {language} from '../_common/language'

class UserNotification extends React.Component {
  constructor (props) {
    super(props)

    this.press_itemNotification = this.press_itemNotification.bind(this)
  }

  press_itemNotification (item) {
    const {props} = this

    if (item.target === 'workout') {
      props.navigation.navigate('ClassesDetail', {
        uniqId: item.target_id,
        postRead: {
          content_type: 'workouts',
          object_id: item.target_id,
        },
        unread: item.unread,
      })
    } else {
      props.navigation.navigate('SeriesDetail', {
        uniqId: item.target_id,
        postRead: {
          content_type: item.target,
          object_id: item.target_id,
        },
        unread: item.unread,
      })
    }
  }

  render () {
    const {props} = this

    return (
      <Container>
        <CustomHeader
            navigation={props.navigation}
            title={language[props.language].menu.drawer_notif} />

        <Col style={{paddingVertical: 15}}>
          <Content style={{paddingHorizontal: 15}}>
            {props.userNotification.map(item => (
              <TouchableOpacity key={`notif-user-${item.id}`} onPress={() => this.press_itemNotification(item)} style={{paddingVertical: 15, borderBottomColor: '#666666', borderBottomWidth: 0.5}}>
                <Text style={{color: item.unread ? '#075e54' : '#202020', fontSize: 14}}>{item.text}</Text>
                <Text style={{color: '#666666', fontSize: 12}}>1 hours, 5 minutes ago</Text>
              </TouchableOpacity>
            ))}
          </Content>
        </Col>
      </Container>
    )
  }
}

const mapStateToProps = state => ({
  language: state.userRdc.userMeInfo.language,
  userNotification: state.userRdc.userMeNotification,
})

export default connect(mapStateToProps)(UserNotification)
