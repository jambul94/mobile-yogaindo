import React from 'react'
import {Col, Container, Icon, Text} from 'native-base'
import {TouchableOpacity} from 'react-native'
import {CustomHeader} from '../_component'

class UserDownload extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      listDownload: [],
    }

    this.pressSetting = this.pressSetting.bind(this)
  }

  pressSetting () {
    const {props} = this

    props.navigation.push('UserDownloadSetting')
  }

  render () {
    const {props, state} = this

    return (
      <Container>
        <CustomHeader
          navigation={props.navigation}
          rightChildren={
            <TouchableOpacity onPress={this.pressSetting} style={{paddingRight: 5}}>
              <Text style={{color: '#202020', fontSize: 10, textTransform: 'uppercase'}}>Setting</Text>
            </TouchableOpacity>
          }
          title="Downloads" />

        {state.listDownload.length === 0 ? (
          <Col style={{justifyContent: 'center', alignItems: 'center'}}>
            <Icon style={{color: '#202020', fontSize: 40, padding: 20}} name="arrow-alt-circle-down" type="FontAwesome5" />
            <Text style={{color: '#202020', fontSize: 14, textTransform: 'uppercase', letterSpacing: 1}}>You Have No Downloads</Text>
            <Text style={{color: '#202020', fontSize: 14, textTransform: 'uppercase', letterSpacing: 1}}>In Progress</Text>
            <Text style={{color: '#666666', fontSize: 12, paddingLeft: 100, paddingRight: 100, paddingTop: 50, textAlign: 'center'}}>You can download classes for offline acces. Just tap the downlod button on any of your classes or series to get started.</Text>
          </Col>
        ) : null}
      </Container>
    )
  }
}

export default UserDownload
