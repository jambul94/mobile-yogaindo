import React from 'react'
import SwitchToggle from '@dooboo-ui/native-switch-toggle'
import {Container, Col, Content, Icon, Row, Text} from 'native-base'
import {Linking, TouchableOpacity, View} from 'react-native'
import {CustomHeader, CustomModalSpinner} from '../_component'
import {asyncStorage, showToast} from '../_common/helper'
import {connect} from 'react-redux'
import {language} from '../_common/language'
import {getListCategories, get_listCategoriesStyle} from '../_actions/categories'
import {getListClass} from '../_actions/classes'
import {getListInstructor, get_listInstructorReward} from '../_actions/instructor'
import {getListPlaylist} from '../_actions/playlist'
import {get_listUserNotification, get_listUserReward, getUserMeInfo, getUserMeClass, getUserMeSeries, getuserMePlaylist, update_userMeInfo} from '../_actions/user'
import {get_listBanner, get_listDifficulty, get_listFaq, get_listIntensity, get_listSubscribePackage} from '../_actions/content'
import {
  set_filterClassSort, set_filterFaqTextSearch, set_filterInstructorSort,
  set_filterPlaylistrSort, set_filterSeriesSort,
  set_filterUserClassSort, set_filterUserPlaylistSort, set_filterUserSeriesSort,
} from '../_actions/filter'

class UserSetting extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      isPrivate: false,
      showLoading: false,
    }

    this.pressEditProfile = this.pressEditProfile.bind(this)
    this.pressTogglePrivate = this.pressTogglePrivate.bind(this)
    this.press_menuLogout = this.press_menuLogout.bind(this)
    this.press_menuPrivacyPolice = this.press_menuPrivacyPolice.bind(this)
    this.press_menuTos = this.press_menuTos.bind(this)
    this.press_sosmedIcon = this.press_sosmedIcon.bind(this)
    this.press_toggleLanguage = this.press_toggleLanguage.bind(this)
  }

  onTogglePrivate (nextPrivate, callbk) {
    this.setState({
      isPrivate: nextPrivate,
    }, callbk && callbk())
  }

  pressEditProfile () {
    const {props} = this

    props.navigation.push('UserEditProfile')
  }

  pressTogglePrivate () {
    const {state} = this

    this.onTogglePrivate(!state.isPrivate)
  }

  press_menuLogout () {
    const {props} = this

    asyncStorage.removeItem('@key_log').then(() => {
      props.navigation.navigate('MainAppAuth')
    })
  }

  press_menuPrivacyPolice () {
    const {props} = this

    props.navigation.navigate('ContentPrivacyPolice')
  }

  press_menuTos () {
    const {props} = this

    props.navigation.navigate('ContentTos')
  }

  press_sosmedIcon (item) {
    const link = item.key === 'email' ? 'mailto:' + item.value : item.value

    Linking.canOpenURL(link).then(support => {
      if (support) {
        Linking.openURL(link)
      }
    })
  }

  press_toggleLanguage () {
    const {props} = this
    let activeLanguage = props.userInfo.language

    if (activeLanguage === 'EN') {
      activeLanguage = 'ID'
    } else {
      activeLanguage = 'EN'
    }

    this.toggle_showLoading(true)
    props.dispatch(update_userMeInfo({
      language: activeLanguage,
    }, async () => {
      props.dispatch(set_filterFaqTextSearch(''))
      props.dispatch(set_filterClassSort(null, ''))
      props.dispatch(set_filterInstructorSort(null, ''))
      props.dispatch(set_filterPlaylistrSort(null, ''))
      props.dispatch(set_filterSeriesSort(null, ''))
      props.dispatch(set_filterUserClassSort(null, ''))
      props.dispatch(set_filterUserPlaylistSort(null, ''))
      props.dispatch(set_filterUserSeriesSort(null, ''))

      try {
        await props.dispatch(get_listDifficulty())
        await props.dispatch(get_listFaq())
        await props.dispatch(get_listIntensity())
        await props.dispatch(getListCategories())
        await props.dispatch(get_listCategoriesStyle())
        await props.dispatch(getListClass())
        await props.dispatch(getListInstructor())
        await props.dispatch(get_listInstructorReward())
        await props.dispatch(get_listUserNotification())
        await props.dispatch(get_listUserReward())
        await props.dispatch(getListPlaylist())
        await props.dispatch(getUserMeInfo())
        await props.dispatch(getUserMeClass())
        await props.dispatch(getUserMeSeries())
        await props.dispatch(getuserMePlaylist())
        await props.dispatch(get_listBanner())
        await props.dispatch(get_listSubscribePackage())

        this.toggle_showLoading(false)
      } catch {
        this.toggle_showLoading(false, () => {
          showToast('Some data failed to sync with current language', 'warning')
        })
      }
    }, () => {
      this.toggle_showLoading(false, () => {
        showToast('Language failed to update', 'warning')
      })
    }))
  }

  toggle_showLoading (show, callbk) {
    this.setState({
      showLoading: show,
    }, () => {
      setTimeout(() => {
        callbk && callbk()
      }, 500)
    })
  }

  render () {
    const {props, state} = this

    return (
      <Container>
        <CustomHeader
          navigation={props.navigation}
          noRight={true}
          title={language[props.language].menu.drawer_setting} />

        <CustomModalSpinner
          isVisible={state.showLoading} />

        <Content>
          <Col style={{padding: 15}}>
            <Text style={{color: '#202020', fontSize: 16, textTransform: 'uppercase', fontWeight: 'bold', letterSpacing: 1}}>
              {language[props.language].title.setting_account}
            </Text>
            <Row style={{flex: 0, borderBottomColor: '#666666', borderBottomWidth: 1, paddingTop: 10, paddingBottom: 10}}>
              <TouchableOpacity onPress={this.pressEditProfile} style={{flex: 1, flexDirection: 'row'}}>
                <Text style={{flex: 1, fontSize: 14, textTransform: 'uppercase', color: '#202020', letterSpacing: 1}}>
                  {language[props.language].title.profile_edit}
                </Text>
                <Icon style={{fontSize: 14, alignSelf: 'flex-end', color: '#666666'}} name="chevron-right" type="FontAwesome5" />
              </TouchableOpacity>
            </Row>

            <Text style={{color: '#202020', fontSize: 16, textTransform: 'uppercase', fontWeight: 'bold', letterSpacing: 1, marginTop: 30}}>
              {language[props.language].title.setting_display}
            </Text>
            <Row style={{borderBottomColor: '#666666', borderBottomWidth: 1, paddingTop: 10, paddingBottom: 10}}>
              <Col style={{flex: 2, justifyContent: 'center'}}>
                <Text style={{fontSize: 14, textTransform: 'uppercase', color: '#202020', letterSpacing: 1}}>
                  {language[props.language].title.setting_language}
                </Text>
              </Col>

              <Col style={{flex: 1, alignItems: 'flex-end'}}>
                <SwitchToggle
                  buttonStyle={{alignItems: 'center', justifyContent: 'center', position: 'absolute'}}
                  circleColorOn="#075e54"
                  circleStyle={{width: 20,height: 20,borderRadius: 5}}
                  containerStyle={{width: 80,height: 30,borderRadius: 5,backgroundColor: '#666666',padding: 5}}
                  backTextLeft={props.userInfo.language === 'EN' ? 'EN' : null}
                  backTextRight={props.userInfo.language === 'EN' ? null : 'ID'}
                  leftContainerStyle={{flex: 1, alignItems: 'center', justifyContent: 'flex-start'}}
                  onPress={this.press_toggleLanguage}
                  rightContainerStyle={{flex: 1, alignItems: 'center', justifyContent: 'center'}}
                  textLeftStyle={{color: '#202020'}}
                  textRightStyle={{color: '#202020'}}
                  switchOn={props.userInfo.language === 'EN' ? true : false}
                  type={1} />
              </Col>
            </Row>

            <Text style={{color: '#202020', fontSize: 16, textTransform: 'uppercase', fontWeight: 'bold', letterSpacing: 1, marginTop: 30}}>
              {language[props.language].title.setting_privacy}
            </Text>
            <Row style={{borderBottomColor: '#666666', borderBottomWidth: 1, paddingTop: 10, paddingBottom: 10}}>
              <Col style={{flex: 2, justifyContent: 'center'}}>
                <Text style={{fontSize: 14, textTransform: 'uppercase', color: '#202020', letterSpacing: 1}}>
                  {language[props.language].title.setting_private}
                </Text>
              </Col>

              <Col style={{flex: 1, alignItems: 'flex-end'}}>
                <SwitchToggle
                  buttonStyle={{alignItems: 'center', justifyContent: 'center', position: 'absolute'}}
                  circleColorOn="#075e54"
                  circleStyle={{width: 20,height: 20,borderRadius: 5}}
                  containerStyle={{width: 80,height: 30,borderRadius: 5,backgroundColor: '#666666',padding: 5}}
                  backTextLeft={state.isPrivate ? language[props.language].title.setting_private_on : null}
                  backTextRight={state.isPrivate ? null : language[props.language].title.setting_private_off}
                  leftContainerStyle={{flex: 1, alignItems: 'center', justifyContent: 'flex-start'}}
                  onPress={this.pressTogglePrivate}
                  rightContainerStyle={{flex: 1, alignItems: 'center', justifyContent: 'center'}}
                  textLeftStyle={{color: '#202020'}}
                  textRightStyle={{color: '#202020'}}
                  switchOn={state.isPrivate}
                  type={1} />
              </Col>
            </Row>

            <Text style={{color: '#202020', fontSize: 16, textTransform: 'uppercase', fontWeight: 'bold', letterSpacing: 1, marginTop: 30}}>
              {language[props.language].title.setting_support}
            </Text>
            <Row style={{flex: 0, borderBottomColor: '#666666', borderBottomWidth: 1, paddingTop: 10, paddingBottom: 10}}>
              <TouchableOpacity onPress={this.press_menuPrivacyPolice} style={{flex: 1, flexDirection: 'row'}}>
                <Text style={{flex: 1, fontSize: 14, textTransform: 'uppercase', color: '#202020', letterSpacing: 1}}>
                  {language[props.language].title.setting_policy}
                </Text>
                <Icon style={{fontSize: 14, alignSelf: 'flex-end', color: '#666666'}} name="chevron-right" type="FontAwesome5" />
              </TouchableOpacity>
            </Row>
            <Row style={{flex: 0, borderBottomColor: '#666666', borderBottomWidth: 1, paddingTop: 10, paddingBottom: 10}}>
              <TouchableOpacity onPress={this.press_menuTos} style={{flex: 1, flexDirection: 'row'}}>
                <Text style={{flex: 1, fontSize: 14, textTransform: 'uppercase', color: '#202020', letterSpacing: 1}}>
                  {language[props.language].title.setting_tos}
                </Text>
                <Icon style={{fontSize: 14, alignSelf: 'flex-end', color: '#666666'}} name="chevron-right" type="FontAwesome5" />
              </TouchableOpacity>
            </Row>

            <Row style={{justifyContent: 'center', marginTop: 20, marginBottom: 10}}>
              <Text style={{color: '#202020', fontSize: 20, fontWeight: 'bold', letterSpacing: 1}}>Yoga</Text>
              <Text style={{color: '#202020', fontSize: 20, textTransform: 'uppercase', letterSpacing: 1}}>Indo</Text>
            </Row>
            <Row style={{justifyContent: 'center', marginBottom: 10}}>
              <Text style={{fontSize: 10, color: '#666666'}}>v 4.3.7</Text>
            </Row>

            <Row style={{justifyContent: 'center'}}>
              {props.sosmed.map(item => {
                const icon = item.key === 'email' ? 'google' : item.key

                return (
                  <TouchableOpacity key={`sosmed-icon-${item.id}`} style={{padding: 6}} onPress={() => this.press_sosmedIcon(item)}>
                    <Icon style={{fontSize: 14, alignSelf: 'flex-end', color: '#666666', fontSize: 19}} name={icon} type="FontAwesome5" />
                  </TouchableOpacity>
                )
              })}
            </Row>

            <View style={{width: '100%', padding: 5, borderBottomColor: '#666666', borderBottomWidth: 1}} />
            <Row style={{justifyContent: 'center', paddingTop: 10, paddingBottom: 10}}>
              <TouchableOpacity onPress={this.press_menuLogout}>
                <Text style={{fontSize: 14, color: '#202020', textTransform: 'uppercase', letterSpacing: 1}}>
                  {language[props.language].menu.logout}
                </Text>
              </TouchableOpacity>
            </Row>
          </Col>
        </Content>
      </Container>
    )
  }
}

const mapStateToProps = state => ({
  language: state.userRdc.userMeInfo.language,
  sosmed: state.contentRdc.sosmed,
  userInfo: state.userRdc.userMeInfo,
})

export default connect(mapStateToProps)(UserSetting)
