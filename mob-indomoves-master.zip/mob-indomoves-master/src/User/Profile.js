import React from 'react'
import UserLogs from './Logs'
import {Button, Col, Container, Content, Row, Text} from 'native-base'
import {CustomHeader} from '../_component'
import {Image, ImageBackground, TouchableOpacity, View} from 'react-native'
import {connect} from 'react-redux'
import {language} from '../_common/language'

class UserProfile extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      activeTab: 0,
    }

    this.pressEditProfile = this.pressEditProfile.bind(this)
    this.pressCalendar = this.pressCalendar.bind(this)
    this.pressLogs = this.pressLogs.bind(this)
  }

  pressEditProfile () {
    const {props} = this

    props.navigation.navigate('UserEditProfile')
  }

  pressLogs () {
    this.setState({
      activeTab: 0,
    })
  }

  pressCalendar () {
    const {props} = this

    props.navigation.navigate('UserActivities')
  }

  render () {
    const {props, state} = this
    const noImage = require('../assets/images/no-image.jpg')

    return (
      <Container>
        <CustomHeader navigation={props.navigation} />

        <Content>
          <Col>
            <ImageBackground style={{flex: 1, width: null, height: 150, alignItems: 'center', marginBottom: 90, backgroundColor: 'rgba(0, 0, 0, 0.3)'}} defaultSource={noImage} source={{uri: props.userInfo.cover_image}}>
              <Image style={{width: 100, height: 100, borderRadius: 100/2, position: 'absolute', bottom: -75, backgroundColor: '#e4e4e4'}} defaultSource={noImage} source={{uri: props.userInfo.photo_thumbnail}} />
            </ImageBackground>
          </Col>

          {/* <Row style={{padding: 15}}>
            <Col style={{alignItems: 'center'}}>
              <Text style={{fontSize: 12, color: '#202020', fontWeight: 'bold'}}>2</Text>
              <Text style={{fontSize: 12, color: '#666666', textTransform: 'uppercase', letterSpacing: 1}}>
                {language[props.language].menu.main_classes}
              </Text>
            </Col>
            <Col style={{alignItems: 'center'}}>
              <Text style={{fontSize: 12, color: '#202020', fontWeight: 'bold'}}>2</Text>
              <Text style={{fontSize: 12, color: '#666666', textTransform: 'uppercase', letterSpacing: 1}}>
                {language[props.language].title.profile_follower}
              </Text>
            </Col>
            <Col style={{alignItems: 'center'}}>
              <Text style={{fontSize: 12, color: '#202020', fontWeight: 'bold'}}>2</Text>
              <Text style={{fontSize: 12, color: '#666666', textTransform: 'uppercase', letterSpacing: 1}}>
                {language[props.language].title.profile_following}
              </Text>
            </Col>
          </Row> */}

          <Row style={{padding: 15, justifyContent: 'center'}}>
            <Button onPress={this.pressEditProfile} style={{backgroundColor: '#075e54', justifyContent: 'center', paddingLeft: 30, paddingRight: 30}}>
              <Text style={{fontSize: 14, textTransform: 'uppercase', letterSpacing: 1}}>
                {language[props.language].title.profile_edit}
              </Text>
            </Button>
          </Row>

          <Row style={{justifyContent: 'center'}}>
            <Text style={{fontSize: 16, color: '#202020', textTransform: 'uppercase', letterSpacing: 2, fontWeight: 'bold'}}>{props.userInfo.name}</Text>
          </Row>

          <View style={{borderBottomColor: '#666666', borderBottomWidth: 1, marginLeft: 15, marginRight: 15, marginTop: 15}} />

          {/* <Row style={{padding: 15}}>
            <Col style={{alignItems: 'center', borderBottomWidth: state.activeTab === 0 ? 1 : 0, borderBottomColor: '#202020'}}>
              <TouchableOpacity style={{padding: 10}} onPress={this.pressLogs}>
                <Text style={{color: '#202020', fontSize: 12, textTransform: 'uppercase', letterSpacing: 1}}>Logs</Text>
              </TouchableOpacity>
            </Col>
            <Col style={{alignItems: 'center', borderBottomWidth: state.activeTab === 1 ? 1 : 0, borderBottomColor: '#202020'}}>
              <TouchableOpacity style={{padding: 10}} onPress={this.pressCalendar}>
                <Text style={{color: '#202020', fontSize: 12, textTransform: 'uppercase', letterSpacing: 1}}>Calendar</Text>
              </TouchableOpacity>
            </Col>
          </Row>

          {state.activeTab === 0 ? (
            <UserLogs />
          ) : null} */}
        </Content>
      </Container>
    )
  }
}

const mapStateToProps = state => ({
  language: state.userRdc.userMeInfo.language,
  userInfo: state.userRdc.userMeInfo,
})

export default connect(mapStateToProps)(UserProfile)
