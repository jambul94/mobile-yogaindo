import React from 'react'
import {Col, Container, Icon, Row, Text} from 'native-base'
import {TouchableOpacity, View} from 'react-native'
import {CustomHeader} from '../_component'

class UserDownloadSetting extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      modeDownload: true,
      listDownload: [],
    }

    this.pressToggleSetting = this.pressToggleSetting.bind(this)
  }

  onToggleSetting (nextMode, callbk) {
    this.setState({
      modeDownload: nextMode,
    }, () => callbk && callbk())
  }

  pressToggleSetting () {
    const {state} = this

    this.onToggleSetting(!state.modeDownload)
  }

  render () {
    const {props, state} = this
    const styleWifiOnly = state.modeDownload ? '#202020' : '#666666'
    const styleWifiCellular = state.modeDownload ? '#666666' : '#202020'

    return (
      <Container>
        <CustomHeader
          navigation={props.navigation}
          noRight={true}
          title="Downloads Setting" />

        <Col style={{padding: 15}}>
          <Text style={{color: '#202020', fontSize: 16, textTransform: 'uppercase', fontWeight: 'bold', letterSpacing: 1}}>Allow Downloads</Text>
          <View style={{width: '100%', padding: 5, borderBottomColor: '#666666', borderBottomWidth: 1}} />

          <Row style={{flex: 0, borderBottomColor: '#666666', borderBottomWidth: 1, paddingTop: 10, paddingBottom: 10}}>
            <TouchableOpacity onPress={this.pressToggleSetting} style={{flex: 1, flexDirection: 'row'}}>
              <Text style={{flex: 1, fontSize: 14, textTransform: 'uppercase', color: styleWifiOnly, letterSpacing: 1}}>Wi-fi Only</Text>
              {state.modeDownload && <Icon style={{fontSize: 14, alignSelf: 'flex-end', color: '#202020'}} name="check" type="FontAwesome5" /> }
            </TouchableOpacity>
          </Row>

          <Row style={{flex: 0, borderBottomColor: '#666666', borderBottomWidth: 1, paddingTop: 10, paddingBottom: 10}}>
            <TouchableOpacity onPress={this.pressToggleSetting} style={{flex: 1, flexDirection: 'row'}}>
              <Text style={{flex: 1, fontSize: 14, textTransform: 'uppercase', color: styleWifiCellular, letterSpacing: 1}}>Wi-fi and Cellular</Text>
              {!state.modeDownload && <Icon style={{fontSize: 14, alignSelf: 'flex-end', color: '#202020'}} name="check" type="FontAwesome5" /> }
            </TouchableOpacity>
          </Row>

          <Text style={{fontSize: 10, color: '#666666', marginTop: 20}}>Note : Downloads may result in standard data charges from your mobile carrier or internet service provider</Text>
        </Col>
      </Container>
    )
  }
}

export default UserDownloadSetting
