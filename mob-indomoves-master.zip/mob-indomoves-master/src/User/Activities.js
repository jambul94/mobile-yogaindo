import React from 'react'
import UserCalendar from './Calendar'
import UserStats from './Stats'
import {Col, Container, Row, Text} from 'native-base'
import {CustomHeader} from '../_component'
import {TouchableOpacity} from 'react-native'

class UserActivities extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      activeTab: 0,
    }

    this.pressCalendar = this.pressCalendar.bind(this)
    this.pressStats = this.pressStats.bind(this)
  }

  pressCalendar () {
    this.setState({
      activeTab: 0,
    })
  }

  pressStats () {
    this.setState({
      activeTab: 1,
    })
  }

  render () {
    const {props, state} = this

    return (
      <Container>
        <CustomHeader
          navigation={props.navigation}
          title="All Activities" />

        <Col style={{maxHeight: 70}}>
          <Row style={{padding: 15}}>
            <Col style={{alignItems: 'center', borderBottomWidth: state.activeTab === 0 ? 1 : 0, borderBottomColor: '#202020'}}>
              <TouchableOpacity style={{padding: 10}} onPress={this.pressCalendar}>
                <Text style={{color: '#202020', fontSize: 12, textTransform: 'uppercase', letterSpacing: 1}}>Calendar</Text>
              </TouchableOpacity>
            </Col>
            <Col style={{alignItems: 'center', borderBottomWidth: state.activeTab === 1 ? 1 : 0, borderBottomColor: '#202020'}}>
              <TouchableOpacity style={{padding: 10}} onPress={this.pressStats}>
                <Text style={{color: '#202020', fontSize: 12, textTransform: 'uppercase', letterSpacing: 1}}>Stats</Text>
              </TouchableOpacity>
            </Col>
          </Row>
        </Col>

        {state.activeTab === 0 ? (
          <Col>
            <Row style={{height: 50, paddingHorizontal: 15, alignItems: 'center'}}>
              <Row style={{justifyContent: 'center'}}>
                <Text style={{fontSize: 14, fontWeight: 'bold'}}>S</Text>
              </Row>
              <Row style={{justifyContent: 'center'}}>
                <Text style={{fontSize: 14, fontWeight: 'bold'}}>M</Text>
              </Row>
              <Row style={{justifyContent: 'center'}}>
                <Text style={{fontSize: 14, fontWeight: 'bold'}}>T</Text>
              </Row>
              <Row style={{justifyContent: 'center'}}>
                <Text style={{fontSize: 14, fontWeight: 'bold'}}>W</Text>
              </Row>
              <Row style={{justifyContent: 'center'}}>
                <Text style={{fontSize: 14, fontWeight: 'bold'}}>T</Text>
              </Row>
              <Row style={{justifyContent: 'center'}}>
                <Text style={{fontSize: 14, fontWeight: 'bold'}}>F</Text>
              </Row>
              <Row style={{justifyContent: 'center'}}>
                <Text style={{fontSize: 14, fontWeight: 'bold'}}>S</Text>
              </Row>
            </Row>

            <UserCalendar />
          </Col>
        ) : null}

        {state.activeTab === 1  ? (
          <UserStats />
        ) : null}
      </Container>
    )
  }
}

export default UserActivities
