import React from 'react'
import PropTypes from 'prop-types'
import {CalendarList} from 'react-native-calendars'

class UserCalendar extends React.Component {
  render () {
    return (
      <CalendarList
        theme={{
          textDayFontSize: 12,
        }}
        calendarHeight={310}
        hideDayNames={true}
        futureScrollRange={0}
        pastScrollRange={6} />
    )
  }
}

UserCalendar.propTypes = {
  navigation: PropTypes.object,
}

export default UserCalendar
