import React from 'react'
import PropsTypes from 'prop-types'
import UserClasses from './Classes'
import UserSeries from './Series'
import UserPlaylist from './Playlist'
import {Col, Row, Text, Tabs, Tab} from 'native-base'
import {connect} from 'react-redux'
import {language} from '../_common/language'

class UserPractice extends React.Component {
  render () {
    const {props} = this

    return (
      <Col>
        <Row style={{backgroundColor: '#e4e4e4', height: 100}}>
          <Col style={{justifyContent: 'center', alignItems: 'center'}}>
            <Text style={{fontWeight: 'bold', fontSize: 20, color: '#202020', letterSpacing: 5, textTransform: 'uppercase'}}>
              {language[props.language].menu.main_practice}
            </Text>
            <Text style={{fontSize: 12, color: '#666666', letterSpacing: 2, textTransform: 'uppercase'}}>
              {language[props.language].title.playlist_userdesc}
            </Text>
          </Col>
        </Row>

        <Tabs
          tabContainerStyle={{elevation:0}}
          tabBarUnderlineStyle={{backgroundColor: '#202020'}}
          tabBarInactiveTextColor="#666666"
          tabBarActiveTextColor="#202020">

          <Tab
            tabStyle={{backgroundColor: '#ffffff'}}
            activeTabStyle={{backgroundColor: '#ffffff'}}
            heading={language[props.language].menu.main_classes}>
              <UserClasses
                navigation={props.navigation}
                listClass={props.userListClass} />
          </Tab>
          <Tab
            tabStyle={{backgroundColor: '#ffffff'}}
            activeTabStyle={{backgroundColor: '#ffffff'}}
            heading={language[props.language].menu.main_series}>
              <UserSeries
                navigation={props.navigation}
                listSeries={props.userListSeries} />
          </Tab>
          <Tab
            tabStyle={{backgroundColor: '#ffffff'}}
            activeTabStyle={{backgroundColor: '#ffffff'}}
            heading={language[props.language].menu.main_playlist}>
              <UserPlaylist
                navigation={props.navigation}
                listPlaylist={props.userListPlaylist} />
          </Tab>
        </Tabs>
      </Col>
    )
  }
}

const mapStateToProps = state => ({
  language: state.userRdc.userMeInfo.language,
  userListClass: state.userRdc.userMeClass,
  userListSeries: state.userRdc.userMeSeries,
  userListPlaylist: state.userRdc.userMePlaylist,
})

UserPractice.propTypes = {
  navigation: PropsTypes.object,
}

UserPractice.defaultProps = {
  language: 'EN',
}

export default connect(mapStateToProps)(UserPractice)
