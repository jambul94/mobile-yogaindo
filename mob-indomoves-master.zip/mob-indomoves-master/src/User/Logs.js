import React from 'react'
import PropTypes from 'prop-types'
import {Col, Text} from 'native-base'

class UserLogs extends React.Component {
  render () {
    return (
      <Col style={{paddingHorizontal: 15, paddingBottom: 15}}>
        <Text>User Log</Text>
      </Col>
    )
  }
}

UserLogs.propTypes = {
  navigation: PropTypes.object,
}

export default UserLogs
