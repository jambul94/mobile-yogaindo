import React from 'react'
import ImagePicker from 'react-native-image-picker'
import {ActionSheet, Col, Container, Content, Icon, Item, Row, Text} from 'native-base'
import {Image, TouchableOpacity} from 'react-native'
import {CustomHeader, CustomInput, CustomModalSpinner} from '../_component'
import SwitchToggle from '@dooboo-ui/native-switch-toggle'
import {NavigationEvents} from 'react-navigation'
import {connect} from 'react-redux'
import {serializeForm, showToast} from '../_common/helper'
import {update_userMeInfo} from '../_actions/user'
import {language} from '../_common/language'

class UserEditProfile extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      ...initStateFormProfile,
      gender: false,
      showLoading: false,
    }

    this._didFocus = this._didFocus.bind(this)
    this.changeInput = this.changeInput.bind(this)
    this.press_changePicture = this.press_changePicture.bind(this)
    this.press_distanceUnit = this.press_distanceUnit.bind(this)
    this.pressToggleGender = this.pressToggleGender.bind(this)
    this.press_saveProfile = this.press_saveProfile.bind(this)
  }

  _didFocus () {
    this.setDefaultFormValue()
  }

  setDefaultFormValue () {
    const {props} = this

    this.setState({
      name: props.userInfo.name,
      address: props.userInfo.address,
      about: props.userInfo.about,
      email: props.userInfo.email,
      gender: props.userInfo.gender,
      distance_unit: props.userInfo.distance_unit,
      photo_temp: props.userInfo.photo_thumbnail,
    })
  }

  onChangeInput (field, value, callbk) {
    this.setState({
      [field]: value,
    }, () => callbk && callbk())
  }

  onTogglePrivate (nextPrivate, callbk) {
    this.setState({
      gender: nextPrivate,
    }, callbk && callbk())
  }

  changeInput (name, value) {
    this.onChangeInput(name, value)
  }

  pressToggleGender () {
    const {state} = this
    let fixValue = ''

    if (state.gender === 'M') {
      fixValue = 'F'
    } else {
      fixValue = 'M'
    }

    this.changeInput('gender', fixValue)
  }

  press_changePicture () {
    ImagePicker.showImagePicker({
      title: 'Select Profile Photo',
    }, (resp) => {
      if (resp.data !== undefined) {
        this.setState({
          photo: resp.uri,
          photo_temp: resp.uri,
        })
      }
    })
  }

  press_distanceUnit () {
    const {props} = this
    const listChoice = ['Imperial', 'Metric']

    ActionSheet.show({
      options: listChoice,
      title: language[props.language].form.label_distanceUnit,
    }, idx => {
      if (idx !== undefined) {
        this.changeInput('distance_unit', listChoice[idx])
      }
    })
  }

  press_saveProfile () {
    const {state} = this
    const formData = serializeForm(initStateFormProfile, state)

    this.toggle_showLoading(true)
    this.props.dispatch(update_userMeInfo(formData,
      () => {
        this.toggle_showLoading(false, () => {
          setTimeout(() => {
            showToast('Profile successfull updated', 'success')
            this.setState({
              photo: '',
            })
          }, 500)
        })
      }, () => {
        this.toggle_showLoading(false, () => {
          setTimeout(() => {
            showToast('Profile failed updated', 'warning')
          }, 500)
        })
      })
    )
  }

  toggle_showLoading (show, callbk) {
    this.setState({
      showLoading: show,
    }, callbk && callbk())
  }

  render () {
    const {props, state} = this
    const noImage = require('../assets/images/no-image.jpg')

    return (
      <Container>
        <NavigationEvents
          onDidFocus={this._didFocus} />

        <CustomHeader
          navigation={props.navigation}
          rightChildren={
            <TouchableOpacity style={{paddingRight: 5}} onPress={this.press_saveProfile}>
              <Text style={{color: '#202020', fontSize: 10, textTransform: 'uppercase'}}>
                {language[props.language].form.button_save}
              </Text>
            </TouchableOpacity>
          }
          title={language[props.language].title.profile_edit} />

        <CustomModalSpinner
          isVisible={state.showLoading} />

        <Content style={{paddingHorizontal: 15}}>
          <Col style={{alignItems: 'center', marginBottom: 30, paddingTop: 15}}>
            <Image style={{width: 80, height: 80, borderRadius: 80/2, backgroundColor: 'rgba(0, 0, 0, 0.3)'}} defaultSource={noImage} source={{uri: state.photo_temp}} />
            <TouchableOpacity onPress={this.press_changePicture} style={{marginTop: 10}}>
              <Text style={{color: '#202020', fontSize: 12, letterSpacing: 1, textTransform: 'uppercase'}}>Change Picture</Text>
            </TouchableOpacity>
          </Col>

          <Row style={{marginBottom: 25}}>
            <Text style={{flex: 1, fontSize: 14, color: '#666666', textTransform: 'uppercase', marginTop: 4}}>
              {language[props.language].title.profile_name}
            </Text>
            <Item style={{flex: 3, height: 30, borderBottomWidth: 1}}>
              <CustomInput
                name="name"
                onChangeText={this.changeInput}
                placeholderTextColor="#707070"
                style={{fontSize: 14}}
                value={state.name} />
            </Item>
          </Row>
          <Row style={{marginBottom: 25}}>
            <Text style={{flex: 1, fontSize: 14, color: '#666666', textTransform: 'uppercase', marginTop: 4}}>
              {language[props.language].title.profile_location}
            </Text>
            <Item style={{flex: 3, borderBottomWidth: 1}}>
              <CustomInput
                multiline={true}
                name="address"
                numberOfLines={3}
                onChangeText={this.changeInput}
                placeholderTextColor="#707070"
                style={{fontSize: 14, paddingTop: 4}}
                textAlignVertical="top"
                value={state.address} />
            </Item>
          </Row>
          <Row style={{marginBottom: 25}}>
            <Text style={{flex: 1, fontSize: 14, color: '#666666', textTransform: 'uppercase', marginTop: 4}}>
              {language[props.language].title.profile_bio}
            </Text>
            <Item style={{flex: 3, borderBottomWidth: 1}}>
              <CustomInput
                multiline={true}
                name="about"
                numberOfLines={3}
                onChangeText={this.changeInput}
                placeholderTextColor="#707070"
                style={{fontSize: 14, paddingTop: 4}}
                textAlignVertical="top"
                value={state.about} />
            </Item>
          </Row>
          <Row style={{marginBottom: 25}}>
            <Text style={{flex: 1, fontSize: 14, color: '#666666', textTransform: 'uppercase', marginTop: 4}}>
              {language[props.language].title.profile_email}
            </Text>
            <Item style={{flex: 3, height: 30, borderBottomWidth: 1}}>
              <CustomInput
                name="email"
                onChangeText={this.changeInput}
                placeholderTextColor="#707070"
                style={{fontSize: 14}}
                value={state.email} />
            </Item>
          </Row>
          <Row style={{paddingBottom: 15}}>
            <Text style={{flex: 1, fontSize: 14, color: '#666666', textTransform: 'uppercase', marginTop: 4}}>
              {language[props.language].title.profile_gender}
            </Text>
            <Row style={{flex: 3}}>
              <SwitchToggle
                buttonStyle={{alignItems: 'center', justifyContent: 'center', position: 'absolute'}}
                circleColorOn="#075e54"
                circleStyle={{width: 20,height: 20,borderRadius: 5}}
                containerStyle={{width: 120,height: 30,borderRadius: 5,backgroundColor: '#666666',padding: 5}}
                backTextLeft={state.gender === 'M' ? language[props.language].title.profile_gender_m : null}
                backTextRight={state.gender === 'F' ? language[props.language].title.profile_gender_f : null}
                leftContainerStyle={{flex: 1, alignItems: 'center', justifyContent: 'flex-start'}}
                onPress={this.pressToggleGender}
                rightContainerStyle={{flex: 1, alignItems: 'center', justifyContent: 'center'}}
                textLeftStyle={{color: '#202020'}}
                textRightStyle={{color: '#202020'}}
                switchOn={state.gender === 'M' ? true : false}
                type={1} />
            </Row>
          </Row>
          <Row style={{marginBottom: 25}}>
            <Text style={{flex: 1, fontSize: 14, color: '#666666', textTransform: 'uppercase', marginTop: 4}}>
              {language[props.language].title.profile_distanceUnit}
            </Text>
            <Item style={{flex: 3, height: 30, borderBottomWidth: 1}}>
              <TouchableOpacity onPress={this.press_distanceUnit} style={{flex: 1, flexDirection: 'row'}}>
                <Text style={{flex: 1, fontSize: 14, color: '#202020', letterSpacing: 1}}>
                  {state.distance_unit !== '' ? state.distance_unit : language[props.language].form.select_distanceUnit}
                </Text>
                <Icon style={{fontSize: 14, alignSelf: 'flex-end', color: '#666666'}} name="chevron-right" type="FontAwesome5" />
              </TouchableOpacity>
            </Item>
          </Row>
        </Content>
      </Container>
    )
  }
}

const initStateFormProfile = {
  name: '',
  address: '',
  about: '',
  email: '',
  gender: '',
  distance_unit: '',
  photo: '',
}

const mapStateToProps = state => ({
  language: state.userRdc.userMeInfo.language,
  userInfo: state.userRdc.userMeInfo,
})

export default connect(mapStateToProps)(UserEditProfile)
