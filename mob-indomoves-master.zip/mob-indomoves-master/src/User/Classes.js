import React from 'react'
import PropTypes from 'prop-types'
import {ActionSheet, Col, Icon, Row, Text} from 'native-base'
import {FlatList, Image, TouchableOpacity} from 'react-native'
import {connect} from 'react-redux'
import {language} from '../_common/language'
import {set_filterUserClassSort} from '../_actions/filter'
import {getUserMeClass} from '../_actions/user'

class UserClasses extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      listSort: true,
    }

    this.press_sort = this.press_sort.bind(this)
    this.pressTextExplore = this.pressTextExplore.bind(this)
  }

  onChangeListSort (nextSort, callBk) {
    this.setState({
      listSort: nextSort,
    }, callBk && callBk())
  }

  pressClassDetail (uniqId) {
    const {props} = this

    props.navigation.push('ClassesDetail', {
      uniqId,
    })
  }

  press_sort () {
    const {props} = this
    const listSort = listSortType(props)
    const fixOptions = listSort.map(item => item.name)

    ActionSheet.show({
      options: fixOptions,
      title: language[props.language].title.sort_type,
    }, idx => {
      if (idx !== undefined) {
        props.dispatch(set_filterUserClassSort(listSort[idx].value, listSort[idx].name))
        props.dispatch(getUserMeClass())
      }
    })
  }

  pressTextExplore () {
    const {props} = this

    props.navigation.push('MainAppScreen', {
      activePage: 2,
    })
  }

  render () {
    const {props} = this
    const noImage = require('../assets/images/no-image.jpg')

    return props.listClass.length === 0 ? (
      <Col style={{justifyContent: 'center', alignItems: 'center'}}>
        <Text style={{color: '#666666', fontSize: 14, textTransform: 'uppercase'}}>
          {language[props.language].title.user_class_empty}
        </Text>
        <Text onPress={this.pressTextExplore} style={{color: '#666666', fontSize: 14, textTransform: 'uppercase', fontWeight: 'bold'}}>
          {language[props.language].menu.text_explore}
        </Text>
      </Col>
    ) : (
      <Col>
        <Row style={{paddingHorizontal: 15, paddingVertical: 10, height: 40}}>
          <Text style={{fontSize: 14, color: '#666666', textTransform: 'uppercase'}}>{language[props.language].title.sort_label} : </Text>
          <TouchableOpacity onPress={this.press_sort} style={{flexDirection: 'row'}}>
            <Text style={{fontSize: 14, color: '#202020', textTransform: 'uppercase', marginRight: 10}}>
              {props.sortLabel !== '' ? props.sortLabel : language[props.language].title.sort_recentadd}
            </Text>
            <Icon style={{fontSize: 11, color: '#202020', paddingTop: 4}} type="FontAwesome5" name="chevron-down" />
          </TouchableOpacity>
        </Row>

        <FlatList
          data={props.listClass}
          style={{paddingLeft: 15, paddingRight: 15}}
          renderItem={({item}) => {
            return (
              <TouchableOpacity onPress={() => this.pressClassDetail(item.id)}>
                <Row style={{marginBottom: 10}}>
                  <Image style={{width: 50, height: 50, backgroundColor: 'rgba(0, 0, 0, 0.3)'}} defaultSource={noImage} source={{uri: item.thumbnail}} />
                  <Col>
                    <Text style={{color: '#202020', fontSize: 14, paddingLeft: 10}}>{item.name}</Text>
                    <Text style={{color: '#666666', fontSize: 12, paddingLeft: 10}}>{item.instructor}</Text>
                    <Text style={{color: '#666666', fontSize: 12, paddingLeft: 10}}>{item.duration}</Text>
                  </Col>
                </Row>
              </TouchableOpacity>
            )
          }} />
      </Col>
    )
  }
}

const listSortType = (props) => {
  return [{
    name: language[props.language].title.sort_asc,
    value: 'name',
  }, {
    name: language[props.language].title.sort_recentadd,
    value: 'desc',
  }]
}

UserClasses.propTypes = {
  navigation: PropTypes.object,
  listClass: PropTypes.array,
}

UserClasses.defaultProps = {
  language: 'EN',
}

const mapStateToProps = state => ({
  language: state.userRdc.userMeInfo.language,
  sortLabel: state.filterRdc.userClass_sortLabel,
})

export default connect(mapStateToProps)(UserClasses)
