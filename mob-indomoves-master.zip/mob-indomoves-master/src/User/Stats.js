import React from 'react'
import {Col, Content, Row, Text} from 'native-base'

class UserStats extends React.Component {
  render () {
    const {props} = this

    return (
      <Content>
        <Col style={{height: 230, backgroundColor: '#e4e4e4', paddingHorizontal: 15, paddingTop: 15, paddingBottom: 30}}>
          <Row style={{justifyContent: 'center', height: 50}}>
            <Text style={{fontSize: 12, color: '#202020', fontWeight: 'bold', letterSpacing: 1}}>Workouts per week</Text>
          </Row>

          <Row style={{alignItems: 'flex-end'}}>
            <Col style={{alignItems: 'center', marginRight: 5/2, backgroundColor: '#202020', height: '50%'}}>
              <Text style={{position: 'absolute', top: -25, color: '#202020', fontSize: 14}}>3</Text>
              <Text style={{position: 'absolute', bottom: -20, color: '#202020', fontSize: 10}}>Dec 22 - Dec 29</Text>
            </Col>
            <Col style={{alignItems: 'center', marginHorizontal: 5/2, backgroundColor: '#202020', height: '10%'}}>
              <Text style={{position: 'absolute', top: -25, color: '#202020', fontSize: 14}}>1</Text>
              <Text style={{position: 'absolute', bottom: -20, color: '#202020', fontSize: 10}}>Dec 30 - jan 4</Text>
            </Col>
            <Col style={{alignItems: 'center', marginHorizontal: 5/2, backgroundColor: '#202020', height: '30%'}}>
              <Text style={{position: 'absolute', top: -25, color: '#202020', fontSize: 14}}>4</Text>
              <Text style={{position: 'absolute', bottom: -20, color: '#202020', fontSize: 10}}>Jan 5 - jan 12</Text>
            </Col>
            <Col style={{alignItems: 'center', marginLeft: 5/2, backgroundColor: '#202020', height: '100%'}}>
              <Text style={{position: 'absolute', top: -25, color: '#202020', fontSize: 14}}>7</Text>
              <Text style={{position: 'absolute', bottom: -20, color: '#202020', fontSize: 10}}>Jan 13 - jan 19</Text>
            </Col>
          </Row>
        </Col>

        <Row style={{paddingVertical: 20, marginHorizontal: 15, justifyContent: 'space-between', borderBottomColor: '#666666', borderBottomWidth: 1}}>
          <Text style={{fontSize: 12, color: '#202020', letterSpacing: 1}}>Total Workouts</Text>
          <Text style={{fontSize: 12, color: '#202020', letterSpacing: 1}}>2</Text>
        </Row>
        <Row style={{paddingVertical: 20, marginHorizontal: 15, justifyContent: 'space-between', borderBottomColor: '#666666', borderBottomWidth: 1}}>
          <Text style={{fontSize: 12, color: '#202020', letterSpacing: 1}}>Total Distance</Text>
          <Text style={{fontSize: 12, color: '#202020', letterSpacing: 1}}>22 mi</Text>
        </Row>
        <Row style={{paddingVertical: 20, marginHorizontal: 15, justifyContent: 'space-between', borderBottomColor: '#666666', borderBottomWidth: 1}}>
          <Text style={{fontSize: 12, color: '#202020', letterSpacing: 1}}>Total Time</Text>
          <Text style={{fontSize: 12, color: '#202020', letterSpacing: 1}}>5 min</Text>
        </Row>
        <Row style={{paddingVertical: 20, marginHorizontal: 15, justifyContent: 'space-between', borderBottomColor: '#666666', borderBottomWidth: 1}}>
          <Text style={{fontSize: 12, color: '#202020', letterSpacing: 1}}>Avg. workouts / week</Text>
          <Text style={{fontSize: 12, color: '#202020', letterSpacing: 1}}>2 workouts</Text>
        </Row>
        <Row style={{paddingVertical: 20, marginHorizontal: 15, justifyContent: 'space-between', borderBottomColor: '#666666', borderBottomWidth: 1}}>
          <Text style={{fontSize: 12, color: '#202020', letterSpacing: 1}}>Most Consecutive Days</Text>
          <Text style={{fontSize: 12, color: '#202020', letterSpacing: 1}}>1 day</Text>
        </Row>
        <Row style={{paddingVertical: 20, marginHorizontal: 15, justifyContent: 'space-between', borderBottomColor: '#666666', borderBottomWidth: 1}}>
          <Text style={{fontSize: 12, color: '#202020', letterSpacing: 1}}>Most Consecutive Days</Text>
          <Text style={{fontSize: 12, color: '#202020', letterSpacing: 1}}>2 week</Text>
        </Row>
      </Content>
    )
  }
}

export default UserStats
