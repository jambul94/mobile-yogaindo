import React from 'react'
import PropTypes from 'prop-types'
import ViewMoreText from 'react-native-view-more-text'
import {ActionSheet, Button, Col, Icon, Row, Text} from 'native-base'
import {FlatList, Image, ImageBackground, TouchableOpacity, View} from 'react-native'
import {CustomIconButton} from '../_component'
import {connect} from 'react-redux'
import {set_filterSeriesSort} from '../_actions/filter'
import {getListSeriesByCategories} from '../_actions/series'
import {language} from '../_common/language'

class SeriesList extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      maxColumns: 2,
    }

    this.pressListType = this.pressListType.bind(this)
    this.pressSeriesCategory = this.pressSeriesCategory.bind(this)
    this.pressSeriesDetail = this.pressSeriesDetail.bind(this)
    this.press_filter = this.press_filter.bind(this)
    this.press_sort = this.press_sort.bind(this)
  }

  onChangeListType (nextType, callBk) {
    this.setState({
      maxColumns: nextType,
    }, () => callBk && callBk())
  }

  pressListType (nextType) {
    this.onChangeListType(nextType)
  }

  pressSeriesCategory (selectedItem) {
    const {props} = this

    props.onPressSeriesCategory && props.onPressSeriesCategory(selectedItem)
  }

  pressSeriesDetail (uniqId) {
    const {props} = this

    props.navigation.navigate('SeriesDetail', {
      uniqId,
    })
  }

  press_filter () {
    const {props} = this

    props.navigation.navigate('SeriesFilter', {
      category: props.category,
      category_temp: props.category_temp,
    })
  }

  press_sort () {
    const {props} = this
    const listSort = listSortType(props)
    const fixOptions = listSort.map(item => item.name)

    ActionSheet.show({
      options: fixOptions,
      title: 'Sort Type',
    }, idx => {
      if (idx !== undefined) {
        props.dispatch(set_filterSeriesSort(listSort[idx].value, listSort[idx].name))
        props.dispatch(getListSeriesByCategories(props.category))
      }
    })
  }

  render () {
    const {props, state} = this
    const noImage = require('../assets/images/no-image.jpg')

    return (
      <Col>
        {props.category === null ? (
          <FlatList
            style={{paddingLeft: 15, paddingRight: 15}}
            data={props.listCategories}
            renderItem={({item, index}) => {
              return (
                <TouchableOpacity style={[{flex: 1, height: 150, marginBottom: 10}]} onPress={() => this.pressSeriesCategory(item)}>
                  <ImageBackground style={{flex: 1, width: null, height: null, justifyContent: 'center', padding: 15, backgroundColor: 'rgba(0, 0, 0, 0.3)'}} defaultSource={noImage} source={{uri: item.thumb}}>
                    <Text style={{fontSize: 16, color: '#ffffff', letterSpacing: 1, textTransform: 'uppercase', fontWeight: 'bold', textShadowColor: 'rgba(0, 0, 0, 0.5)', textShadowOffset: {width: -1, height: 1}, textShadowRadius: 2}}>{item.name}</Text>
                  </ImageBackground>
                </TouchableOpacity>
              )
            }} />
        ) : (
          <Col>
            <Row style={{height: 70, paddingLeft: 15, paddingRight: 15}}>
              <Col style={{justifyContent: 'center'}}>
                <Text style={{fontSize: 14, color: '#202020', textTransform: 'uppercase'}}>
                  {language[props.language].title.series_count.replace('[title]', props.category_temp)}
                </Text>
                <Row style={{flex:0}}>
                  <Text style={{fontSize: 14, color: '#666666', textTransform: 'uppercase'}}>{language[props.language].title.sort_label} : </Text>
                  <TouchableOpacity onPress={this.press_sort} style={{flexDirection: 'row'}}>
                    <Text style={{fontSize: 14, color: '#202020', textTransform: 'uppercase', marginRight: 5}}>
                      {props.sortLabel !== '' ? props.sortLabel : language[props.language].title.sort_relevan}
                    </Text>
                    <Icon style={{fontSize: 11, color: '#202020', paddingTop: 4}} type="FontAwesome5" name="chevron-down" />
                  </TouchableOpacity>
                </Row>
              </Col>

              <Row style={{flex: 0, alignItems: 'center'}}>
                <CustomIconButton
                  idIconBtn={2}
                  icon="th-large"
                  isActive={state.maxColumns === 2}
                  onPress={this.pressListType}
                  style={{marginRight: 10}} />

                <CustomIconButton
                  idIconBtn={1}
                  icon="bars"
                  isActive={state.maxColumns === 1}
                  onPress={this.pressListType} />
              </Row>
            </Row>

            <FlatList
              key={`listClasses-${state.maxColumns}`}
              style={{paddingLeft: 15, paddingRight: 15}}
              data={props.listSeries}
              numColumns={state.maxColumns}
              renderItem={({item, index}) => {
                const oddEven = index % state.maxColumns
                const styleBoxItem = state.maxColumns === 2 ? oddEven === 0 ? {marginRight: 7} : {marginLeft: 7} : null
                const styleBoxHeight = state.maxColumns === 2 ? 150 : 250

                if (state.maxColumns === 2 && item.empty) {
                  return (
                    <Col style={{backgroundColor: 'transparent', height: styleBoxHeight}} />
                  )
                } else if (state.maxColumns === 1 && item.empty) {
                  return null
                } else {
                  if (state.maxColumns === 2) {
                    return (
                      <TouchableOpacity onPress={() => this.pressSeriesDetail(item.id)} style={[{flex: 1, height: styleBoxHeight, marginBottom: 10}, styleBoxItem]}>
                        <Image style={{width: '100%', height: styleBoxHeight - 50, marginBottom: 5, backgroundColor: 'rgba(0, 0, 0, 0.3)'}} defaultSource={noImage} source={{uri: item.thumbnail}} />
                        <Text numberOfLines={1} style={{fontSize: 12, color: '#202020', textTransform: 'uppercase', fontWeight: 'bold', letterSpacing: 1}}>{item.name}</Text>
                        <Text numberOfLines={1} style={{fontSize: 10, color: '#666666', letterSpacing: 1}}>{item.instructor}</Text>
                      </TouchableOpacity>
                    )
                  } else if (state.maxColumns === 1) {
                    return (
                      <Col style={{marginBottom: 30}}>
                        <TouchableOpacity onPress={() => this.pressSeriesDetail(item.id)} style={[{flex: 1, height: styleBoxHeight}, styleBoxItem]}>
                          <Image style={{width: '100%', height: styleBoxHeight - 50, marginBottom: 10, backgroundColor: 'rgba(0, 0, 0, 0.3)'}} defaultSource={noImage} source={{uri: item.thumbnail}} />
                          <Text numberOfLines={1} style={{fontSize: 16, color: '#202020', textAlign: 'center', textTransform: 'uppercase', fontWeight: 'bold', letterSpacing: 2}}>{item.name}</Text>
                          <Text numberOfLines={1} style={{fontSize: 12, color: '#666666', textAlign: 'center', letterSpacing: 1}}>{item.instructor}</Text>
                        </TouchableOpacity>

                        <Row style={{paddingTop: 15}}>
                          <Row style={{justifyContent: 'flex-start'}}>
                            <Icon name="play-circle" type="FontAwesome5" style={{color: '#202020', fontSize: 16, marginRight: 10}} />
                            <Text style={{fontSize: 12, color: '#202020', letterSpacing: 1}}>17</Text>
                          </Row>
                          <Row style={{justifyContent: 'center'}}>
                            <Icon name="signal" type="FontAwesome5" style={{color: '#202020', fontSize: 16, marginRight: 10}} />
                            <Text style={{fontSize: 12, color: '#202020', letterSpacing: 1}}>{item.difficulty}</Text>
                          </Row>
                          <Row style={{justifyContent: 'flex-end'}}>
                            <Icon name="users" type="FontAwesome5" style={{color: '#202020', fontSize: 16, marginRight: 10}} />
                            <Text style={{fontSize: 12, color: '#202020', letterSpacing: 1}}>980</Text>
                          </Row>
                        </Row>

                        <View style={{width: '100%', borderBottomColor: '#666666', borderBottomWidth: 1, marginTop: 15, marginBottom: 15}} />

                        <ViewMoreText
                          numberOfLines={3}
                          renderViewMore={(onPress) => (
                          <Text onPress={onPress} style={{fontSize: 12, color: '#202020', fontWeight: 'bold', letterSpacing: 1, lineHeight: 20}}>
                            {language[props.language].title.detail_readmore}
                          </Text>)}
                          renderViewLess={() => null}>
                          <Text style={{fontSize: 12, color: '#202020', lineHeight: 20}}>{item.description}</Text>
                        </ViewMoreText>
                      </Col>
                    )
                  }
                }
              }} />

            <Row style={{position: 'absolute', bottom: 0, left: 0, right: 0, justifyContent: 'center', marginBottom: 15}}>
              <Button onPress={this.press_filter} style={{backgroundColor: '#075e54', paddingHorizontal: 10}}>
                <Icon name="filter" type="FontAwesome5" style={{color: '#ffffff', fontSize: 16, marginRight: -5}} />
                <Text style={{color: '#ffffff', fontSize: 14}}>Filter</Text>
              </Button>
            </Row>
          </Col>
        )}
      </Col>
    )
  }
}

SeriesList.propTypes = {
  category: PropTypes.string,
  category_temp: PropTypes.string,
  navigation: PropTypes.object,
  listCategories: PropTypes.array,
  listSeries: PropTypes.array,
  onPressSeriesCategory: PropTypes.func,
}

SeriesList.defaultProps = {
  category: null,
  category_temp: null,
}

const listSortType = (props) => {
  return [{
    name: language[props.language].title.sort_asc,
    value: 'name',
  },{
    name: language[props.language].title.sort_popular,
    value: 'most',
  },{
    name: language[props.language].title.sort_relevan,
    value: null,
  },{
    name: language[props.language].title.sort_newest,
    value: 'desc',
  }]
}

SeriesList.defaultProps = {
  language: 'EN',
}

const mapStateToProps = state => ({
  language: state.userRdc.userMeInfo.language,
  sortLabel: state.filterRdc.series_sortLabel,
})

export default connect(mapStateToProps)(SeriesList)
