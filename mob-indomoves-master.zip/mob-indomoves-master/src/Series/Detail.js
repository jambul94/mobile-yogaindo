import React from 'react'
import ViewMoreText from 'react-native-view-more-text'
import Video from 'react-native-video'
import collect from 'collect.js'
import Moment from 'react-moment'
import {CustomHeader, CustomInput, CustomModalComment, CustomModalSpinner} from '../_component'
import {Button, Col, Container, Content, Icon, Row, Text} from 'native-base'
import {FlatList, Image, ImageBackground, TouchableOpacity} from 'react-native'
import {NavigationEvents} from 'react-navigation'
import {connect} from 'react-redux'
import {getDetailSeries, getListSeriesComment, post_SeriesComment} from '../_actions/series'
import {addSeriesToUserMe, delete_seriesFromUserMe, getUserMeSeries, update_notificationToRead} from '../_actions/user'
import {showToast} from '../_common/helper'
import {language} from '../_common/language'

class SeriesDetail extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      activeTab: 0,
      comment: null,
      isDetailCommentShow: false,
      isExistInPractice: false,
      isFullScreen: false,
      listComment: [],
      selectedComment: null,
      screenType: 'contain',
      showVideo: false,
    }

    this._didFocus = this._didFocus.bind(this)
    this.change_input = this.change_input.bind(this)
    this.reqDetailSeries = this.reqDetailSeries.bind(this)
    this.pressAddToMyPractice = this.pressAddToMyPractice.bind(this)
    this.pressOverview = this.pressOverview.bind(this)
    this.pressClassess = this.pressClassess.bind(this)
    this.pressCommunity = this.pressCommunity.bind(this)
    this.pressClassesDetail = this.pressClassesDetail.bind(this)
    this.press_removeFromMyPractive =this.press_removeFromMyPractive.bind(this)
    this.press_subscribe = this.press_subscribe.bind(this)
    this.press_submitComment = this.press_submitComment.bind(this)
    this.press_submitSubComment = this.press_submitSubComment.bind(this)
    this.pressShowVideo = this.pressShowVideo.bind(this)
    this.toggle_modalDetailComment = this.toggle_modalDetailComment.bind(this)
  }

  _didFocus () {
    this.reqDetailSeries()
    this.req_listComment()
  }

  change_input (name, value) {
    this.setState({
      [name]: value,
    })
  }

  reqDetailSeries () {
    const {props} = this
    const uniqId = props.navigation.getParam('uniqId')
    const unreadStatus = props.navigation.getParam('unread', null)

    props.dispatch(getDetailSeries(uniqId, () => {
      const existSeries = collect(props.userListSeries).firstWhere('id', uniqId)

      if (unreadStatus) {
        const readFormData = props.navigation.getParam('postRead', null)
        props.dispatch(update_notificationToRead(readFormData))
      }

      if (existSeries !== null) {
        this.setState({
          isExistInPractice: true,
        })
      }
    }))
  }

  req_listComment () {
    const {props} = this
    const uniqId = props.navigation.getParam('uniqId')

    getListSeriesComment(uniqId, resp => {
      this.setState({
        listComment: resp,
      })
    })
  }

  pressAddToMyPractice () {
    const {props} = this
    const idSeries = props.detailSeries.id

    this.toggleLoading(true)
    props.dispatch(addSeriesToUserMe(idSeries, () => {
      this.toggleLoading(false)
      showToast('Berhasil ditambahkan ke My Practice', 'success')
      props.dispatch(getUserMeSeries())
      this.setState({
        isExistInPractice: true,
      })
    }), () => {
      this.toggleLoading(false)
      showToast('Gagal ditambahkan ke My Practice', 'warning')
    })
  }

  pressOverview () {
    this.setState({
      activeTab: 0,
    })
  }

  pressClassess () {
    this.setState({
      activeTab: 1,
    })
  }

  pressCommunity () {
    this.setState({
      activeTab: 2,
      comment: null,
    })
  }

  pressClassesDetail (uniqId) {
    const {props} = this

    props.navigation.push('ClassesDetail', {
      uniqId,
    })
  }

  toggleLoading (show, callbk) {
    this.setState({
      showLoading: show,
    }, callbk && callbk())
  }

  press_removeFromMyPractive () {
    const {props} = this
    const idSeries = props.detailSeries.id

    this.toggleLoading(true)
    props.dispatch(delete_seriesFromUserMe(idSeries, () => {
      this.toggleLoading(false)
      showToast('Berhasil dihapus dari My Practice', 'success')
      this.setState({
        isExistInPractice: false,
      })
    }, () => {
      this.toggleLoading(false)
      showToast('Gagal dhapus dari My Practice', 'warning')
    }))
  }

  press_subscribe () {
    const {props} = this

    props.navigation.navigate('PaymentForm')
  }

  press_submitComment () {
    const {props, state} = this
    const uniqId = props.navigation.getParam('uniqId')
    const formData = {
      series_id: uniqId,
      comment: state.comment,
    }

    this.toggleLoading(true)
    post_SeriesComment(formData, () => {
      this.toggleLoading(false)
      this.req_listComment()
      this.setState({
        comment: null,
      })
      showToast('Komentar telah berhasil di tambahkan', 'success')
    }, () => {
      this.toggleLoading(false)
      showToast('Komentar gagal di tambahkan', 'warning')
    })
  }

  press_submitSubComment (comment_id, comment) {
    const {props} = this
    const uniqId = props.navigation.getParam('uniqId')
    const formData = {
      series_id: uniqId,
      comment,
      comment_id,
    }

    this.toggleLoading(true)
    post_SeriesComment(formData, () => {
      this.toggleLoading(false)
      this.req_listComment()
      this.setState({
        isDetailCommentShow: false,
      })
      showToast('Komentar telah berhasil di tambahkan', 'success')
    }, () => {
      this.toggleLoading(false)
      showToast('Komentar gagal di tambahkan', 'warning')
    })
  }

  pressShowVideo () {
    this.setState({
      showVideo: true,
    })
  }

  toggle_modalDetailComment (uniqId) {
    const {state} = this
    let selectedComment = collect(state.listComment).firstWhere('id', uniqId)

    if (state.isDetailCommentShow) {
      selectedComment = null
    } else {
      selectedComment = {
        id: selectedComment.id,
        comment: selectedComment.comment,
        created_at: selectedComment.created_at,
        commenter: selectedComment.commenter,
        user_comments: selectedComment.user_comments,
      }
    }

    this.setState({
      isDetailCommentShow: !state.isDetailCommentShow,
      selectedComment,
    })
  }

  render () {
    const {props, state} = this
    const noImage = require('../assets/images/no-image.jpg')

    return (
      <Container>
        <NavigationEvents
          onDidFocus={this._didFocus} />

        <CustomHeader
          navigation={props.navigation} />

        <CustomModalSpinner
          isVisible={state.showLoading} />

        <CustomModalComment
          isVisible={state.isDetailCommentShow}
          parentData={state.selectedComment}
          onBackButtonPress={this.toggle_modalDetailComment}
          onPressSubmitComment={this.press_submitSubComment} />

        {props.detailSeries !== null ? (
          <Content>
            <ImageBackground style={{flex: 1, width: null, height: 200, alignItems: 'center', marginBottom: 15, backgroundColor: 'rgba(0, 0, 0, 0.3)'}} defaultSource={noImage} source={{uri: props.detailSeries.thumbnail}}/>

            <Text style={{textAlign: 'center', fontSize: 16, color: '#202020', fontWeight: 'bold', textTransform: 'uppercase', letterSpacing: 2, marginBottom: 10}}>{props.detailSeries.name}</Text>
            <Text style={{textAlign: 'center', fontSize: 12, color: '#707070', fontWeight: 'bold', textTransform: 'uppercase', letterSpacing: 2}}>{props.detailSeries.instructor.name}</Text>

            {props.userSubscribeStatus ?
              !state.isExistInPractice ? (
                <Col style={{paddingTop: 15, paddingLeft: 15, paddingRight: 15, paddingBottom: 15/2}}>
                  <Button onPress={this.pressAddToMyPractice} style={{backgroundColor: '#075e54', justifyContent: 'center'}}>
                    <Text style={{fontSize: 14, textTransform: 'uppercase', letterSpacing: 1}}>
                      {language[props.language].form.button_add_mypractive}
                    </Text>
                  </Button>
                </Col>
              ) : (
                <Col style={{paddingTop: 15, paddingLeft: 15, paddingRight: 15, paddingBottom: 15/2}}>
                  <Button onPress={this.press_removeFromMyPractive} style={{backgroundColor: '#075e54', justifyContent: 'center'}}>
                    <Text style={{fontSize: 14, textTransform: 'uppercase', letterSpacing: 1}}>
                      {language[props.language].form.button_remove_mypractive}
                    </Text>
                  </Button>
                </Col>
              )
            : (
              <Col style={{paddingTop: 15, paddingLeft: 15, paddingRight: 15, paddingBottom: 15/2}}>
                <Button onPress={this.press_subscribe} style={{backgroundColor: '#075e54', justifyContent: 'center'}}>
                  <Text style={{fontSize: 14, textTransform: 'uppercase', letterSpacing: 1}}>
                    {language[props.language].form.button_subscribe}
                  </Text>
                </Button>
              </Col>
            )}

            <Row style={{padding: 15}}>
              <Col style={{alignItems: 'center', borderBottomWidth: state.activeTab === 0 ? 1 : 0, borderBottomColor: '#202020'}}>
                <TouchableOpacity style={{padding: 10}} onPress={this.pressOverview}>
                  <Text style={{color: '#202020', fontSize: 12, textTransform: 'uppercase', letterSpacing: 1}}>
                    {language[props.language].title.detail_overview}
                  </Text>
                </TouchableOpacity>
              </Col>
              <Col style={{alignItems: 'center', borderBottomWidth: state.activeTab === 1 ? 1 : 0, borderBottomColor: '#202020'}}>
                <TouchableOpacity style={{padding: 10}} onPress={this.pressClassess}>
                  <Text style={{color: '#202020', fontSize: 12, textTransform: 'uppercase', letterSpacing: 1}}>
                    {language[props.language].menu.main_classes}
                  </Text>
                </TouchableOpacity>
              </Col>
              <Col style={{alignItems: 'center', borderBottomWidth: state.activeTab === 2 ? 1 : 0, borderBottomColor: '#202020'}}>
                <TouchableOpacity style={{padding: 10}} onPress={this.pressCommunity}>
                  <Text style={{color: '#202020', fontSize: 12, textTransform: 'uppercase', letterSpacing: 1}}>
                    {language[props.language].title.detail_community}
                  </Text>
                </TouchableOpacity>
              </Col>
            </Row>

            {state.activeTab === 0 ?
            (
              <Col>
                <Col style={{paddingLeft: 15, paddingRight: 15, marginBottom: 15}}>
                  <Text style={{fontSize: 12, fontWeight: 'bold', letterSpacing: 1, marginBottom: 15}}>
                    {language[props.language].title.detail_about_series}
                  </Text>
                  <ViewMoreText
                    numberOfLines={3}
                    renderViewMore={(onPress) => <Text onPress={onPress} style={{fontSize: 12, color: '#202020', fontWeight: 'bold', letterSpacing: 1, lineHeight: 20}}>
                      {language[props.language].title.detail_readmore}
                    </Text>}
                    renderViewLess={() => null}>
                      <Text style={{fontSize: 12, color: '#202020', lineHeight: 20}}>{props.detailSeries.description}</Text>
                  </ViewMoreText>
                </Col>

                <Col style={{justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0, 0, 0, 0.4)', height: 200, marginBottom: 20}}>
                  {!state.showVideo ? (
                    <TouchableOpacity onPress={this.pressShowVideo}>
                      <Icon style={{fontSize: 60, color: '#ffffff'}} name="play-circle" type="FontAwesome5" />
                    </TouchableOpacity>
                  ) : (
                    <Video
                      controls={true}
                      fullscreen={state.isFullScreen}
                      fullscreenAutorotate={true}
                      fullscreenOrientation="landscape"
                      resizeMode={state.screenType}
                      source={{uri: props.detailSeries.intro}}
                      style={{position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: '#202020'}} />
                  )}
                </Col>

                <Col style={{backgroundColor: '#e4e4e4'}}>
                  <Row style={{paddingLeft: 15, paddingRight: 15, paddingTop: 15, paddingBottom: 7.5}}>
                    <Image style={{width: 100, height: 100, borderRadius: 100/2, backgroundColor: 'rgba(0, 0, 0, 0.3)'}} defaultSource={noImage} source={{uri: props.detailSeries.instructor.photo}} />
                    <Col style={{justifyContent: 'center', paddingLeft: 30}}>
                      <Text style={{fontSize: 12, color: '#202020', fontWeight: 'bold', letterSpacing: 1, textTransform: 'uppercase', paddingTop: 3, paddingBottom: 3}}>
                        {language[props.language].title.reward_instructor}
                      </Text>
                      <Text style={{fontSize: 12, color: '#202020', letterSpacing: 1, paddingTop: 3, paddingBottom: 3}}>{props.detailSeries.instructor.name}</Text>
                    </Col>
                  </Row>

                  <Row style={{paddingLeft: 15, paddingRight: 15, paddingTop: 7.5, paddingBottom: 15}}>
                    <ViewMoreText
                      numberOfLines={3}
                      renderViewMore={(onPress) => <Text onPress={onPress} style={{fontSize: 12, color: '#202020', fontWeight: 'bold', letterSpacing: 1, lineHeight: 20}}>
                        {language[props.language].title.detail_readmore}
                      </Text>}
                      renderViewLess={() => null}>
                        <Text style={{fontSize: 12, color: '#202020', lineHeight: 20}}>{props.detailSeries.instructor.bio}</Text>
                    </ViewMoreText>
                  </Row>
                </Col>

                <Col style={{padding: 15}}>
                  <Row style={{justifyContent: 'center', marginBottom: 5}}>
                    <Text style={{fontSize: 12, color: '#707070', textTransform: 'uppercase', letterSpacing: 1, fontWeight: 'bold'}}>
                      {language[props.language].title.detail_total_runtime}
                    </Text>
                  </Row>

                  <Row style={{justifyContent: 'center'}}>
                    <Icon style={{fontSize: 14, marginRight: 5, color: '#202020'}} name="stopwatch" type="FontAwesome5" />
                    <Text style={{fontSize: 12, color: '#202020', letterSpacing: 1}}>{`${props.detailSeries.total_duration} - (${props.detailSeries.workouts.length} Videos)`}</Text>
                  </Row>

                  <Row style={{paddingTop: 15, paddingBottom: 15, marginTop: 10}}>
                    <Col style={{alignItems: 'center'}}>
                      <Text style={{fontSize: 12, color: '#707070', textTransform: 'uppercase', letterSpacing: 1, fontWeight: 'bold'}}>
                        {language[props.language].title.detail_difficult}
                      </Text>

                      <Row style={{paddingTop: 10, paddingBottom: 10}}>
                        <Icon name="signal" type="FontAwesome5" style={{color: '#202020', fontSize: 12, marginRight: 5}} />
                        <Text style={{fontSize: 12, color: '#202020', letterSpacing: 1}}>{props.detailSeries.difficulty}</Text>
                      </Row>
                    </Col>

                    <Col style={{alignItems: 'center'}}>
                      <Text style={{fontSize: 12, color: '#707070', textTransform: 'uppercase', letterSpacing: 1, fontWeight: 'bold'}}>
                        {language[props.language].title.detail_intensity}
                      </Text>

                      <Row style={{paddingTop: 10, paddingBottom: 10}}>
                        <Icon name="level-up-alt" type="FontAwesome5" style={{color: '#202020', fontSize: 12, marginRight: 5}} />
                        <Text style={{fontSize: 12, color: '#202020', letterSpacing: 1}}>{`Level ${props.detailSeries.intensity}`}</Text>
                      </Row>
                    </Col>
                  </Row>
                </Col>
              </Col>
            )
            : null}

            {state.activeTab === 1 ? (
              <Col style={{paddingLeft: 15, paddingRight: 15, marginBottom: 15}}>
                {props.detailSeries.workouts.map((item, idx) => {
                  return (
                    <Col key={`list-class-${item.id}-series`} style={{marginBottom: 30}}>
                      <TouchableOpacity onPress={() => this.pressClassesDetail(item.id)} style={[{flex: 1, height: 250}]}>
                        <ImageBackground style={{width: '100%', height: 200, marginBottom: 10, backgroundColor: 'rgba(0, 0, 0, 0.3)'}} defaultSource={noImage} source={{uri: item.thumbnail}}>
                          <Text style={{textTransform: 'uppercase', color: '#202020', fontSize: 12, width: 'auto', backgroundColor: '#ffffff', alignSelf: 'flex-start', letterSpacing: 1, padding: 10, paddingLeft: 20, paddingRight: 20}}>{idx + 1}</Text>
                        </ImageBackground>

                        <Text style={{fontSize: 16, color: '#202020', textAlign: 'center', textTransform: 'uppercase', fontWeight: 'bold', letterSpacing: 2}}>{`${item.name} (${item.duration})`}</Text>
                      </TouchableOpacity>

                      <ViewMoreText
                        numberOfLines={3}
                        renderViewMore={(onPress) => <Text onPress={onPress} style={{fontSize: 12, color: '#202020', fontWeight: 'bold', letterSpacing: 1, lineHeight: 20}}>
                          {language[props.language].title.detail_readmore}
                        </Text>}
                        renderViewLess={() => null}>
                          <Text style={{fontSize: 12, color: '#202020', lineHeight: 20}}>{item.description}</Text>
                      </ViewMoreText>
                    </Col>
                  )
                })}
              </Col>
            ) : null}

            {state.activeTab === 2 ? (
              <Col style={{paddingLeft: 15, paddingRight: 15, marginBottom: 15}}>
                <FlatList
                  data={state.listComment}
                  style={{paddingVertical: 15}}
                  renderItem={({item}) => {
                    return (
                      <Row style={{marginBottom: 20}}>
                        <Image style={{width: 50, height: 50, borderRadius: 50/2, backgroundColor: 'rgba(0, 0, 0, 0.3)'}} defaultSource={noImage} source={{uri: item.commenter.photo_thumbnail}} />
                        <Col>
                          <Row style={{paddingLeft: 15, flex: 0}}>
                            <Text style={{color: '#202020', fontSize: 14}}>{item.commenter.name} . </Text>
                            <Moment style={{color: '#666666', fontSize: 11, paddingTop: 3}} fromNow={true} ago={true} element={Text}>{item.created_at}</Moment>
                          </Row>
                          <Text style={{color: '#666666', fontSize: 12, paddingLeft: 15, paddingVertical: 5}}>{item.comment}</Text>
                          <Row style={{paddingLeft: 15, flex: 0}}>
                            <TouchableOpacity onPress={() => this.toggle_modalDetailComment(item.id)}>
                              <Text style={{color: '#075e54', fontSize: 12}}>{item.user_comments.length} comments</Text>
                            </TouchableOpacity>
                          </Row>
                        </Col>
                      </Row>
                    )
                  }} />
              </Col>
            ) : null}
          </Content>
        ) : null}

        {state.activeTab === 2 && (
          <Row style={{backgroundColor: '#e4e4e4', alignItems: 'center', flex: 0, paddingVertical: 5, paddingHorizontal: 15}}>
            <CustomInput
              onChangeText={this.change_input}
              multiline={true}
              name="comment"
              placeholder="insert comment..."
              placeholderTextColor="#707070"
              style={{flex: 1, color: '#202020', marginLeft: 10, fontSize: 14, height: 50}}
              value={this.state.comment} />

            <TouchableOpacity onPress={this.press_submitComment} style={{backgroundColor: '#075e54', height: 40, width: 48, justifyContent: 'center', alignItems: 'center'}}>
              <Icon style={{color: '#f4f4f4f4', fontSize: 16}} name="arrow-right" type="FontAwesome5" />
            </TouchableOpacity>
          </Row>
        )}
      </Container>
    )
  }
}

SeriesDetail.defaultProps = {
  language: 'EN',
}

const mapStateToProps = state => ({
  language: state.userRdc.userMeInfo.language,
  userListSeries: state.userRdc.userMeSeries,
  userSubscribeStatus: state.userRdc.userMeInfo.is_subscribe,
  detailSeries: state.seriesRdc.detailSeries,
})

export default connect(mapStateToProps)(SeriesDetail)
