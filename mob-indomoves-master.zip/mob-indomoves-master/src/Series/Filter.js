import React from 'react'
import {Button, Col, Container, Content, Footer, Icon, Row, Text} from 'native-base'
import {CustomHeader} from '../_component'
import {TouchableOpacity} from 'react-native'
import {connect} from 'react-redux'
import {set_filterSeriesInstructor, set_filterSeriesStyles} from '../_actions/filter'

class ClassFilter extends React.Component {
  constructor (props) {
    super(props)

    this.press_applyFilter = this.press_applyFilter.bind(this)
    this.press_clearFilter = this.press_clearFilter.bind(this)
    this.press_instructor = this.press_instructor.bind(this)
    this.press_style = this.press_style.bind(this)
  }

  press_clearFilter () {
    const {props} = this

    props.dispatch(set_filterSeriesInstructor([], []))
    props.dispatch(set_filterSeriesStyles([], []))
  }

  press_applyFilter () {
    const {props} = this
    const category = props.navigation.getParam('category', null)
    const category_temp = props.navigation.getParam('category_temp', null)

    props.navigation.push('MainAppScreen', {
      mode: 'filter',
      activePage: 3,
      category,
      category_temp,
    })
  }

  press_instructor () {
    const {props} = this
    const category = props.navigation.getParam('category', null)
    const category_temp = props.navigation.getParam('category_temp', null)

    props.navigation.navigate('SeriesFilterInstructor', {
      category,
      category_temp,
    })
  }

  press_style () {
    const {props} = this
    const category = props.navigation.getParam('category', null)
    const category_temp = props.navigation.getParam('category_temp', null)

    props.navigation.navigate('SeriesFilterStyles', {
      category,
      category_temp,
    })
  }

  render () {
    const {props} = this
    const labelInstructor = props.instructorLabel.map((item, idx) => idx !== 0 ? `, ${item.name}` : item.name)
    const labelStyle = props.stylesLabel.map((item, idx) => idx !== 0 ? `, ${item.name}` : item.name)

    return (
      <Container>
        <CustomHeader
          bodyAlignItem="flex-start"
          rightChildren={
            <TouchableOpacity style={{padding: 5, borderWidth: 1}} onPress={this.press_clearFilter}>
              <Text style={{color: '#202020', fontSize: 10, textTransform: 'uppercase'}}>Reset</Text>
            </TouchableOpacity>
          }
          title="Filter"
          navigation={props.navigation} />

        <Content>
          <Col style={{padding: 15}}>
            <Row style={{paddingVertical: 15}}>
              <TouchableOpacity onPress={this.press_instructor} style={{flex: 1, flexDirection: 'column'}}>
                <Row>
                  <Text style={{flex: 1, fontSize: 14, textTransform: 'uppercase', color: '#202020', letterSpacing: 1}}>Instructors</Text>
                  <Icon style={{fontSize: 14, alignSelf: 'flex-end', color: '#666666'}} name="chevron-right" type="FontAwesome5" />
                </Row>
                <Row>
                  <Text numberOfLines={1} style={{fontSize: 12, color: '#666666', letterSpacing: 1}}>{labelInstructor}</Text>
                </Row>
              </TouchableOpacity>
            </Row>
            <Row style={{paddingVertical: 15}}>
              <TouchableOpacity onPress={this.press_style} style={{flex: 1, flexDirection: 'column'}}>
                <Row>
                  <Text style={{flex: 1, fontSize: 14, textTransform: 'uppercase', color: '#202020', letterSpacing: 1}}>Styles</Text>
                  <Icon style={{fontSize: 14, alignSelf: 'flex-end', color: '#666666'}} name="chevron-right" type="FontAwesome5" />
                </Row>
                <Row>
                  <Text numberOfLines={1} style={{fontSize: 12, color: '#666666', letterSpacing: 1}}>{labelStyle}</Text>
                </Row>
              </TouchableOpacity>
            </Row>
          </Col>
        </Content>

        <Footer style={{backgroundColor: 'transparent', height:65, padding: 10}}>
          <Row>
            <Button onPress={this.press_applyFilter} block={true} style={{backgroundColor: '#075e54', justifyContent: 'center', width: '100%'}}>
              <Text style={{fontSize: 14}}>Apply</Text>
            </Button>
          </Row>
        </Footer>
      </Container>
    )
  }
}

const mapStateToProps = state => ({
  instructorLabel: state.filterRdc.series_instructorLabel,
  stylesLabel: state.filterRdc.series_stylesLabel,
})

export default connect(mapStateToProps)(ClassFilter)
