import React from 'react'
import {Button, Col, Container, Content, Footer, Icon, Row, Text} from 'native-base'
import {CustomHeader} from '../_component'
import {TouchableOpacity} from 'react-native'
import {connect} from 'react-redux'
import {collection} from '../_common/helper'
import {set_filterSeriesInstructor} from '../_actions/filter'

class SeriesFilterInstructor extends React.Component {
  constructor (props) {
    super(props)

    this.press_applyFilter = this.press_applyFilter.bind(this)
    this.press_clearFilter = this.press_clearFilter.bind(this)
    this.press_selectedItem = this.press_selectedItem.bind(this)
  }

  press_applyFilter () {
    const {props} = this
    const category = props.navigation.getParam('category', null)
    const category_temp = props.navigation.getParam('category_temp', null)

    props.navigation.push('MainAppScreen', {
      mode: 'filter',
      activePage: 3,
      category,
      category_temp,
    })
  }

  press_clearFilter () {
    const {props} = this

    props.dispatch(set_filterSeriesInstructor([], []))
  }

  press_selectedItem (selectedItem) {
    const {props} = this
    const instructor = collection(props.instructorLabel.slice()).firstWhere('id', selectedItem.id)
    let instructorLabel = props.instructorLabel.slice()
    let instructorValue = props.instructorValue.slice()

    if (instructor) {
      instructorLabel = collection(instructorLabel).where('id', '!==', selectedItem.id).toArray()
      instructorValue = instructorValue.filter(item => item !== selectedItem.id)
    } else {
      instructorLabel.push(selectedItem)
      instructorValue.push(selectedItem.id)
    }

    props.dispatch(set_filterSeriesInstructor(instructorValue, instructorLabel))
  }

  render () {
    const {props} = this

    return (
      <Container>
        <CustomHeader
          bodyAlignItem="flex-start"
          rightChildren={
            <TouchableOpacity style={{padding: 5, borderWidth: 1}} onPress={this.press_clearFilter}>
              <Text style={{color: '#202020', fontSize: 10, textTransform: 'uppercase'}}>Clear</Text>
            </TouchableOpacity>
          }
          title="Instructor"
          navigation={props.navigation} />

        <Content>
          <Col style={{padding: 15}}>
            {props.instructor.map(item => (
              <TouchableOpacity key={`filter-instructor-${item.id}`} onPress={() => this.press_selectedItem(item)}>
                <Row style={{paddingVertical: 15}}>
                  <Text style={{flex: 1, fontSize: 14, color: '#202020', letterSpacing: 1}}>{item.name}</Text>
                  {props.instructorValue.includes(item.id)
                    ? <Icon style={{fontSize: 14, alignSelf: 'flex-end', color: '#666666'}} name="check" type="FontAwesome5" />
                    : null}
                </Row>
              </TouchableOpacity>
            ))}
          </Col>
        </Content>

        <Footer style={{backgroundColor: 'transparent', height:65, padding: 10}}>
          <Row>
            <Button onPress={this.press_applyFilter} block={true} style={{backgroundColor: '#075e54', justifyContent: 'center', width: '100%'}}>
              <Text style={{fontSize: 14}}>Apply</Text>
            </Button>
          </Row>
        </Footer>
      </Container>
    )
  }
}

const mapStateToProps = state => ({
  instructor: state.instructorRdc.instructor,
  instructorLabel: state.filterRdc.series_instructorLabel,
  instructorValue: state.filterRdc.series_instructorValue,
})

export default connect(mapStateToProps)(SeriesFilterInstructor)
