import {createStackNavigator} from 'react-navigation-stack'
import ClassesDetail from '../Classes/Detail'
import ClassesFilter from '../Classes/Filter'
import ClassesFilterDifficulty from '../Classes/FilterDifficulty'
import ClassesFilterInstructor from '../Classes/FilterInstructor'
import ClassesFilterInstensity from '../Classes/FilterIntensity'
import ClassesFilterStyles from '../Classes/FilterStyles'
import ContentFaqDetail from '../Content/FaqDetail'
import ContentFaqList from '../Content/FaqList'
import ContentPrivacyPolice from '../Content/PrivacyPolice'
import ContentTos from '../Content/Tos'
import InstructorsDetail from '../Instructors/Detail'
import InstructorsList from '../Instructors/List'
import MainAppLogin from '../Main/AppLogin'
import MainAppRegister from '../Main/AppRegister'
import MainAppAuth from '../Main/AppAuth'
import MainAppVerification from '../Main/AppVerification'
import MainAppScreen from '../Main/AppScreen'
import MainAppSearch from '../Main/AppSearch'
import MainAppSplashScreen from '../Main/AppSplashScreen'
import PaymentForm from '../Payment/Form'
import PaymentCreditCard from '../Payment/CreditCard'
import PlaylistList from '../Playlist/List'
import PlaylistDetail from '../Playlist/Detail'
import RewardList from '../Reward/List'
import SeriesDetail from '../Series/Detail'
import SeriesFilter from '../Series/Filter'
import SeriesFilterInstructor from '../Series/FilterInstructor'
import SeriesFilterStyles from '../Series/FilterStyles'
// import UserActivities from '../User/Activities'
import UserEditProfile from '../User/EditProfile'
// import UserDownload from '../User/Download'
// import UserDownloadSetting from '../User/DownloadSetting'
import UserNotification from '../User/Notification'
import UserProfile from '../User/Profile'
import UserSetting from '../User/Setting'

const SplashNavigator = createStackNavigator(
  {
    MainAppSplashScreen: MainAppSplashScreen,
  }, {
    initialRouteName: 'MainAppSplashScreen',
    headerMode: 'none',
  }
)

const AuthNavigator = createStackNavigator(
  {
    MainAppAuth: MainAppAuth,
    MainAppLogin: MainAppLogin,
    MainAppRegister: MainAppRegister,
    MainAppVerification: MainAppVerification,
  }, {
    initialRouteName: 'MainAppAuth',
    headerMode: 'none',
  }
)

const AppNavigator = createStackNavigator(
  {
    ClassesDetail: ClassesDetail,
    ClassesFilter: ClassesFilter,
    ClassesFilterDifficulty: ClassesFilterDifficulty,
    ClassesFilterInstructor: ClassesFilterInstructor,
    ClassesFilterInstensity: ClassesFilterInstensity,
    ClassesFilterStyles: ClassesFilterStyles,
    ContentFaqDetail: ContentFaqDetail,
    ContentFaqList: ContentFaqList,
    ContentPrivacyPolice: ContentPrivacyPolice,
    ContentTos: ContentTos,
    InstructorsDetail: InstructorsDetail,
    InstructorsList: InstructorsList,
    MainAppScreen: MainAppScreen,
    MainAppSearch: MainAppSearch,
    PaymentForm: PaymentForm,
    PaymentCreditCard: PaymentCreditCard,
    PlaylistList: PlaylistList,
    PlaylistDetail: PlaylistDetail,
    RewardList: RewardList,
    SeriesDetail: SeriesDetail,
    SeriesFilter: SeriesFilter,
    SeriesFilterInstructor: SeriesFilterInstructor,
    SeriesFilterStyles: SeriesFilterStyles,
    // UserActivities: UserActivities,
    UserEditProfile: UserEditProfile,
    // UserDownload: UserDownload,
    // UserDownloadSetting: UserDownloadSetting,
    UserNotification: UserNotification,
    UserProfile: UserProfile,
    UserSetting: UserSetting,
  },{
    initialRouteName: 'MainAppScreen',
    headerMode: 'none',
  }
)

export {
  AuthNavigator,
  AppNavigator,
  SplashNavigator,
}
