import asyncStorage from '@react-native-community/async-storage'
import axios from 'axios'
import collection from 'collect.js'
import dotenv from 'react-native-config'
import moment from 'moment'
import Xendit from 'xendit-js-node'
import {Toast} from 'native-base'
import {navigate} from '../_common/navigationService'

const apiClient = () => {
  const options = {
    timeout: 50000,
    headers: {
      'Content-Type': 'application/json',
    },
  }
  const client = axios.create(options)

  client.interceptors.request.use(
    async requestConfig => {
      const keyLog = await asyncStorage.getItem('@key_log').then(val => val)

      if (keyLog) {
        requestConfig.headers.Authorization = `Token ${keyLog}`
      }
      return requestConfig
    },
    requestError => {
      return Promise.reject(requestError)
    },
  )

  client.interceptors.response.use(
    response => Promise.resolve(response),
    error => {
      if (error.response) {
        const {status} = error.response;

        if (status === 401) {
          asyncStorage.removeItem('@key_log').then(() => {
            navigate('MainAppAuth')
          })
        }

        return Promise.reject(error)
      }
    }
  )

  return client
}

const serializeForm = (initialState, state) => {
  let dataFormFix = {}, key

  for (key in initialState) {
      if (initialState.hasOwnProperty(key) && state.hasOwnProperty(key)) {
          if (typeof state[key] === 'undefined') {
              dataFormFix[key] = null
          } else if (typeof state[key] === 'string' && state[key] === '') {
              dataFormFix[key] = null
          } else if (Array.isArray(state[key]) && state[key].length === 0) {
              dataFormFix[key] = null
          } else {
              dataFormFix[key] = state[key]
          }
      }
  }
  return dataFormFix
}

const showToast = (text = null, type = null) => {
  let textColor = '#f5f5f5'
  switch (type) {
    case 'success':
      textColor = '#26de26'
      break
    case 'warning':
      textColor = '#d8db26'
      break
    case 'danger':
      textColor = '#db2e25'
      break
    default:
      return textColor
  }
  Toast.show({
    text: text,
    textStyle: {
      color: textColor,
      fontSize: 14,
    },
    buttonText: '',
    duration: 3000,
    style: {
      backgroundColor: '#202020',
      margin: 10,
      borderRadius: 3,
    },
  })
}


export {
  asyncStorage,
  axios,
  apiClient,
  collection,
  dotenv,
  moment,
  serializeForm,
  showToast,
  Xendit,
}
