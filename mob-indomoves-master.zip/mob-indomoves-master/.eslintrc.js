module.exports = {
  root: true,
  extends: '@react-native-community',
  rules: {
    'prettier/prettier': 0,
    'semi': 0,
    'space-before-function-paren': 1,
    'arrow-spacing': 1
  },
};
