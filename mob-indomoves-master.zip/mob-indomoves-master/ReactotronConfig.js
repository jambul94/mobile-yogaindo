import Reactotron from 'reactotron-react-native'
import {asyncStorage} from './src/_common/helper'
import {reactotronRedux} from 'reactotron-redux'

const reactotron = Reactotron
  .setAsyncStorageHandler(asyncStorage)
  .configure()
  .useReactNative()
  .use(reactotronRedux())
  .connect()

export {
  reactotron,
}
